#!/usr/bin/env bash
#
# 批量测试 PanguLU 在不同线程数下的运行时间
#

# 可执行程序路径
PanguLU_BIN=~/PanguLU/examples/pangulu_example.elf

# 要测试的矩阵文件列表（相对于绝对路径）
FILES=(
#  "$HOME/mtx/water_tank.mtx"
#  "$HOME/mtx/onetone1.mtx"
#  "$HOME/mtx/lung2.mtx"
#  "$HOME/mtx/ASIC_680k.mtx"
#  "$HOME/mtx/bcsstk35.mtx"
#  "$HOME/mtx/psmigr_3.mtx"
#  "$HOME/mtx/xenon1.mtx"
#  "$HOME/mtx/viscoplastic2.mtx"
#  "$HOME/mtx/BenElechi1.mtx"
#  "$HOME/mtx/Zd_Jac6_db.mtx"
  "$HOME/mtx/heart3.mtx"
  "$HOME/mtx/ACTIVSg70K.mtx"
  "$HOME/mtx/bcircuit.mtx"
  "$HOME/mtx/hvdc2.mtx"
  "$HOME/mtx/Chebyshev4.mtx"
  "$HOME/mtx/thermomech_dK.mtx"
  "$HOME/mtx/epb3.mtx"
  "$HOME/mtx/twotone.mtx"
  "$HOME/mtx/g7jac200.mtx"
  "$HOME/mtx/Zd_Jac6.mtx"
)

# 要测试的线程数
THREADS=(1 2 4 8 16 32)

# 日志文件
LOGFILE="intel_PanguLU.log"
echo "=== PanguLU Batch Run Started: $(date) ===" | tee "${LOGFILE}"

for file in "${FILES[@]}"; do
  if [[ ! -f "$file" ]]; then
    echo "SKIP: 文件不存在: $file" | tee -a "${LOGFILE}"
    continue
  fi

  echo "--- Processing: $file ---" | tee -a "${LOGFILE}"
  for th in "${THREADS[@]}"; do
    export OMP_NUM_THREADS=$th
    echo "[$(date +'%H:%M:%S')] Threads=$th:" | tee -a "${LOGFILE}"
    # 执行 QKLU 并将时间信息追加到日志
    { time mpirun -np "$th" "$PanguLU_BIN" -nb 256 -f "$file"; } 2>&1 | tee -a "${LOGFILE}"
    echo "--------------------------------------" | tee -a "${LOGFILE}"
  done
  echo | tee -a "${LOGFILE}"
done

echo "=== PanguLU Batch Run Finished: $(date) ===" | tee -a "${LOGFILE}"