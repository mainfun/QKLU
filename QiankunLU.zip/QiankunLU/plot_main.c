#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include <omp.h>

#include "base/matrix_plot.h"
#include "base/file.h"

int main(int argc, char *argv[]) {
    if (argc < 3) { LOG_ERROR("Usage: %s <matrix file> <output image path>", argv[0]); }
    double start_time = omp_get_wtime();
    CSRMatrix *original_matrix = load_matrix_csr(argv[1], false);
    PreprocessInfo *info = init_preprocess_info();
    CSRMatrix *A = reordering(original_matrix, info,true,true);
    double plot_time = omp_get_wtime();
    plot_LU(A, argv[2], omp_get_wtime() - start_time);
    LOG_TIME("plot_LU time:%f", (omp_get_wtime()-plot_time)*1000);
    free_csr_matrix(original_matrix);
    free_preprocess_info(info);
    return 0;
}
