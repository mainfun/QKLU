import re

# 示例文本
text = """
<!DOCTYPE html>
<html lang='en'>
<head>
<title>SuiteSparse Matrix Collection</title>
<meta content='SuiteSparse Matrix Collection Index' name='Description'>
<meta charset='utf-8'>
<meta content='width=device-width, initial-scale=1' name='viewport'>
<link rel="stylesheet" media="none" href="/assets/application-52a4821cb811a7ddf82e72437d06e754a7b7741c5aa84da2df099ffb7d7b89de.css" data-turbolinks-track="true" onload="if(media!=&#39;all&#39;)media=&#39;all&#39;" />
<script src="/assets/application-beb157311ea976755bc69e0f1bb582ba98dd5f515d12899460900f56e69b701e.js" data-turbolinks-track="true"></script>
<meta name="csrf-param" content="authenticity_token" />
<meta name="csrf-token" content="8h9aCCYKA/PkJFAp/zLLmrMaN+K9UWLoJZv6q8vj2v0+zDFe5KZCRxuF62jtzjypLh4klhLfxD0q84JnheZq0Q==" />
<meta content='r2pRTzxj91fBd9LQN4oiboo32gfV1c8PpalflcYY8XE' name='google-site-verification'>
</head>
<body>
<nav class='navbar fixed-top navbar-expand-lg navbar-dark'>
<div class='container'>
<div class='navbar-brand'>
<div class='logo'>
<img alt="SuiteSparse Matrix Collection Logo" src="/assets/logo-7cabf2bf0925e8e538d6ebd5552c56283cad18c4ec1b6e83d3ba420fc059d0f7.png" />
</div>
<a href='/'>
<h1>
SuiteSparse Matrix Collection
<small>Formerly the University of Florida Sparse Matrix Collection</small>
</h1>
</a>
</div>
<button aria-controls='navbarNav' aria-label='Toggle navigation' class='navbar-toggler' data-target='#navbar' data-toggle='collapse' type='button'>
<span class='navbar-toggler-icon'></span>
</button>
<div class='collapse navbar-collapse' id='navbar'>
<ul class='ml-auto navbar-nav nav-pills'>
<li class='nav-item'>
<a class="nav-link active" href="/">Index</a>
</li>
<li class='nav-item'>
<a class="nav-link" href="/about">About</a>
</li>
<li class='nav-item'>
<a class="nav-link" href="/interfaces">Interfaces</a>
</li>
<li class='nav-item'>
<a class="nav-link" href="/submit">Submit Matrix</a>
</li>
</ul>
</div>
</div>
</nav>
<div class='container theme-showcase main' id='index-main' role='main'>


<div class='alert alert-info alert-dismissible about-alert'>
<button aria-label='Close' class='close about-close' data-dismiss='alert' type='button'>
<span aria-hidden='true'>
&times;
</span>
</button>
The SuiteSparse Matrix Collection (formerly the University of Florida Sparse Matrix Collection) is a widely used set of sparse matrix benchmarks collected from a wide range of applications. See the
<a class="alert-link" href="/about">about page</a>
for more information.
</div>
<div class='card card-body bg-light'>
<div class='row'>
<div class='col-lg-2'>
<div class='text-center filter-column'>
<div class='dropdown'>
<button aria-expanded='true' aria-haspopup='true' class='btn btn-outline-dark btn-md dropdown-toggle mb-2' data-toggle='dropdown' id='filter-dropdown' type='button'>
<span aria-hidden='true' class='fa fa-filter'></span>
Filters
</button>
<ul aria-labelledby='filter-dropdown' class='dropdown-menu' data-no-turbolink='true'>
<li>
<div class='small' data-target='.size-checkbox' tabIndex='-1'>
<input type="checkbox" name="size_checkbox" id="size_checkbox" value="enable" class="filter-checkbox size-checkbox" data-target="#size-filter" checked="checked" />
<label for="size_checkbox">Size and Shape</label>
</div>
</li>
<li>
<div class='small' data-target='.structure-checkbox' tabIndex='-1'>
<input type="checkbox" name="structure_checkbox" id="structure_checkbox" value="enable" class="filter-checkbox structure-checkbox" data-target="#structure-filter" checked="checked" />
<label for="structure_checkbox">Structure and Entry Types</label>
</div>
</li>
<li>
<div class='small' data-target='.metadata-checkbox' tabIndex='-1'>
<input type="checkbox" name="metadata_checkbox" id="metadata_checkbox" value="enable" class="filter-checkbox metadata-checkbox" data-target="#metadata-filter" />
<label for="metadata_checkbox">Metadata</label>
</div>
</li>
</ul>
</div>
</div>
<div class='filterrific_spinner' style='display:none; margin: 30px 40%;'>
<img src="/assets/ajax-loader-fd7f32a8862609f42dd58dd94f33acfa1ad5d0895687fe5420e3e5c1e94b1857.gif" />
</div>
</div>
<!-- Set up the filter form -->
<div class='col-lg-10 text-center' style='margin-left: -1px; border-left: 1px solid #e3e3e3;'>
<form class="new_filterrific" id="filterrific_filter" action="/" accept-charset="UTF-8" method="get"><div class='row filter'>
<div class='col-md-6'>
<div class='card' id='search'>
<legend class='card-header'>
<label for="filterrific_search_query">Keyword Search</label>
</legend>
<div class='card-body'>
<input class="filterrific-periodically-observed" type="text" name="filterrific[search_query]" id="filterrific_search_query" />
</div>
</div>
</div>
<div class='col-md-6'>
<div class='card'>
<legend class='card-header'>
<label for="filterrific_sorted_by">Sorted by</label>
</legend>
<div class='card-body'>
<select name="filterrific[sorted_by]" id="filterrific_sorted_by"><option value="id_desc">ID (High to Low)</option>
<option selected="selected" value="id_asc">ID (Low to High)</option>
<option value="group_asc">Group (A to Z)</option>
<option value="group_desc">Group (Z to A)</option>
<option value="name_asc">Name (A to Z)</option>
<option value="name_desc">Name (Z to A)</option>
<option value="rows_desc">Rows (High to Low)</option>
<option value="rows_asc">Rows (Low to High)</option>
<option value="cols_desc">Columns (High to Low)</option>
<option value="cols_asc">Columns (Low to High)</option>
<option value="nonzeros_desc">Nonzeros (High to Low)</option>
<option value="nonzeros_asc">Nonzeros (Low to High)</option>
<option value="kind_asc">Kind (A to Z)</option>
<option value="kind_desc">Kind (Z to A)</option>
<option value="date_asc">Date (Oldest First)</option>
<option value="date_desc">Date (Recent First)</option></select>
</div>
</div>
</div>
</div>
<div class='filter filter-hidden' id='size-filter'>
<h2 class='py-2'>
Filter by Matrix Size and Shape
</h2>
<div class='row'>
<div class='col-md-4'>
<div class='card'>
<legend class='card-header'>
Rows
</legend>
<div class='card-body d-flex justify-content-between py-1'>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-rows-min" type="text" name="filterrific[min_rows]" />
<label for="filter-input-rows-min">Min</label>
</div>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-rows-max" type="text" name="filterrific[max_rows]" />
<label for="filter-input-rows-max">Max</label>
</div>
</div>
</div>
</div>
<div class='col-md-4'>
<div class='card'>
<legend class='card-header'>
Columns
</legend>
<div class='card-body d-flex justify-content-between py-1'>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-columns-min" type="text" name="filterrific[min_cols]" />
<label for="filter-input-columns-min">Min</label>
</div>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-columns-max" type="text" name="filterrific[max_cols]" />
<label for="filter-input-columns-max">Max</label>
</div>
</div>
</div>
</div>
<div class='col-md-4'>
<div class='card'>
<legend class='card-header'>
Nonzeros
</legend>
<div class='card-body d-flex justify-content-between py-1'>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-nonzeros-min" type="text" value="100000" name="filterrific[min_nonzeros]" />
<label for="filter-input-nonzeros-min">Min</label>
</div>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-nonzeros-max" type="text" name="filterrific[max_nonzeros]" />
<label for="filter-input-nonzeros-max">Max</label>
</div>
</div>
</div>
</div>
</div>
</div>
<div class='filter filter-hidden' id='structure-filter'>
<h2 class='py-2'>
Filter by Matrix Structure and Entry Type
</h2>
<div class='row'>
<div class='col-md-4 column'>
<div class='card'>
<legend class='card-header'>
Pattern Symmetry
</legend>
<div class='card-body d-flex justify-content-between py-1'>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-pattern_symmetry-min" type="text" name="filterrific[min_pattern_symmetry]" />
<label for="filter-input-pattern_symmetry-min">Min (%)</label>
</div>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-pattern_symmetry-max" type="text" name="filterrific[max_pattern_symmetry]" />
<label for="filter-input-pattern_symmetry-max">Max (%)</label>
</div>
</div>
</div>
</div>
<div class='col-md-4 column'>
<div class='card'>
<legend class='card-header'>
Numerical Symmetry
</legend>
<div class='card-body d-flex justify-content-between py-1'>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-numerical_symmetry-min" type="text" name="filterrific[min_numerical_symmetry]" />
<label for="filter-input-numerical_symmetry-min">Min (%)</label>
</div>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-numerical_symmetry-max" type="text" name="filterrific[max_numerical_symmetry]" />
<label for="filter-input-numerical_symmetry-max">Max (%)</label>
</div>
</div>
</div>
</div>
<div class='col-md-4 column'>
<div class='card'>
<legend class='card-header'>
Strongly Connected Components
</legend>
<div class='card-body d-flex justify-content-between py-1'>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-strongly_connected_components-min" type="text" name="filterrific[min_strongly_connected_components]" />
<label for="filter-input-strongly_connected_components-min">Min</label>
</div>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-strongly_connected_components-max" type="text" name="filterrific[max_strongly_connected_components]" />
<label for="filter-input-strongly_connected_components-max">Max</label>
</div>
</div>
</div>
</div>
</div>
<div class='row'>
<div class='col-md-4 column'>
<div class='card'>
<legend class='card-header'>
<label for='filter-input-rb_type'>
Rutherford-Boeing Type
</label>
</legend>
<div class='card-body'>
<select id="filter-input-rb_type" name="filterrific[rb_type]"><option value="">Any</option>
<option value="Real">Real</option>
<option value="Complex">Complex</option>
<option value="Integer">Integer</option>
<option value="Binary">Binary</option></select>
</div>
</div>
</div>
<div class='col-md-4 column'>
<div class='card'>
<legend class='card-header'>
<label for='filter-input-structure'>
Special Structure
</label>
</legend>
<div class='card-body'>
<select id="filter-input-structure" name="filterrific[structure]"><option value="">Any</option>
<option value="Square">Square</option>
<option value="Rectangular">Rectangular</option>
<option value="Symmetric">Symmetric</option>
<option value="Unsymmetric">Unsymmetric</option>
<option value="Hermitian">Hermitian</option>
<option value="Skew-Symmetric">Skew-Symmetric</option></select>
</div>
</div>
</div>
<div class='col-md-4 column'>
<div class='card'>
<legend class='card-header'>
<label for='filter-input-positive_definite'>
Positive Definite
</label>
</legend>
<div class='card-body'>
<select id="filter-input-positive_definite" name="filterrific[positive_definite]"><option value="">Any</option>
<option value="Yes">Yes</option>
<option value="No">No</option></select>
</div>
</div>
</div>
</div>
</div>
<div class='filter filter-hidden' id='metadata-filter'>
<h2 class='py-2'>
Filter by Matrix Metadata
</h2>
<div class='row'>
<div class='col-md-3 col-6 column'>
<div class='card'>
<label class='card-header' for='filter-input-name'>
Matrix Name
</label>
<div class='card-body'>
<input class="filterrific-periodically-observed" id="filter-input-name" style="width: 80%;" type="text" name="filterrific[name_query]" />
</div>
</div>
</div>
<div class='col-md-3 col-6 column'>
<div class='card'>
<label class='card-header' for='filter-input-group'>
Group Name
</label>
<div class='card-body'>
<input class="filterrific-periodically-observed" id="filter-input-group" style="width: 80%;" type="text" name="filterrific[group_query]" />
</div>
</div>
</div>
<div class='col-md-3 col-6 column'>
<div class='card'>
<legend class='card-header'>
Matrix ID
</legend>
<div class='card-body d-flex justify-content-between py-1'>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-id-min" type="text" name="filterrific[min_id]" />
<label for='filter-input-id-min'>
Min
</label>
</div>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-id-max" type="text" name="filterrific[max_id]" />
<label for='filter-input-id-max'>
Max
</label>
</div>
</div>
</div>
</div>
<div class='col-md-3 col-6 column'>
<div class='card'>
<legend class='card-header'>
Year
</legend>
<div class='card-body d-flex justify-content-between py-1'>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-year-min" type="text" name="filterrific[min_year]" />
<label for="filter-input-year-min">Min</label>
</div>
<div class='input-with-label p-1'>
<input class="filterrific-periodically-observed" id="filter-input-year-max" type="text" name="filterrific[max_year]" />
<label for="filter-input-year-max">Max</label>
</div>
</div>
</div>
</div>
</div>
</div>
</form></div>
</div>
</div>
<div id='filterrific_results'>
<div class='card card-body bg-light container p-1 my-2'>
<div class='d-flex justify-content-between align-items-center'>
<div class='p-2'>
Displaying <strong>all&nbsp;524</strong> collection matrices
</div>
<div class='p-2'>
<a href="/?filterrific%5Breset_filterrific%5D=true"><button class='btn btn-outline-dark btn-sm'>
Reset Filters
<span aria-hidden='true' class='fas fa-sync-alt'></span>
</button>
</a></div>
</div>
</div>
<!-- Top Pagination Bar -->
<div class='pagination-container container px-2'>
<div class='row'>
<div class='col'></div>
<div class='col p-0'>

</div>
<div class='col col-lg-3 p-2 text-right'>
<label for="per_page_top">Display per page:</label>
<select name="per_page_top" id="per_page_top" onchange="if(this.value){window.location=&#39;?per_page=&#39;+this.value;}"><option value="20">20</option>
<option value="50">50</option>
<option value="100">100</option>
<option selected="selected" value="All">All</option></select>
</div>
</div>
</div>
<!-- Layout the matrix table -->
<div class='col-sm-12 m-0 p-0'>
<table class='table table-sm table-striped' id='matrices'>
<thead>
<tr class='text-nowrap' id='sort-selector'>
<th><a class="filterrific_current_sort_column" data-remote="true" data-method="get" href="/?filterrific%5Bmin_nonzeros%5D=100000&amp;filterrific%5Bpositive_definite%5D=No&amp;filterrific%5Brb_type%5D=Real&amp;filterrific%5Bsorted_by%5D=id_desc&amp;filterrific%5Bstructure%5D=Square">Id <span class="fas fa-sort-up"></span></a></th>
<th><a class="filterrific_sort_column" data-remote="true" data-method="get" href="/?filterrific%5Bmin_nonzeros%5D=100000&amp;filterrific%5Bpositive_definite%5D=No&amp;filterrific%5Brb_type%5D=Real&amp;filterrific%5Bsorted_by%5D=name_asc&amp;filterrific%5Bstructure%5D=Square">Name</a></th>
<th><a class="filterrific_sort_column" data-remote="true" data-method="get" href="/?filterrific%5Bmin_nonzeros%5D=100000&amp;filterrific%5Bpositive_definite%5D=No&amp;filterrific%5Brb_type%5D=Real&amp;filterrific%5Bsorted_by%5D=group_asc&amp;filterrific%5Bstructure%5D=Square">Group</a></th>
<th><a class="filterrific_sort_column" data-remote="true" data-method="get" href="/?filterrific%5Bmin_nonzeros%5D=100000&amp;filterrific%5Bpositive_definite%5D=No&amp;filterrific%5Brb_type%5D=Real&amp;filterrific%5Bsorted_by%5D=rows_asc&amp;filterrific%5Bstructure%5D=Square">Rows</a></th>
<th><a class="filterrific_sort_column" data-remote="true" data-method="get" href="/?filterrific%5Bmin_nonzeros%5D=100000&amp;filterrific%5Bpositive_definite%5D=No&amp;filterrific%5Brb_type%5D=Real&amp;filterrific%5Bsorted_by%5D=cols_asc&amp;filterrific%5Bstructure%5D=Square">Cols</a></th>
<th><a class="filterrific_sort_column" data-remote="true" data-method="get" href="/?filterrific%5Bmin_nonzeros%5D=100000&amp;filterrific%5Bpositive_definite%5D=No&amp;filterrific%5Brb_type%5D=Real&amp;filterrific%5Bsorted_by%5D=nonzeros_asc&amp;filterrific%5Bstructure%5D=Square">Nonzeros</a></th>
<th class='d-none d-md-table-cell'><a class="filterrific_sort_column" data-remote="true" data-method="get" href="/?filterrific%5Bmin_nonzeros%5D=100000&amp;filterrific%5Bpositive_definite%5D=No&amp;filterrific%5Brb_type%5D=Real&amp;filterrific%5Bsorted_by%5D=kind_asc&amp;filterrific%5Bstructure%5D=Square">Kind</a></th>
<th class='d-none d-md-table-cell'><a class="filterrific_sort_column" data-remote="true" data-method="get" href="/?filterrific%5Bmin_nonzeros%5D=100000&amp;filterrific%5Bpositive_definite%5D=No&amp;filterrific%5Brb_type%5D=Real&amp;filterrific%5Bsorted_by%5D=date_asc&amp;filterrific%5Bstructure%5D=Square">Date</a></th>
<th class='d-none d-lg-table-cell' id='download-header'>Download File</th>
</tr>
</thead>
<tbody>
<tr>
<td class='column-id'>236</td>
<td class='column-name'><a href="/HB/psmigr_2">psmigr_2</a></td>
<td class='column-group'><a href="/HB">HB</a></td>
<td class='column-num_rows'>3,140</td>
<td class='column-num_cols'>3,140</td>
<td class='column-nonzeros'>540,022</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>1983</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/HB/psmigr_2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/HB/psmigr_2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/HB/psmigr_2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>237</td>
<td class='column-name'><a href="/HB/psmigr_3">psmigr_3</a></td>
<td class='column-group'><a href="/HB">HB</a></td>
<td class='column-num_rows'>3,140</td>
<td class='column-num_cols'>3,140</td>
<td class='column-nonzeros'>543,160</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>1983</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/HB/psmigr_3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/HB/psmigr_3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/HB/psmigr_3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>283</td>
<td class='column-name'><a href="/ATandT/onetone1">onetone1</a></td>
<td class='column-group'><a href="/ATandT">ATandT</a></td>
<td class='column-num_rows'>36,057</td>
<td class='column-num_cols'>36,057</td>
<td class='column-nonzeros'>335,552</td>
<td class='column-kind d-none d-md-table-cell'>Frequency Domain Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ATandT/onetone1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ATandT/onetone1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ATandT/onetone1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>284</td>
<td class='column-name'><a href="/ATandT/onetone2">onetone2</a></td>
<td class='column-group'><a href="/ATandT">ATandT</a></td>
<td class='column-num_rows'>36,057</td>
<td class='column-num_cols'>36,057</td>
<td class='column-nonzeros'>222,596</td>
<td class='column-kind d-none d-md-table-cell'>Frequency Domain Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ATandT/onetone2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ATandT/onetone2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ATandT/onetone2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>285</td>
<td class='column-name'><a href="/ATandT/pre2">pre2</a></td>
<td class='column-group'><a href="/ATandT">ATandT</a></td>
<td class='column-num_rows'>659,033</td>
<td class='column-num_cols'>659,033</td>
<td class='column-nonzeros'>5,834,044</td>
<td class='column-kind d-none d-md-table-cell'>Frequency Domain Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ATandT/pre2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ATandT/pre2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ATandT/pre2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>286</td>
<td class='column-name'><a href="/ATandT/twotone">twotone</a></td>
<td class='column-group'><a href="/ATandT">ATandT</a></td>
<td class='column-num_rows'>120,750</td>
<td class='column-num_cols'>120,750</td>
<td class='column-nonzeros'>1,206,265</td>
<td class='column-kind d-none d-md-table-cell'>Frequency Domain Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ATandT/twotone.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ATandT/twotone.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ATandT/twotone.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>289</td>
<td class='column-name'><a href="/Averous/epb2">epb2</a></td>
<td class='column-group'><a href="/Averous">Averous</a></td>
<td class='column-num_rows'>25,228</td>
<td class='column-num_cols'>25,228</td>
<td class='column-nonzeros'>175,027</td>
<td class='column-kind d-none d-md-table-cell'>Thermal Problem</td>
<td class='column-date d-none d-md-table-cell'>1998</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Averous/epb2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Averous/epb2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Averous/epb2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>290</td>
<td class='column-name'><a href="/Averous/epb3">epb3</a></td>
<td class='column-group'><a href="/Averous">Averous</a></td>
<td class='column-num_rows'>84,617</td>
<td class='column-num_cols'>84,617</td>
<td class='column-nonzeros'>463,625</td>
<td class='column-kind d-none d-md-table-cell'>Thermal Problem</td>
<td class='column-date d-none d-md-table-cell'>1998</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Averous/epb3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Averous/epb3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Averous/epb3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>291</td>
<td class='column-name'><a href="/Bai/af23560">af23560</a></td>
<td class='column-group'><a href="/Bai">Bai</a></td>
<td class='column-num_rows'>23,560</td>
<td class='column-num_cols'>23,560</td>
<td class='column-nonzeros'>460,598</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1991</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bai/af23560.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bai/af23560.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bai/af23560.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>340</td>
<td class='column-name'><a href="/Boeing/bcsstk35">bcsstk35</a></td>
<td class='column-group'><a href="/Boeing">Boeing</a></td>
<td class='column-num_rows'>30,237</td>
<td class='column-num_cols'>30,237</td>
<td class='column-nonzeros'>1,450,163</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Boeing/bcsstk35.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Boeing/bcsstk35.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Boeing/bcsstk35.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>342</td>
<td class='column-name'><a href="/Boeing/bcsstk37">bcsstk37</a></td>
<td class='column-group'><a href="/Boeing">Boeing</a></td>
<td class='column-num_rows'>25,503</td>
<td class='column-num_cols'>25,503</td>
<td class='column-nonzeros'>1,140,977</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Boeing/bcsstk37.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Boeing/bcsstk37.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Boeing/bcsstk37.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>346</td>
<td class='column-name'><a href="/Boeing/bcsstm36">bcsstm36</a></td>
<td class='column-group'><a href="/Boeing">Boeing</a></td>
<td class='column-num_rows'>23,052</td>
<td class='column-num_cols'>23,052</td>
<td class='column-nonzeros'>320,606</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Boeing/bcsstm36.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Boeing/bcsstm36.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Boeing/bcsstm36.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>350</td>
<td class='column-name'><a href="/Boeing/crystk01">crystk01</a></td>
<td class='column-group'><a href="/Boeing">Boeing</a></td>
<td class='column-num_rows'>4,875</td>
<td class='column-num_cols'>4,875</td>
<td class='column-nonzeros'>315,891</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Boeing/crystk01.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Boeing/crystk01.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Boeing/crystk01.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>351</td>
<td class='column-name'><a href="/Boeing/crystk02">crystk02</a></td>
<td class='column-group'><a href="/Boeing">Boeing</a></td>
<td class='column-num_rows'>13,965</td>
<td class='column-num_cols'>13,965</td>
<td class='column-nonzeros'>968,583</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Boeing/crystk02.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Boeing/crystk02.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Boeing/crystk02.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>352</td>
<td class='column-name'><a href="/Boeing/crystk03">crystk03</a></td>
<td class='column-group'><a href="/Boeing">Boeing</a></td>
<td class='column-num_rows'>24,696</td>
<td class='column-num_cols'>24,696</td>
<td class='column-nonzeros'>1,751,178</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Boeing/crystk03.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Boeing/crystk03.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Boeing/crystk03.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>373</td>
<td class='column-name'><a href="/Bomhof/circuit_4">circuit_4</a></td>
<td class='column-group'><a href="/Bomhof">Bomhof</a></td>
<td class='column-num_rows'>80,209</td>
<td class='column-num_cols'>80,209</td>
<td class='column-nonzeros'>307,604</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2000</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bomhof/circuit_4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bomhof/circuit_4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bomhof/circuit_4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>374</td>
<td class='column-name'><a href="/Bova/rma10">rma10</a></td>
<td class='column-group'><a href="/Bova">Bova</a></td>
<td class='column-num_rows'>46,835</td>
<td class='column-num_cols'>46,835</td>
<td class='column-nonzeros'>2,329,092</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bova/rma10.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bova/rma10.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bova/rma10.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>376</td>
<td class='column-name'><a href="/Brethour/coater2">coater2</a></td>
<td class='column-group'><a href="/Brethour">Brethour</a></td>
<td class='column-num_rows'>9,540</td>
<td class='column-num_cols'>9,540</td>
<td class='column-nonzeros'>207,308</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Brethour/coater2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Brethour/coater2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Brethour/coater2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>379</td>
<td class='column-name'><a href="/Cote/vibrobox">vibrobox</a></td>
<td class='column-group'><a href="/Cote">Cote</a></td>
<td class='column-num_rows'>12,328</td>
<td class='column-num_cols'>12,328</td>
<td class='column-nonzeros'>301,700</td>
<td class='column-kind d-none d-md-table-cell'>Acoustics Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Cote/vibrobox.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Cote/vibrobox.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Cote/vibrobox.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>395</td>
<td class='column-name'><a href="/DRIVCAV/cavity16">cavity16</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>137,887</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity16.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity16.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity16.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>396</td>
<td class='column-name'><a href="/DRIVCAV/cavity17">cavity17</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>131,735</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity17.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity17.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity17.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>397</td>
<td class='column-name'><a href="/DRIVCAV/cavity18">cavity18</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>138,040</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity18.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity18.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity18.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>398</td>
<td class='column-name'><a href="/DRIVCAV/cavity19">cavity19</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>131,735</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity19.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity19.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity19.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>399</td>
<td class='column-name'><a href="/DRIVCAV/cavity20">cavity20</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>138,040</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity20.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity20.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity20.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>400</td>
<td class='column-name'><a href="/DRIVCAV/cavity21">cavity21</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>131,735</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity21.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity21.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity21.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>401</td>
<td class='column-name'><a href="/DRIVCAV/cavity22">cavity22</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>138,040</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity22.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity22.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity22.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>402</td>
<td class='column-name'><a href="/DRIVCAV/cavity23">cavity23</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>131,735</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity23.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity23.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity23.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>403</td>
<td class='column-name'><a href="/DRIVCAV/cavity24">cavity24</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>138,040</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity24.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity24.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity24.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>404</td>
<td class='column-name'><a href="/DRIVCAV/cavity25">cavity25</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>131,735</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity25.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity25.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity25.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>405</td>
<td class='column-name'><a href="/DRIVCAV/cavity26">cavity26</a></td>
<td class='column-group'><a href="/DRIVCAV">DRIVCAV</a></td>
<td class='column-num_rows'>4,562</td>
<td class='column-num_cols'>4,562</td>
<td class='column-nonzeros'>138,040</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/DRIVCAV/cavity26.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/DRIVCAV/cavity26.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/DRIVCAV/cavity26.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>409</td>
<td class='column-name'><a href="/FIDAP/ex11">ex11</a></td>
<td class='column-group'><a href="/FIDAP">FIDAP</a></td>
<td class='column-num_rows'>16,614</td>
<td class='column-num_cols'>16,614</td>
<td class='column-nonzeros'>1,096,948</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FIDAP/ex11.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FIDAP/ex11.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FIDAP/ex11.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>415</td>
<td class='column-name'><a href="/FIDAP/ex19">ex19</a></td>
<td class='column-group'><a href="/FIDAP">FIDAP</a></td>
<td class='column-num_rows'>12,005</td>
<td class='column-num_cols'>12,005</td>
<td class='column-nonzeros'>259,577</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FIDAP/ex19.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FIDAP/ex19.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FIDAP/ex19.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>431</td>
<td class='column-name'><a href="/FIDAP/ex35">ex35</a></td>
<td class='column-group'><a href="/FIDAP">FIDAP</a></td>
<td class='column-num_rows'>19,716</td>
<td class='column-num_cols'>19,716</td>
<td class='column-nonzeros'>227,872</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FIDAP/ex35.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FIDAP/ex35.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FIDAP/ex35.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>435</td>
<td class='column-name'><a href="/FIDAP/ex40">ex40</a></td>
<td class='column-group'><a href="/FIDAP">FIDAP</a></td>
<td class='column-num_rows'>7,740</td>
<td class='column-num_cols'>7,740</td>
<td class='column-nonzeros'>456,188</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FIDAP/ex40.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FIDAP/ex40.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FIDAP/ex40.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>445</td>
<td class='column-name'><a href="/Garon/garon2">garon2</a></td>
<td class='column-group'><a href="/Garon">Garon</a></td>
<td class='column-num_rows'>13,535</td>
<td class='column-num_cols'>13,535</td>
<td class='column-nonzeros'>373,235</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1996</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Garon/garon2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Garon/garon2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Garon/garon2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>446</td>
<td class='column-name'><a href="/Goodwin/goodwin">goodwin</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>7,320</td>
<td class='column-num_cols'>7,320</td>
<td class='column-nonzeros'>324,772</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/goodwin.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/goodwin.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/goodwin.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>447</td>
<td class='column-name'><a href="/Goodwin/rim">rim</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>22,560</td>
<td class='column-num_cols'>22,560</td>
<td class='column-nonzeros'>1,014,951</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/rim.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/rim.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/rim.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>448</td>
<td class='column-name'><a href="/Graham/graham1">graham1</a></td>
<td class='column-group'><a href="/Graham">Graham</a></td>
<td class='column-num_rows'>9,035</td>
<td class='column-num_cols'>9,035</td>
<td class='column-nonzeros'>335,472</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1998</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Graham/graham1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Graham/graham1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Graham/graham1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>452</td>
<td class='column-name'><a href="/Grund/bayer01">bayer01</a></td>
<td class='column-group'><a href="/Grund">Grund</a></td>
<td class='column-num_rows'>57,735</td>
<td class='column-num_cols'>57,735</td>
<td class='column-nonzeros'>275,094</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Grund/bayer01.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Grund/bayer01.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Grund/bayer01.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>541</td>
<td class='column-name'><a href="/Hamm/bcircuit">bcircuit</a></td>
<td class='column-group'><a href="/Hamm">Hamm</a></td>
<td class='column-num_rows'>68,902</td>
<td class='column-num_cols'>68,902</td>
<td class='column-nonzeros'>375,558</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hamm/bcircuit.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hamm/bcircuit.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hamm/bcircuit.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>542</td>
<td class='column-name'><a href="/Hamm/hcircuit">hcircuit</a></td>
<td class='column-group'><a href="/Hamm">Hamm</a></td>
<td class='column-num_rows'>105,676</td>
<td class='column-num_cols'>105,676</td>
<td class='column-nonzeros'>513,072</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hamm/hcircuit.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hamm/hcircuit.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hamm/hcircuit.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>544</td>
<td class='column-name'><a href="/Hamm/scircuit">scircuit</a></td>
<td class='column-group'><a href="/Hamm">Hamm</a></td>
<td class='column-num_rows'>170,998</td>
<td class='column-num_cols'>170,998</td>
<td class='column-nonzeros'>958,936</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hamm/scircuit.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hamm/scircuit.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hamm/scircuit.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>549</td>
<td class='column-name'><a href="/Hollinger/g7jac040">g7jac040</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>11,790</td>
<td class='column-num_cols'>11,790</td>
<td class='column-nonzeros'>107,383</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac040.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac040.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac040.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>550</td>
<td class='column-name'><a href="/Hollinger/g7jac040sc">g7jac040sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>11,790</td>
<td class='column-num_cols'>11,790</td>
<td class='column-nonzeros'>107,383</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac040sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac040sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac040sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>551</td>
<td class='column-name'><a href="/Hollinger/g7jac050sc">g7jac050sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>14,760</td>
<td class='column-num_cols'>14,760</td>
<td class='column-nonzeros'>145,157</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac050sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac050sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac050sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>552</td>
<td class='column-name'><a href="/Hollinger/g7jac060">g7jac060</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>17,730</td>
<td class='column-num_cols'>17,730</td>
<td class='column-nonzeros'>183,325</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac060.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac060.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac060.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>553</td>
<td class='column-name'><a href="/Hollinger/g7jac060sc">g7jac060sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>17,730</td>
<td class='column-num_cols'>17,730</td>
<td class='column-nonzeros'>183,325</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac060sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac060sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac060sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>554</td>
<td class='column-name'><a href="/Hollinger/g7jac080">g7jac080</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>23,670</td>
<td class='column-num_cols'>23,670</td>
<td class='column-nonzeros'>259,648</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac080.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac080.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac080.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>555</td>
<td class='column-name'><a href="/Hollinger/g7jac080sc">g7jac080sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>23,670</td>
<td class='column-num_cols'>23,670</td>
<td class='column-nonzeros'>259,648</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac080sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac080sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac080sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>556</td>
<td class='column-name'><a href="/Hollinger/g7jac100">g7jac100</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>29,610</td>
<td class='column-num_cols'>29,610</td>
<td class='column-nonzeros'>335,972</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac100.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac100.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac100.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>557</td>
<td class='column-name'><a href="/Hollinger/g7jac100sc">g7jac100sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>29,610</td>
<td class='column-num_cols'>29,610</td>
<td class='column-nonzeros'>335,972</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac100sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac100sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac100sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>558</td>
<td class='column-name'><a href="/Hollinger/g7jac120">g7jac120</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>35,550</td>
<td class='column-num_cols'>35,550</td>
<td class='column-nonzeros'>412,306</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac120.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac120.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac120.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>559</td>
<td class='column-name'><a href="/Hollinger/g7jac120sc">g7jac120sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>35,550</td>
<td class='column-num_cols'>35,550</td>
<td class='column-nonzeros'>412,306</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac120sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac120sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac120sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>560</td>
<td class='column-name'><a href="/Hollinger/g7jac140">g7jac140</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>41,490</td>
<td class='column-num_cols'>41,490</td>
<td class='column-nonzeros'>488,633</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac140.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac140.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac140.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>561</td>
<td class='column-name'><a href="/Hollinger/g7jac140sc">g7jac140sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>41,490</td>
<td class='column-num_cols'>41,490</td>
<td class='column-nonzeros'>488,633</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac140sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac140sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac140sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>562</td>
<td class='column-name'><a href="/Hollinger/g7jac160">g7jac160</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>47,430</td>
<td class='column-num_cols'>47,430</td>
<td class='column-nonzeros'>564,952</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac160.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac160.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac160.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>563</td>
<td class='column-name'><a href="/Hollinger/g7jac160sc">g7jac160sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>47,430</td>
<td class='column-num_cols'>47,430</td>
<td class='column-nonzeros'>564,952</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac160sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac160sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac160sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>564</td>
<td class='column-name'><a href="/Hollinger/g7jac180">g7jac180</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>53,370</td>
<td class='column-num_cols'>53,370</td>
<td class='column-nonzeros'>641,290</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac180.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac180.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac180.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>565</td>
<td class='column-name'><a href="/Hollinger/g7jac180sc">g7jac180sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>53,370</td>
<td class='column-num_cols'>53,370</td>
<td class='column-nonzeros'>641,290</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac180sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac180sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac180sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>566</td>
<td class='column-name'><a href="/Hollinger/g7jac200">g7jac200</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>59,310</td>
<td class='column-num_cols'>59,310</td>
<td class='column-nonzeros'>717,620</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac200.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac200.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac200.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>567</td>
<td class='column-name'><a href="/Hollinger/g7jac200sc">g7jac200sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>59,310</td>
<td class='column-num_cols'>59,310</td>
<td class='column-nonzeros'>717,620</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/g7jac200sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/g7jac200sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/g7jac200sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>572</td>
<td class='column-name'><a href="/Hollinger/jan99jac060">jan99jac060</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>20,614</td>
<td class='column-num_cols'>20,614</td>
<td class='column-nonzeros'>111,903</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/jan99jac060.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/jan99jac060.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/jan99jac060.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>573</td>
<td class='column-name'><a href="/Hollinger/jan99jac060sc">jan99jac060sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>20,614</td>
<td class='column-num_cols'>20,614</td>
<td class='column-nonzeros'>111,903</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/jan99jac060sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/jan99jac060sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/jan99jac060sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>574</td>
<td class='column-name'><a href="/Hollinger/jan99jac080">jan99jac080</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>27,534</td>
<td class='column-num_cols'>27,534</td>
<td class='column-nonzeros'>151,063</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/jan99jac080.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/jan99jac080.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/jan99jac080.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>575</td>
<td class='column-name'><a href="/Hollinger/jan99jac080sc">jan99jac080sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>27,534</td>
<td class='column-num_cols'>27,534</td>
<td class='column-nonzeros'>151,063</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/jan99jac080sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/jan99jac080sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/jan99jac080sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>576</td>
<td class='column-name'><a href="/Hollinger/jan99jac100">jan99jac100</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>34,454</td>
<td class='column-num_cols'>34,454</td>
<td class='column-nonzeros'>190,224</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/jan99jac100.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/jan99jac100.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/jan99jac100.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>577</td>
<td class='column-name'><a href="/Hollinger/jan99jac100sc">jan99jac100sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>34,454</td>
<td class='column-num_cols'>34,454</td>
<td class='column-nonzeros'>190,224</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/jan99jac100sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/jan99jac100sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/jan99jac100sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>578</td>
<td class='column-name'><a href="/Hollinger/jan99jac120">jan99jac120</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>41,374</td>
<td class='column-num_cols'>41,374</td>
<td class='column-nonzeros'>229,385</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/jan99jac120.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/jan99jac120.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/jan99jac120.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>579</td>
<td class='column-name'><a href="/Hollinger/jan99jac120sc">jan99jac120sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>41,374</td>
<td class='column-num_cols'>41,374</td>
<td class='column-nonzeros'>229,385</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/jan99jac120sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/jan99jac120sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/jan99jac120sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>582</td>
<td class='column-name'><a href="/Hollinger/mark3jac040">mark3jac040</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>18,289</td>
<td class='column-num_cols'>18,289</td>
<td class='column-nonzeros'>106,803</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac040.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac040.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac040.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>583</td>
<td class='column-name'><a href="/Hollinger/mark3jac040sc">mark3jac040sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>18,289</td>
<td class='column-num_cols'>18,289</td>
<td class='column-nonzeros'>106,803</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac040sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac040sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac040sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>584</td>
<td class='column-name'><a href="/Hollinger/mark3jac060">mark3jac060</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>27,449</td>
<td class='column-num_cols'>27,449</td>
<td class='column-nonzeros'>160,723</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac060.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac060.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac060.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>585</td>
<td class='column-name'><a href="/Hollinger/mark3jac060sc">mark3jac060sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>27,449</td>
<td class='column-num_cols'>27,449</td>
<td class='column-nonzeros'>160,723</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac060sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac060sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac060sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>586</td>
<td class='column-name'><a href="/Hollinger/mark3jac080">mark3jac080</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>36,609</td>
<td class='column-num_cols'>36,609</td>
<td class='column-nonzeros'>214,643</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac080.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac080.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac080.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>587</td>
<td class='column-name'><a href="/Hollinger/mark3jac080sc">mark3jac080sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>36,609</td>
<td class='column-num_cols'>36,609</td>
<td class='column-nonzeros'>214,643</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac080sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac080sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac080sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>588</td>
<td class='column-name'><a href="/Hollinger/mark3jac100">mark3jac100</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>45,769</td>
<td class='column-num_cols'>45,769</td>
<td class='column-nonzeros'>268,563</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac100.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac100.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac100.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>589</td>
<td class='column-name'><a href="/Hollinger/mark3jac100sc">mark3jac100sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>45,769</td>
<td class='column-num_cols'>45,769</td>
<td class='column-nonzeros'>268,563</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac100sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac100sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac100sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>590</td>
<td class='column-name'><a href="/Hollinger/mark3jac120">mark3jac120</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>54,929</td>
<td class='column-num_cols'>54,929</td>
<td class='column-nonzeros'>322,483</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac120.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac120.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac120.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>591</td>
<td class='column-name'><a href="/Hollinger/mark3jac120sc">mark3jac120sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>54,929</td>
<td class='column-num_cols'>54,929</td>
<td class='column-nonzeros'>322,483</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac120sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac120sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac120sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>592</td>
<td class='column-name'><a href="/Hollinger/mark3jac140">mark3jac140</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>64,089</td>
<td class='column-num_cols'>64,089</td>
<td class='column-nonzeros'>376,395</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac140.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac140.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac140.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>593</td>
<td class='column-name'><a href="/Hollinger/mark3jac140sc">mark3jac140sc</a></td>
<td class='column-group'><a href="/Hollinger">Hollinger</a></td>
<td class='column-num_rows'>64,089</td>
<td class='column-num_cols'>64,089</td>
<td class='column-nonzeros'>376,395</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hollinger/mark3jac140sc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hollinger/mark3jac140sc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hollinger/mark3jac140sc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>732</td>
<td class='column-name'><a href="/Li/li">li</a></td>
<td class='column-group'><a href="/Li">Li</a></td>
<td class='column-num_rows'>22,695</td>
<td class='column-num_cols'>22,695</td>
<td class='column-nonzeros'>1,215,181</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Li/li.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Li/li.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Li/li.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>738</td>
<td class='column-name'><a href="/Mallya/lhr07">lhr07</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>7,337</td>
<td class='column-num_cols'>7,337</td>
<td class='column-nonzeros'>154,660</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr07.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr07.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr07.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>739</td>
<td class='column-name'><a href="/Mallya/lhr07c">lhr07c</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>7,337</td>
<td class='column-num_cols'>7,337</td>
<td class='column-nonzeros'>156,508</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr07c.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr07c.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr07c.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>740</td>
<td class='column-name'><a href="/Mallya/lhr10">lhr10</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>10,672</td>
<td class='column-num_cols'>10,672</td>
<td class='column-nonzeros'>228,395</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr10.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr10.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr10.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>741</td>
<td class='column-name'><a href="/Mallya/lhr10c">lhr10c</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>10,672</td>
<td class='column-num_cols'>10,672</td>
<td class='column-nonzeros'>232,633</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr10c.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr10c.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr10c.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>742</td>
<td class='column-name'><a href="/Mallya/lhr11">lhr11</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>10,964</td>
<td class='column-num_cols'>10,964</td>
<td class='column-nonzeros'>231,806</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr11.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr11.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr11.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>743</td>
<td class='column-name'><a href="/Mallya/lhr11c">lhr11c</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>10,964</td>
<td class='column-num_cols'>10,964</td>
<td class='column-nonzeros'>233,741</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr11c.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr11c.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr11c.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>744</td>
<td class='column-name'><a href="/Mallya/lhr14">lhr14</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>14,270</td>
<td class='column-num_cols'>14,270</td>
<td class='column-nonzeros'>305,750</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr14.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr14.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr14.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>745</td>
<td class='column-name'><a href="/Mallya/lhr14c">lhr14c</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>14,270</td>
<td class='column-num_cols'>14,270</td>
<td class='column-nonzeros'>307,858</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr14c.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr14c.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr14c.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>746</td>
<td class='column-name'><a href="/Mallya/lhr17">lhr17</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>17,576</td>
<td class='column-num_cols'>17,576</td>
<td class='column-nonzeros'>379,761</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr17.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr17.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr17.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>747</td>
<td class='column-name'><a href="/Mallya/lhr17c">lhr17c</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>17,576</td>
<td class='column-num_cols'>17,576</td>
<td class='column-nonzeros'>381,975</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr17c.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr17c.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr17c.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>748</td>
<td class='column-name'><a href="/Mallya/lhr34">lhr34</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>35,152</td>
<td class='column-num_cols'>35,152</td>
<td class='column-nonzeros'>746,972</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr34.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr34.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr34.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>749</td>
<td class='column-name'><a href="/Mallya/lhr34c">lhr34c</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>35,152</td>
<td class='column-num_cols'>35,152</td>
<td class='column-nonzeros'>764,014</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr34c.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr34c.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr34c.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>750</td>
<td class='column-name'><a href="/Mallya/lhr71">lhr71</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>70,304</td>
<td class='column-num_cols'>70,304</td>
<td class='column-nonzeros'>1,494,006</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr71.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr71.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr71.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>751</td>
<td class='column-name'><a href="/Mallya/lhr71c">lhr71c</a></td>
<td class='column-group'><a href="/Mallya">Mallya</a></td>
<td class='column-num_rows'>70,304</td>
<td class='column-num_cols'>70,304</td>
<td class='column-nonzeros'>1,528,092</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>1997</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mallya/lhr71c.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mallya/lhr71c.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mallya/lhr71c.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>765</td>
<td class='column-name'><a href="/Nemeth/nemeth01">nemeth01</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>725,054</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth01.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth01.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth01.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>766</td>
<td class='column-name'><a href="/Nemeth/nemeth02">nemeth02</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>394,808</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth02.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth02.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth02.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>767</td>
<td class='column-name'><a href="/Nemeth/nemeth03">nemeth03</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>394,808</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth03.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth03.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth03.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>768</td>
<td class='column-name'><a href="/Nemeth/nemeth04">nemeth04</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>394,808</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth04.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth04.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth04.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>769</td>
<td class='column-name'><a href="/Nemeth/nemeth05">nemeth05</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>394,808</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth05.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth05.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth05.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>770</td>
<td class='column-name'><a href="/Nemeth/nemeth06">nemeth06</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>394,808</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth06.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth06.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth06.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>771</td>
<td class='column-name'><a href="/Nemeth/nemeth07">nemeth07</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>394,812</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth07.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth07.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth07.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>772</td>
<td class='column-name'><a href="/Nemeth/nemeth08">nemeth08</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>394,816</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth08.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth08.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth08.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>773</td>
<td class='column-name'><a href="/Nemeth/nemeth09">nemeth09</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>395,506</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth09.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth09.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth09.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>774</td>
<td class='column-name'><a href="/Nemeth/nemeth10">nemeth10</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>401,448</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth10.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth10.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth10.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>775</td>
<td class='column-name'><a href="/Nemeth/nemeth11">nemeth11</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>408,264</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth11.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth11.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth11.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>776</td>
<td class='column-name'><a href="/Nemeth/nemeth12">nemeth12</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>446,818</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth12.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth12.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth12.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>777</td>
<td class='column-name'><a href="/Nemeth/nemeth13">nemeth13</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>474,472</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth13.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth13.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth13.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>778</td>
<td class='column-name'><a href="/Nemeth/nemeth14">nemeth14</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>496,144</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth14.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth14.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth14.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>779</td>
<td class='column-name'><a href="/Nemeth/nemeth15">nemeth15</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>539,802</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth15.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth15.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth15.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>780</td>
<td class='column-name'><a href="/Nemeth/nemeth16">nemeth16</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>587,012</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth16.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth16.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth16.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>781</td>
<td class='column-name'><a href="/Nemeth/nemeth17">nemeth17</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>629,620</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth17.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth17.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth17.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>782</td>
<td class='column-name'><a href="/Nemeth/nemeth18">nemeth18</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>695,234</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth18.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth18.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth18.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>783</td>
<td class='column-name'><a href="/Nemeth/nemeth19">nemeth19</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>818,302</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth19.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth19.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth19.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>784</td>
<td class='column-name'><a href="/Nemeth/nemeth20">nemeth20</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>971,870</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth20.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth20.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth20.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>785</td>
<td class='column-name'><a href="/Nemeth/nemeth21">nemeth21</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>1,173,746</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth21.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth21.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth21.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>786</td>
<td class='column-name'><a href="/Nemeth/nemeth22">nemeth22</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>1,358,832</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth22.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth22.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth22.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>787</td>
<td class='column-name'><a href="/Nemeth/nemeth23">nemeth23</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>1,506,810</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth23.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth23.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth23.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>788</td>
<td class='column-name'><a href="/Nemeth/nemeth24">nemeth24</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>1,506,550</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth24.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth24.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth24.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>789</td>
<td class='column-name'><a href="/Nemeth/nemeth25">nemeth25</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>1,511,758</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth25.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth25.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth25.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>790</td>
<td class='column-name'><a href="/Nemeth/nemeth26">nemeth26</a></td>
<td class='column-group'><a href="/Nemeth">Nemeth</a></td>
<td class='column-num_rows'>9,506</td>
<td class='column-num_cols'>9,506</td>
<td class='column-nonzeros'>1,511,760</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>1999</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Nemeth/nemeth26.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Nemeth/nemeth26.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Nemeth/nemeth26.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>801</td>
<td class='column-name'><a href="/Ronis/xenon1">xenon1</a></td>
<td class='column-group'><a href="/Ronis">Ronis</a></td>
<td class='column-num_rows'>48,600</td>
<td class='column-num_cols'>48,600</td>
<td class='column-nonzeros'>1,181,120</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Ronis/xenon1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Ronis/xenon1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Ronis/xenon1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>802</td>
<td class='column-name'><a href="/Ronis/xenon2">xenon2</a></td>
<td class='column-group'><a href="/Ronis">Ronis</a></td>
<td class='column-num_rows'>157,464</td>
<td class='column-num_cols'>157,464</td>
<td class='column-nonzeros'>3,866,688</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Ronis/xenon2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Ronis/xenon2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Ronis/xenon2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>809</td>
<td class='column-name'><a href="/Shyy/shyy161">shyy161</a></td>
<td class='column-group'><a href="/Shyy">Shyy</a></td>
<td class='column-num_rows'>76,480</td>
<td class='column-num_cols'>76,480</td>
<td class='column-nonzeros'>329,762</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Shyy/shyy161.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Shyy/shyy161.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Shyy/shyy161.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>811</td>
<td class='column-name'><a href="/Simon/appu">appu</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>14,000</td>
<td class='column-num_cols'>14,000</td>
<td class='column-nonzeros'>1,853,104</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Random Graph</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/appu.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/appu.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/appu.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>812</td>
<td class='column-name'><a href="/Simon/bbmat">bbmat</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>38,744</td>
<td class='column-num_cols'>38,744</td>
<td class='column-nonzeros'>1,771,722</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/bbmat.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/bbmat.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/bbmat.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>814</td>
<td class='column-name'><a href="/Simon/raefsky1">raefsky1</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>3,242</td>
<td class='column-num_cols'>3,242</td>
<td class='column-nonzeros'>293,409</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/raefsky1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/raefsky1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/raefsky1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>815</td>
<td class='column-name'><a href="/Simon/raefsky2">raefsky2</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>3,242</td>
<td class='column-num_cols'>3,242</td>
<td class='column-nonzeros'>293,551</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/raefsky2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/raefsky2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/raefsky2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>816</td>
<td class='column-name'><a href="/Simon/raefsky3">raefsky3</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>21,200</td>
<td class='column-num_cols'>21,200</td>
<td class='column-nonzeros'>1,488,768</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/raefsky3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/raefsky3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/raefsky3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>818</td>
<td class='column-name'><a href="/Simon/raefsky5">raefsky5</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>6,316</td>
<td class='column-num_cols'>6,316</td>
<td class='column-nonzeros'>167,178</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/raefsky5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/raefsky5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/raefsky5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>819</td>
<td class='column-name'><a href="/Simon/raefsky6">raefsky6</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>3,402</td>
<td class='column-num_cols'>3,402</td>
<td class='column-nonzeros'>130,371</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/raefsky6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/raefsky6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/raefsky6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>820</td>
<td class='column-name'><a href="/Simon/venkat01">venkat01</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>62,424</td>
<td class='column-num_cols'>62,424</td>
<td class='column-nonzeros'>1,717,792</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/venkat01.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/venkat01.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/venkat01.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>821</td>
<td class='column-name'><a href="/Simon/venkat25">venkat25</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>62,424</td>
<td class='column-num_cols'>62,424</td>
<td class='column-nonzeros'>1,717,763</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/venkat25.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/venkat25.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/venkat25.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>822</td>
<td class='column-name'><a href="/Simon/venkat50">venkat50</a></td>
<td class='column-group'><a href="/Simon">Simon</a></td>
<td class='column-num_rows'>62,424</td>
<td class='column-num_cols'>62,424</td>
<td class='column-nonzeros'>1,717,777</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>1993</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Simon/venkat50.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Simon/venkat50.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Simon/venkat50.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>827</td>
<td class='column-name'><a href="/Vavasis/av41092">av41092</a></td>
<td class='column-group'><a href="/Vavasis">Vavasis</a></td>
<td class='column-num_rows'>41,092</td>
<td class='column-num_cols'>41,092</td>
<td class='column-nonzeros'>1,683,902</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Vavasis/av41092.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Vavasis/av41092.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Vavasis/av41092.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>832</td>
<td class='column-name'><a href="/Wang/wang3">wang3</a></td>
<td class='column-group'><a href="/Wang">Wang</a></td>
<td class='column-num_rows'>26,064</td>
<td class='column-num_cols'>26,064</td>
<td class='column-nonzeros'>177,168</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Wang/wang3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Wang/wang3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Wang/wang3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>833</td>
<td class='column-name'><a href="/Wang/wang4">wang4</a></td>
<td class='column-group'><a href="/Wang">Wang</a></td>
<td class='column-num_rows'>26,068</td>
<td class='column-num_cols'>26,068</td>
<td class='column-nonzeros'>177,196</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Wang/wang4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Wang/wang4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Wang/wang4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>834</td>
<td class='column-name'><a href="/Zhao/Zhao1">Zhao1</a></td>
<td class='column-group'><a href="/Zhao">Zhao</a></td>
<td class='column-num_rows'>33,861</td>
<td class='column-num_cols'>33,861</td>
<td class='column-nonzeros'>166,453</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Zhao/Zhao1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Zhao/Zhao1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Zhao/Zhao1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>835</td>
<td class='column-name'><a href="/Zhao/Zhao2">Zhao2</a></td>
<td class='column-group'><a href="/Zhao">Zhao</a></td>
<td class='column-num_rows'>33,861</td>
<td class='column-num_cols'>33,861</td>
<td class='column-nonzeros'>166,453</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Zhao/Zhao2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Zhao/Zhao2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Zhao/Zhao2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>842</td>
<td class='column-name'><a href="/Cunningham/k3plates">k3plates</a></td>
<td class='column-group'><a href="/Cunningham">Cunningham</a></td>
<td class='column-num_rows'>11,107</td>
<td class='column-num_cols'>11,107</td>
<td class='column-nonzeros'>378,927</td>
<td class='column-kind d-none d-md-table-cell'>Acoustics Problem</td>
<td class='column-date d-none d-md-table-cell'>2002</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Cunningham/k3plates.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Cunningham/k3plates.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Cunningham/k3plates.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>844</td>
<td class='column-name'><a href="/Cunningham/qa8fk">qa8fk</a></td>
<td class='column-group'><a href="/Cunningham">Cunningham</a></td>
<td class='column-num_rows'>66,127</td>
<td class='column-num_cols'>66,127</td>
<td class='column-nonzeros'>1,660,579</td>
<td class='column-kind d-none d-md-table-cell'>Acoustics Problem</td>
<td class='column-date d-none d-md-table-cell'>2002</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Cunningham/qa8fk.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Cunningham/qa8fk.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Cunningham/qa8fk.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>846</td>
<td class='column-name'><a href="/Boeing/bcsstk39">bcsstk39</a></td>
<td class='column-group'><a href="/Boeing">Boeing</a></td>
<td class='column-num_rows'>46,772</td>
<td class='column-num_cols'>46,772</td>
<td class='column-nonzeros'>2,060,662</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2002</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Boeing/bcsstk39.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Boeing/bcsstk39.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Boeing/bcsstk39.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>890</td>
<td class='column-name'><a href="/Norris/heart1">heart1</a></td>
<td class='column-group'><a href="/Norris">Norris</a></td>
<td class='column-num_rows'>3,557</td>
<td class='column-num_cols'>3,557</td>
<td class='column-nonzeros'>1,385,317</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Norris/heart1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Norris/heart1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Norris/heart1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>891</td>
<td class='column-name'><a href="/Norris/heart2">heart2</a></td>
<td class='column-group'><a href="/Norris">Norris</a></td>
<td class='column-num_rows'>2,339</td>
<td class='column-num_cols'>2,339</td>
<td class='column-nonzeros'>680,341</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Norris/heart2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Norris/heart2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Norris/heart2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>892</td>
<td class='column-name'><a href="/Norris/heart3">heart3</a></td>
<td class='column-group'><a href="/Norris">Norris</a></td>
<td class='column-num_rows'>2,339</td>
<td class='column-num_cols'>2,339</td>
<td class='column-nonzeros'>680,341</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Norris/heart3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Norris/heart3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Norris/heart3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>894</td>
<td class='column-name'><a href="/Norris/lung2">lung2</a></td>
<td class='column-group'><a href="/Norris">Norris</a></td>
<td class='column-num_rows'>109,460</td>
<td class='column-num_cols'>109,460</td>
<td class='column-nonzeros'>492,564</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Norris/lung2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Norris/lung2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Norris/lung2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>895</td>
<td class='column-name'><a href="/Norris/stomach">stomach</a></td>
<td class='column-group'><a href="/Norris">Norris</a></td>
<td class='column-num_rows'>213,360</td>
<td class='column-num_cols'>213,360</td>
<td class='column-nonzeros'>3,021,648</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Norris/stomach.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Norris/stomach.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Norris/stomach.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>896</td>
<td class='column-name'><a href="/Norris/torso1">torso1</a></td>
<td class='column-group'><a href="/Norris">Norris</a></td>
<td class='column-num_rows'>116,158</td>
<td class='column-num_cols'>116,158</td>
<td class='column-nonzeros'>8,516,500</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Norris/torso1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Norris/torso1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Norris/torso1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>897</td>
<td class='column-name'><a href="/Norris/torso2">torso2</a></td>
<td class='column-group'><a href="/Norris">Norris</a></td>
<td class='column-num_rows'>115,967</td>
<td class='column-num_cols'>115,967</td>
<td class='column-nonzeros'>1,033,473</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Norris/torso2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Norris/torso2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Norris/torso2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>898</td>
<td class='column-name'><a href="/Norris/torso3">torso3</a></td>
<td class='column-group'><a href="/Norris">Norris</a></td>
<td class='column-num_rows'>259,156</td>
<td class='column-num_cols'>259,156</td>
<td class='column-nonzeros'>4,429,042</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Norris/torso3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Norris/torso3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Norris/torso3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>899</td>
<td class='column-name'><a href="/Shen/e40r0100">e40r0100</a></td>
<td class='column-group'><a href="/Shen">Shen</a></td>
<td class='column-num_rows'>17,281</td>
<td class='column-num_cols'>17,281</td>
<td class='column-nonzeros'>553,562</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Shen/e40r0100.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Shen/e40r0100.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Shen/e40r0100.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>901</td>
<td class='column-name'><a href="/Shen/shermanACb">shermanACb</a></td>
<td class='column-group'><a href="/Shen">Shen</a></td>
<td class='column-num_rows'>18,510</td>
<td class='column-num_cols'>18,510</td>
<td class='column-nonzeros'>145,149</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Shen/shermanACb.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Shen/shermanACb.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Shen/shermanACb.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>911</td>
<td class='column-name'><a href="/vanHeukelum/cage10">cage10</a></td>
<td class='column-group'><a href="/vanHeukelum">vanHeukelum</a></td>
<td class='column-num_rows'>11,397</td>
<td class='column-num_cols'>11,397</td>
<td class='column-nonzeros'>150,645</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/vanHeukelum/cage10.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/vanHeukelum/cage10.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/vanHeukelum/cage10.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>912</td>
<td class='column-name'><a href="/vanHeukelum/cage11">cage11</a></td>
<td class='column-group'><a href="/vanHeukelum">vanHeukelum</a></td>
<td class='column-num_rows'>39,082</td>
<td class='column-num_cols'>39,082</td>
<td class='column-nonzeros'>559,722</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/vanHeukelum/cage11.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/vanHeukelum/cage11.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/vanHeukelum/cage11.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>913</td>
<td class='column-name'><a href="/vanHeukelum/cage12">cage12</a></td>
<td class='column-group'><a href="/vanHeukelum">vanHeukelum</a></td>
<td class='column-num_rows'>130,228</td>
<td class='column-num_cols'>130,228</td>
<td class='column-nonzeros'>2,032,536</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/vanHeukelum/cage12.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/vanHeukelum/cage12.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/vanHeukelum/cage12.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>914</td>
<td class='column-name'><a href="/vanHeukelum/cage13">cage13</a></td>
<td class='column-group'><a href="/vanHeukelum">vanHeukelum</a></td>
<td class='column-num_rows'>445,315</td>
<td class='column-num_cols'>445,315</td>
<td class='column-nonzeros'>7,479,343</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/vanHeukelum/cage13.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/vanHeukelum/cage13.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/vanHeukelum/cage13.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>915</td>
<td class='column-name'><a href="/vanHeukelum/cage14">cage14</a></td>
<td class='column-group'><a href="/vanHeukelum">vanHeukelum</a></td>
<td class='column-num_rows'>1,505,785</td>
<td class='column-num_cols'>1,505,785</td>
<td class='column-nonzeros'>27,130,349</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/vanHeukelum/cage14.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/vanHeukelum/cage14.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/vanHeukelum/cage14.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>916</td>
<td class='column-name'><a href="/vanHeukelum/cage15">cage15</a></td>
<td class='column-group'><a href="/vanHeukelum">vanHeukelum</a></td>
<td class='column-num_rows'>5,154,859</td>
<td class='column-num_cols'>5,154,859</td>
<td class='column-nonzeros'>99,199,551</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/vanHeukelum/cage15.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/vanHeukelum/cage15.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/vanHeukelum/cage15.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>920</td>
<td class='column-name'><a href="/Hohn/sinc12">sinc12</a></td>
<td class='column-group'><a href="/Hohn">Hohn</a></td>
<td class='column-num_rows'>7,500</td>
<td class='column-num_cols'>7,500</td>
<td class='column-nonzeros'>283,992</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hohn/sinc12.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hohn/sinc12.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hohn/sinc12.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>921</td>
<td class='column-name'><a href="/Hohn/sinc15">sinc15</a></td>
<td class='column-group'><a href="/Hohn">Hohn</a></td>
<td class='column-num_rows'>11,532</td>
<td class='column-num_cols'>11,532</td>
<td class='column-nonzeros'>551,184</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hohn/sinc15.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hohn/sinc15.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hohn/sinc15.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>922</td>
<td class='column-name'><a href="/Hohn/sinc18">sinc18</a></td>
<td class='column-group'><a href="/Hohn">Hohn</a></td>
<td class='column-num_rows'>16,428</td>
<td class='column-num_cols'>16,428</td>
<td class='column-nonzeros'>948,696</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hohn/sinc18.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hohn/sinc18.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hohn/sinc18.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>925</td>
<td class='column-name'><a href="/FEMLAB/ns3Da">ns3Da</a></td>
<td class='column-group'><a href="/FEMLAB">FEMLAB</a></td>
<td class='column-num_rows'>20,414</td>
<td class='column-num_cols'>20,414</td>
<td class='column-nonzeros'>1,679,599</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FEMLAB/ns3Da.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FEMLAB/ns3Da.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FEMLAB/ns3Da.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>927</td>
<td class='column-name'><a href="/FEMLAB/poisson3Da">poisson3Da</a></td>
<td class='column-group'><a href="/FEMLAB">FEMLAB</a></td>
<td class='column-num_rows'>13,514</td>
<td class='column-num_cols'>13,514</td>
<td class='column-nonzeros'>352,762</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FEMLAB/poisson3Da.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FEMLAB/poisson3Da.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FEMLAB/poisson3Da.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>928</td>
<td class='column-name'><a href="/FEMLAB/poisson3Db">poisson3Db</a></td>
<td class='column-group'><a href="/FEMLAB">FEMLAB</a></td>
<td class='column-num_rows'>85,623</td>
<td class='column-num_cols'>85,623</td>
<td class='column-nonzeros'>2,374,949</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FEMLAB/poisson3Db.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FEMLAB/poisson3Db.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FEMLAB/poisson3Db.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>930</td>
<td class='column-name'><a href="/FEMLAB/sme3Da">sme3Da</a></td>
<td class='column-group'><a href="/FEMLAB">FEMLAB</a></td>
<td class='column-num_rows'>12,504</td>
<td class='column-num_cols'>12,504</td>
<td class='column-nonzeros'>874,887</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FEMLAB/sme3Da.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FEMLAB/sme3Da.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FEMLAB/sme3Da.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>931</td>
<td class='column-name'><a href="/FEMLAB/sme3Db">sme3Db</a></td>
<td class='column-group'><a href="/FEMLAB">FEMLAB</a></td>
<td class='column-num_rows'>29,067</td>
<td class='column-num_cols'>29,067</td>
<td class='column-nonzeros'>2,081,063</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FEMLAB/sme3Db.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FEMLAB/sme3Db.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FEMLAB/sme3Db.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>932</td>
<td class='column-name'><a href="/FEMLAB/sme3Dc">sme3Dc</a></td>
<td class='column-group'><a href="/FEMLAB">FEMLAB</a></td>
<td class='column-num_rows'>42,930</td>
<td class='column-num_cols'>42,930</td>
<td class='column-nonzeros'>3,148,656</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/FEMLAB/sme3Dc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/FEMLAB/sme3Dc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/FEMLAB/sme3Dc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>940</td>
<td class='column-name'><a href="/Schenk_AFE/af_shell1">af_shell1</a></td>
<td class='column-group'><a href="/Schenk_AFE">Schenk_AFE</a></td>
<td class='column-num_rows'>504,855</td>
<td class='column-num_cols'>504,855</td>
<td class='column-nonzeros'>17,562,051</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_AFE/af_shell1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_AFE/af_shell1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_AFE/af_shell1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>941</td>
<td class='column-name'><a href="/Schenk_AFE/af_shell2">af_shell2</a></td>
<td class='column-group'><a href="/Schenk_AFE">Schenk_AFE</a></td>
<td class='column-num_rows'>504,855</td>
<td class='column-num_cols'>504,855</td>
<td class='column-nonzeros'>17,562,051</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_AFE/af_shell2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_AFE/af_shell2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_AFE/af_shell2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>944</td>
<td class='column-name'><a href="/Schenk_AFE/af_shell5">af_shell5</a></td>
<td class='column-group'><a href="/Schenk_AFE">Schenk_AFE</a></td>
<td class='column-num_rows'>504,855</td>
<td class='column-num_cols'>504,855</td>
<td class='column-nonzeros'>17,579,155</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_AFE/af_shell5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_AFE/af_shell5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_AFE/af_shell5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>945</td>
<td class='column-name'><a href="/Schenk_AFE/af_shell6">af_shell6</a></td>
<td class='column-group'><a href="/Schenk_AFE">Schenk_AFE</a></td>
<td class='column-num_rows'>504,855</td>
<td class='column-num_cols'>504,855</td>
<td class='column-nonzeros'>17,579,155</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_AFE/af_shell6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_AFE/af_shell6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_AFE/af_shell6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>948</td>
<td class='column-name'><a href="/Schenk_AFE/af_shell9">af_shell9</a></td>
<td class='column-group'><a href="/Schenk_AFE">Schenk_AFE</a></td>
<td class='column-num_rows'>504,855</td>
<td class='column-num_cols'>504,855</td>
<td class='column-nonzeros'>17,588,845</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_AFE/af_shell9.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_AFE/af_shell9.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_AFE/af_shell9.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>949</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-62">c-62</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>41,731</td>
<td class='column-num_cols'>41,731</td>
<td class='column-nonzeros'>559,341</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-62.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-62.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-62.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>950</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-64">c-64</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>51,035</td>
<td class='column-num_cols'>51,035</td>
<td class='column-nonzeros'>707,985</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-64.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-64.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-64.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>951</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-66">c-66</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>49,989</td>
<td class='column-num_cols'>49,989</td>
<td class='column-nonzeros'>444,853</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-66.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-66.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-66.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>952</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-67">c-67</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>57,975</td>
<td class='column-num_cols'>57,975</td>
<td class='column-nonzeros'>530,229</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-67.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-67.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-67.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>953</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-73">c-73</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>169,422</td>
<td class='column-num_cols'>169,422</td>
<td class='column-nonzeros'>1,279,274</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-73.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-73.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-73.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>954</td>
<td class='column-name'><a href="/Schenk_IBMSDS/2D_27628_bjtcai">2D_27628_bjtcai</a></td>
<td class='column-group'><a href="/Schenk_IBMSDS">Schenk_IBMSDS</a></td>
<td class='column-num_rows'>27,628</td>
<td class='column-num_cols'>27,628</td>
<td class='column-nonzeros'>206,670</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMSDS/2D_27628_bjtcai.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMSDS/2D_27628_bjtcai.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMSDS/2D_27628_bjtcai.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>955</td>
<td class='column-name'><a href="/Schenk_IBMSDS/2D_54019_highK">2D_54019_highK</a></td>
<td class='column-group'><a href="/Schenk_IBMSDS">Schenk_IBMSDS</a></td>
<td class='column-num_rows'>54,019</td>
<td class='column-num_cols'>54,019</td>
<td class='column-nonzeros'>486,129</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMSDS/2D_54019_highK.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMSDS/2D_54019_highK.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMSDS/2D_54019_highK.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>956</td>
<td class='column-name'><a href="/Schenk_IBMSDS/3D_28984_Tetra">3D_28984_Tetra</a></td>
<td class='column-group'><a href="/Schenk_IBMSDS">Schenk_IBMSDS</a></td>
<td class='column-num_rows'>28,984</td>
<td class='column-num_cols'>28,984</td>
<td class='column-nonzeros'>285,092</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMSDS/3D_28984_Tetra.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMSDS/3D_28984_Tetra.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMSDS/3D_28984_Tetra.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>957</td>
<td class='column-name'><a href="/Schenk_IBMSDS/3D_51448_3D">3D_51448_3D</a></td>
<td class='column-group'><a href="/Schenk_IBMSDS">Schenk_IBMSDS</a></td>
<td class='column-num_rows'>51,448</td>
<td class='column-num_cols'>51,448</td>
<td class='column-nonzeros'>537,038</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMSDS/3D_51448_3D.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMSDS/3D_51448_3D.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMSDS/3D_51448_3D.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>958</td>
<td class='column-name'><a href="/Schenk_IBMSDS/ibm_matrix_2">ibm_matrix_2</a></td>
<td class='column-group'><a href="/Schenk_IBMSDS">Schenk_IBMSDS</a></td>
<td class='column-num_rows'>51,448</td>
<td class='column-num_cols'>51,448</td>
<td class='column-nonzeros'>537,038</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMSDS/ibm_matrix_2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMSDS/ibm_matrix_2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMSDS/ibm_matrix_2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>959</td>
<td class='column-name'><a href="/Schenk_IBMSDS/matrix_9">matrix_9</a></td>
<td class='column-group'><a href="/Schenk_IBMSDS">Schenk_IBMSDS</a></td>
<td class='column-num_rows'>103,430</td>
<td class='column-num_cols'>103,430</td>
<td class='column-nonzeros'>1,205,518</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMSDS/matrix_9.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMSDS/matrix_9.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMSDS/matrix_9.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>960</td>
<td class='column-name'><a href="/Schenk_IBMSDS/matrix-new_3">matrix-new_3</a></td>
<td class='column-group'><a href="/Schenk_IBMSDS">Schenk_IBMSDS</a></td>
<td class='column-num_rows'>125,329</td>
<td class='column-num_cols'>125,329</td>
<td class='column-nonzeros'>893,984</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMSDS/matrix-new_3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMSDS/matrix-new_3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMSDS/matrix-new_3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>961</td>
<td class='column-name'><a href="/Schenk_ISEI/barrier2-10">barrier2-10</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>115,625</td>
<td class='column-num_cols'>115,625</td>
<td class='column-nonzeros'>2,158,759</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/barrier2-10.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/barrier2-10.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/barrier2-10.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>962</td>
<td class='column-name'><a href="/Schenk_ISEI/barrier2-11">barrier2-11</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>115,625</td>
<td class='column-num_cols'>115,625</td>
<td class='column-nonzeros'>2,158,759</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/barrier2-11.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/barrier2-11.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/barrier2-11.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>963</td>
<td class='column-name'><a href="/Schenk_ISEI/barrier2-12">barrier2-12</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>115,625</td>
<td class='column-num_cols'>115,625</td>
<td class='column-nonzeros'>2,158,759</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/barrier2-12.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/barrier2-12.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/barrier2-12.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>964</td>
<td class='column-name'><a href="/Schenk_ISEI/barrier2-1">barrier2-1</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>113,076</td>
<td class='column-num_cols'>113,076</td>
<td class='column-nonzeros'>2,129,496</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/barrier2-1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/barrier2-1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/barrier2-1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>965</td>
<td class='column-name'><a href="/Schenk_ISEI/barrier2-2">barrier2-2</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>113,076</td>
<td class='column-num_cols'>113,076</td>
<td class='column-nonzeros'>2,129,496</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/barrier2-2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/barrier2-2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/barrier2-2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>966</td>
<td class='column-name'><a href="/Schenk_ISEI/barrier2-3">barrier2-3</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>113,076</td>
<td class='column-num_cols'>113,076</td>
<td class='column-nonzeros'>2,129,496</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/barrier2-3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/barrier2-3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/barrier2-3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>967</td>
<td class='column-name'><a href="/Schenk_ISEI/barrier2-4">barrier2-4</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>113,076</td>
<td class='column-num_cols'>113,076</td>
<td class='column-nonzeros'>2,129,496</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/barrier2-4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/barrier2-4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/barrier2-4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>968</td>
<td class='column-name'><a href="/Schenk_ISEI/barrier2-9">barrier2-9</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>115,625</td>
<td class='column-num_cols'>115,625</td>
<td class='column-nonzeros'>2,158,759</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/barrier2-9.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/barrier2-9.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/barrier2-9.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>969</td>
<td class='column-name'><a href="/Schenk_ISEI/igbt3">igbt3</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>10,938</td>
<td class='column-num_cols'>10,938</td>
<td class='column-nonzeros'>130,500</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/igbt3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/igbt3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/igbt3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>970</td>
<td class='column-name'><a href="/Schenk_ISEI/nmos3">nmos3</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>18,588</td>
<td class='column-num_cols'>18,588</td>
<td class='column-nonzeros'>237,130</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/nmos3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/nmos3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/nmos3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>971</td>
<td class='column-name'><a href="/Schenk_ISEI/ohne2">ohne2</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>181,343</td>
<td class='column-num_cols'>181,343</td>
<td class='column-nonzeros'>6,869,939</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/ohne2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/ohne2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/ohne2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>972</td>
<td class='column-name'><a href="/Schenk_ISEI/para-10">para-10</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>155,924</td>
<td class='column-num_cols'>155,924</td>
<td class='column-nonzeros'>2,094,873</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/para-10.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/para-10.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/para-10.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>973</td>
<td class='column-name'><a href="/Schenk_ISEI/para-4">para-4</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>153,226</td>
<td class='column-num_cols'>153,226</td>
<td class='column-nonzeros'>2,930,882</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/para-4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/para-4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/para-4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>974</td>
<td class='column-name'><a href="/Schenk_ISEI/para-5">para-5</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>155,924</td>
<td class='column-num_cols'>155,924</td>
<td class='column-nonzeros'>2,094,873</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/para-5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/para-5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/para-5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>975</td>
<td class='column-name'><a href="/Schenk_ISEI/para-6">para-6</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>155,924</td>
<td class='column-num_cols'>155,924</td>
<td class='column-nonzeros'>2,094,873</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/para-6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/para-6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/para-6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>976</td>
<td class='column-name'><a href="/Schenk_ISEI/para-7">para-7</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>155,924</td>
<td class='column-num_cols'>155,924</td>
<td class='column-nonzeros'>2,094,873</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/para-7.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/para-7.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/para-7.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>977</td>
<td class='column-name'><a href="/Schenk_ISEI/para-8">para-8</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>155,924</td>
<td class='column-num_cols'>155,924</td>
<td class='column-nonzeros'>2,094,873</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/para-8.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/para-8.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/para-8.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>978</td>
<td class='column-name'><a href="/Schenk_ISEI/para-9">para-9</a></td>
<td class='column-group'><a href="/Schenk_ISEI">Schenk_ISEI</a></td>
<td class='column-num_rows'>155,924</td>
<td class='column-num_cols'>155,924</td>
<td class='column-nonzeros'>2,094,873</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_ISEI/para-9.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_ISEI/para-9.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_ISEI/para-9.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>982</td>
<td class='column-name'><a href="/Tromble/language">language</a></td>
<td class='column-group'><a href="/Tromble">Tromble</a></td>
<td class='column-num_rows'>399,130</td>
<td class='column-num_cols'>399,130</td>
<td class='column-nonzeros'>1,216,334</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Tromble/language.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Tromble/language.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Tromble/language.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>983</td>
<td class='column-name'><a href="/Sanghavi/ecl32">ecl32</a></td>
<td class='column-group'><a href="/Sanghavi">Sanghavi</a></td>
<td class='column-num_rows'>51,993</td>
<td class='column-num_cols'>51,993</td>
<td class='column-nonzeros'>380,415</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sanghavi/ecl32.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sanghavi/ecl32.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sanghavi/ecl32.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1109</td>
<td class='column-name'><a href="/Sandia/mult_dcop_01">mult_dcop_01</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>25,187</td>
<td class='column-num_cols'>25,187</td>
<td class='column-nonzeros'>193,276</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/mult_dcop_01.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/mult_dcop_01.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/mult_dcop_01.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1110</td>
<td class='column-name'><a href="/Sandia/mult_dcop_02">mult_dcop_02</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>25,187</td>
<td class='column-num_cols'>25,187</td>
<td class='column-nonzeros'>193,276</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/mult_dcop_02.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/mult_dcop_02.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/mult_dcop_02.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1111</td>
<td class='column-name'><a href="/Sandia/mult_dcop_03">mult_dcop_03</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>25,187</td>
<td class='column-num_cols'>25,187</td>
<td class='column-nonzeros'>193,216</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/mult_dcop_03.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/mult_dcop_03.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/mult_dcop_03.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1201</td>
<td class='column-name'><a href="/Hamrle/Hamrle3">Hamrle3</a></td>
<td class='column-group'><a href="/Hamrle">Hamrle</a></td>
<td class='column-num_rows'>1,447,360</td>
<td class='column-num_cols'>1,447,360</td>
<td class='column-nonzeros'>5,514,242</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Hamrle/Hamrle3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Hamrle/Hamrle3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Hamrle/Hamrle3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1204</td>
<td class='column-name'><a href="/Oberwolfach/t2dah_a">t2dah_a</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>11,445</td>
<td class='column-num_cols'>11,445</td>
<td class='column-nonzeros'>176,117</td>
<td class='column-kind d-none d-md-table-cell'>Duplicate Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/t2dah_a.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/t2dah_a.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/t2dah_a.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1208</td>
<td class='column-name'><a href="/Oberwolfach/t3dh_a">t3dh_a</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>79,171</td>
<td class='column-num_cols'>79,171</td>
<td class='column-nonzeros'>4,352,105</td>
<td class='column-kind d-none d-md-table-cell'>Duplicate Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/t3dh_a.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/t3dh_a.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/t3dh_a.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1209</td>
<td class='column-name'><a href="/Oberwolfach/t3dh_e">t3dh_e</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>79,171</td>
<td class='column-num_cols'>79,171</td>
<td class='column-nonzeros'>4,352,105</td>
<td class='column-kind d-none d-md-table-cell'>Duplicate Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/t3dh_e.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/t3dh_e.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/t3dh_e.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1210</td>
<td class='column-name'><a href="/Oberwolfach/t3dl_a">t3dl_a</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>20,360</td>
<td class='column-num_cols'>20,360</td>
<td class='column-nonzeros'>509,866</td>
<td class='column-kind d-none d-md-table-cell'>Duplicate Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/t3dl_a.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/t3dl_a.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/t3dl_a.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1213</td>
<td class='column-name'><a href="/Lin/Lin">Lin</a></td>
<td class='column-group'><a href="/Lin">Lin</a></td>
<td class='column-num_rows'>256,000</td>
<td class='column-num_cols'>256,000</td>
<td class='column-nonzeros'>1,766,400</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Lin/Lin.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Lin/Lin.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Lin/Lin.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1218</td>
<td class='column-name'><a href="/GHS_indef/aug3dcqp">aug3dcqp</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>35,543</td>
<td class='column-num_cols'>35,543</td>
<td class='column-nonzeros'>128,115</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/aug3dcqp.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/aug3dcqp.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/aug3dcqp.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1219</td>
<td class='column-name'><a href="/GHS_indef/bmw3_2">bmw3_2</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>227,362</td>
<td class='column-num_cols'>227,362</td>
<td class='column-nonzeros'>11,288,630</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/bmw3_2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/bmw3_2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/bmw3_2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1220</td>
<td class='column-name'><a href="/GHS_indef/c-55">c-55</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>32,780</td>
<td class='column-num_cols'>32,780</td>
<td class='column-nonzeros'>403,450</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-55.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-55.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-55.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1221</td>
<td class='column-name'><a href="/GHS_indef/c-58">c-58</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>37,595</td>
<td class='column-num_cols'>37,595</td>
<td class='column-nonzeros'>552,551</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-58.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-58.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-58.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1222</td>
<td class='column-name'><a href="/GHS_indef/c-59">c-59</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>41,282</td>
<td class='column-num_cols'>41,282</td>
<td class='column-nonzeros'>480,536</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-59.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-59.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-59.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1223</td>
<td class='column-name'><a href="/GHS_indef/c-62ghs">c-62ghs</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>41,731</td>
<td class='column-num_cols'>41,731</td>
<td class='column-nonzeros'>559,339</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-62ghs.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-62ghs.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-62ghs.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1224</td>
<td class='column-name'><a href="/GHS_indef/c-63">c-63</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>44,234</td>
<td class='column-num_cols'>44,234</td>
<td class='column-nonzeros'>434,704</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-63.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-63.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-63.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1225</td>
<td class='column-name'><a href="/GHS_indef/c-68">c-68</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>64,810</td>
<td class='column-num_cols'>64,810</td>
<td class='column-nonzeros'>565,996</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-68.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-68.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-68.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1226</td>
<td class='column-name'><a href="/GHS_indef/c-69">c-69</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>67,458</td>
<td class='column-num_cols'>67,458</td>
<td class='column-nonzeros'>623,914</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-69.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-69.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-69.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1227</td>
<td class='column-name'><a href="/GHS_indef/c-70">c-70</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>68,924</td>
<td class='column-num_cols'>68,924</td>
<td class='column-nonzeros'>658,986</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-70.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-70.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-70.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1228</td>
<td class='column-name'><a href="/GHS_indef/c-71">c-71</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>76,638</td>
<td class='column-num_cols'>76,638</td>
<td class='column-nonzeros'>859,520</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-71.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-71.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-71.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1229</td>
<td class='column-name'><a href="/GHS_indef/c-72">c-72</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>84,064</td>
<td class='column-num_cols'>84,064</td>
<td class='column-nonzeros'>707,546</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/c-72.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/c-72.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/c-72.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1230</td>
<td class='column-name'><a href="/GHS_indef/copter2">copter2</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>55,476</td>
<td class='column-num_cols'>55,476</td>
<td class='column-nonzeros'>759,952</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/copter2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/copter2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/copter2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1231</td>
<td class='column-name'><a href="/GHS_indef/d_pretok">d_pretok</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>182,730</td>
<td class='column-num_cols'>182,730</td>
<td class='column-nonzeros'>1,641,672</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/d_pretok.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/d_pretok.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/d_pretok.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1232</td>
<td class='column-name'><a href="/GHS_indef/darcy003">darcy003</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>389,874</td>
<td class='column-num_cols'>389,874</td>
<td class='column-nonzeros'>2,097,566</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2002</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/darcy003.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/darcy003.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/darcy003.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1233</td>
<td class='column-name'><a href="/GHS_indef/dawson5">dawson5</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>51,537</td>
<td class='column-num_cols'>51,537</td>
<td class='column-nonzeros'>1,010,777</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/dawson5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/dawson5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/dawson5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1235</td>
<td class='column-name'><a href="/GHS_indef/exdata_1">exdata_1</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>6,001</td>
<td class='column-num_cols'>6,001</td>
<td class='column-nonzeros'>2,269,500</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/exdata_1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/exdata_1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/exdata_1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1236</td>
<td class='column-name'><a href="/GHS_indef/helm2d03">helm2d03</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>392,257</td>
<td class='column-num_cols'>392,257</td>
<td class='column-nonzeros'>2,741,935</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/helm2d03.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/helm2d03.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/helm2d03.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1237</td>
<td class='column-name'><a href="/GHS_indef/helm3d01">helm3d01</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>32,226</td>
<td class='column-num_cols'>32,226</td>
<td class='column-nonzeros'>428,444</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/helm3d01.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/helm3d01.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/helm3d01.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1238</td>
<td class='column-name'><a href="/GHS_indef/k1_san">k1_san</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>67,759</td>
<td class='column-num_cols'>67,759</td>
<td class='column-nonzeros'>559,774</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/k1_san.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/k1_san.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/k1_san.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1240</td>
<td class='column-name'><a href="/GHS_indef/mario001">mario001</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>38,434</td>
<td class='column-num_cols'>38,434</td>
<td class='column-nonzeros'>204,912</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/mario001.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/mario001.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/mario001.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1241</td>
<td class='column-name'><a href="/GHS_indef/mario002">mario002</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>389,874</td>
<td class='column-num_cols'>389,874</td>
<td class='column-nonzeros'>2,097,566</td>
<td class='column-kind d-none d-md-table-cell'>Duplicate 2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/mario002.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/mario002.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/mario002.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1244</td>
<td class='column-name'><a href="/GHS_indef/olesnik0">olesnik0</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>88,263</td>
<td class='column-num_cols'>88,263</td>
<td class='column-nonzeros'>744,216</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/olesnik0.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/olesnik0.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/olesnik0.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1246</td>
<td class='column-name'><a href="/GHS_indef/stokes128">stokes128</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>49,666</td>
<td class='column-num_cols'>49,666</td>
<td class='column-nonzeros'>558,594</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/stokes128.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/stokes128.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/stokes128.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1247</td>
<td class='column-name'><a href="/GHS_indef/stokes64">stokes64</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>12,546</td>
<td class='column-num_cols'>12,546</td>
<td class='column-nonzeros'>140,034</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/stokes64.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/stokes64.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/stokes64.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1248</td>
<td class='column-name'><a href="/GHS_indef/stokes64s">stokes64s</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>12,546</td>
<td class='column-num_cols'>12,546</td>
<td class='column-nonzeros'>140,034</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/stokes64s.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/stokes64s.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/stokes64s.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1251</td>
<td class='column-name'><a href="/GHS_indef/turon_m">turon_m</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>189,924</td>
<td class='column-num_cols'>189,924</td>
<td class='column-nonzeros'>1,690,876</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/turon_m.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/turon_m.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/turon_m.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1291</td>
<td class='column-name'><a href="/GHS_indef/a0nsdsil">a0nsdsil</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>80,016</td>
<td class='column-num_cols'>80,016</td>
<td class='column-nonzeros'>355,034</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/a0nsdsil.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/a0nsdsil.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/a0nsdsil.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1292</td>
<td class='column-name'><a href="/GHS_indef/a2nnsnsl">a2nnsnsl</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>80,016</td>
<td class='column-num_cols'>80,016</td>
<td class='column-nonzeros'>347,222</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/a2nnsnsl.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/a2nnsnsl.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/a2nnsnsl.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1293</td>
<td class='column-name'><a href="/GHS_indef/a5esindl">a5esindl</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>60,008</td>
<td class='column-num_cols'>60,008</td>
<td class='column-nonzeros'>255,004</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/a5esindl.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/a5esindl.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/a5esindl.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1294</td>
<td class='column-name'><a href="/GHS_indef/blockqp1">blockqp1</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>60,012</td>
<td class='column-num_cols'>60,012</td>
<td class='column-nonzeros'>640,033</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/blockqp1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/blockqp1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/blockqp1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1295</td>
<td class='column-name'><a href="/GHS_indef/bloweya">bloweya</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>30,004</td>
<td class='column-num_cols'>30,004</td>
<td class='column-nonzeros'>150,009</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>1992</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/bloweya.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/bloweya.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/bloweya.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1296</td>
<td class='column-name'><a href="/GHS_indef/boyd1">boyd1</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>93,279</td>
<td class='column-num_cols'>93,279</td>
<td class='column-nonzeros'>1,211,231</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/boyd1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/boyd1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/boyd1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1297</td>
<td class='column-name'><a href="/GHS_indef/boyd2">boyd2</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>466,316</td>
<td class='column-num_cols'>466,316</td>
<td class='column-nonzeros'>1,500,397</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/boyd2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/boyd2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/boyd2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1298</td>
<td class='column-name'><a href="/GHS_indef/brainpc2">brainpc2</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>27,607</td>
<td class='column-num_cols'>27,607</td>
<td class='column-nonzeros'>179,395</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/brainpc2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/brainpc2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/brainpc2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1299</td>
<td class='column-name'><a href="/GHS_indef/bratu3d">bratu3d</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>27,792</td>
<td class='column-num_cols'>27,792</td>
<td class='column-nonzeros'>173,796</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>1989</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/bratu3d.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/bratu3d.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/bratu3d.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1300</td>
<td class='column-name'><a href="/GHS_indef/cont-201">cont-201</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>80,595</td>
<td class='column-num_cols'>80,595</td>
<td class='column-nonzeros'>438,795</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/cont-201.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/cont-201.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/cont-201.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1301</td>
<td class='column-name'><a href="/GHS_indef/cont-300">cont-300</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>180,895</td>
<td class='column-num_cols'>180,895</td>
<td class='column-nonzeros'>988,195</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/cont-300.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/cont-300.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/cont-300.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1302</td>
<td class='column-name'><a href="/GHS_indef/dixmaanl">dixmaanl</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>60,000</td>
<td class='column-num_cols'>60,000</td>
<td class='column-nonzeros'>299,998</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>1989</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/dixmaanl.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/dixmaanl.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/dixmaanl.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1304</td>
<td class='column-name'><a href="/GHS_indef/ncvxbqp1">ncvxbqp1</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>50,000</td>
<td class='column-num_cols'>50,000</td>
<td class='column-nonzeros'>349,968</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/ncvxbqp1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/ncvxbqp1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/ncvxbqp1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1305</td>
<td class='column-name'><a href="/GHS_indef/ncvxqp3">ncvxqp3</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>75,000</td>
<td class='column-num_cols'>75,000</td>
<td class='column-nonzeros'>499,964</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/ncvxqp3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/ncvxqp3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/ncvxqp3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1306</td>
<td class='column-name'><a href="/GHS_indef/ncvxqp5">ncvxqp5</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>62,500</td>
<td class='column-num_cols'>62,500</td>
<td class='column-nonzeros'>424,966</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/ncvxqp5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/ncvxqp5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/ncvxqp5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1307</td>
<td class='column-name'><a href="/GHS_indef/ncvxqp7">ncvxqp7</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>87,500</td>
<td class='column-num_cols'>87,500</td>
<td class='column-nonzeros'>574,962</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/ncvxqp7.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/ncvxqp7.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/ncvxqp7.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1308</td>
<td class='column-name'><a href="/GHS_indef/sparsine">sparsine</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>50,000</td>
<td class='column-num_cols'>50,000</td>
<td class='column-nonzeros'>1,548,988</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/sparsine.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/sparsine.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/sparsine.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1309</td>
<td class='column-name'><a href="/GHS_indef/spmsrtls">spmsrtls</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>29,995</td>
<td class='column-num_cols'>29,995</td>
<td class='column-nonzeros'>229,947</td>
<td class='column-kind d-none d-md-table-cell'>Statistical/Mathematical Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/spmsrtls.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/spmsrtls.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/spmsrtls.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1316</td>
<td class='column-name'><a href="/Rajat/rajat15">rajat15</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>37,261</td>
<td class='column-num_cols'>37,261</td>
<td class='column-nonzeros'>443,573</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat15.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat15.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat15.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1319</td>
<td class='column-name'><a href="/Engwirda/airfoil_2d">airfoil_2d</a></td>
<td class='column-group'><a href="/Engwirda">Engwirda</a></td>
<td class='column-num_rows'>14,214</td>
<td class='column-num_cols'>14,214</td>
<td class='column-nonzeros'>259,688</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Engwirda/airfoil_2d.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Engwirda/airfoil_2d.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Engwirda/airfoil_2d.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1320</td>
<td class='column-name'><a href="/IBM_EDA/dc1">dc1</a></td>
<td class='column-group'><a href="/IBM_EDA">IBM_EDA</a></td>
<td class='column-num_rows'>116,835</td>
<td class='column-num_cols'>116,835</td>
<td class='column-nonzeros'>766,396</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IBM_EDA/dc1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IBM_EDA/dc1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IBM_EDA/dc1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1321</td>
<td class='column-name'><a href="/IBM_EDA/dc2">dc2</a></td>
<td class='column-group'><a href="/IBM_EDA">IBM_EDA</a></td>
<td class='column-num_rows'>116,835</td>
<td class='column-num_cols'>116,835</td>
<td class='column-nonzeros'>766,396</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IBM_EDA/dc2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IBM_EDA/dc2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IBM_EDA/dc2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1322</td>
<td class='column-name'><a href="/IBM_EDA/dc3">dc3</a></td>
<td class='column-group'><a href="/IBM_EDA">IBM_EDA</a></td>
<td class='column-num_rows'>116,835</td>
<td class='column-num_cols'>116,835</td>
<td class='column-nonzeros'>766,396</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IBM_EDA/dc3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IBM_EDA/dc3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IBM_EDA/dc3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1323</td>
<td class='column-name'><a href="/IBM_EDA/trans4">trans4</a></td>
<td class='column-group'><a href="/IBM_EDA">IBM_EDA</a></td>
<td class='column-num_rows'>116,835</td>
<td class='column-num_cols'>116,835</td>
<td class='column-nonzeros'>749,800</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IBM_EDA/trans4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IBM_EDA/trans4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IBM_EDA/trans4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1324</td>
<td class='column-name'><a href="/IBM_EDA/trans5">trans5</a></td>
<td class='column-group'><a href="/IBM_EDA">IBM_EDA</a></td>
<td class='column-num_rows'>116,835</td>
<td class='column-num_cols'>116,835</td>
<td class='column-nonzeros'>749,800</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IBM_EDA/trans5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IBM_EDA/trans5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IBM_EDA/trans5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1333</td>
<td class='column-name'><a href="/VanVelzen/std1_Jac2_db">std1_Jac2_db</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>21,982</td>
<td class='column-num_cols'>21,982</td>
<td class='column-nonzeros'>498,771</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/std1_Jac2_db.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/std1_Jac2_db.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/std1_Jac2_db.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1334</td>
<td class='column-name'><a href="/VanVelzen/std1_Jac2">std1_Jac2</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>21,982</td>
<td class='column-num_cols'>21,982</td>
<td class='column-nonzeros'>1,248,213</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/std1_Jac2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/std1_Jac2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/std1_Jac2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1335</td>
<td class='column-name'><a href="/VanVelzen/std1_Jac3_db">std1_Jac3_db</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>21,982</td>
<td class='column-num_cols'>21,982</td>
<td class='column-nonzeros'>531,826</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/std1_Jac3_db.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/std1_Jac3_db.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/std1_Jac3_db.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1336</td>
<td class='column-name'><a href="/VanVelzen/std1_Jac3">std1_Jac3</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>21,982</td>
<td class='column-num_cols'>21,982</td>
<td class='column-nonzeros'>1,455,374</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/std1_Jac3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/std1_Jac3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/std1_Jac3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1337</td>
<td class='column-name'><a href="/VanVelzen/Zd_Jac2_db">Zd_Jac2_db</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>22,835</td>
<td class='column-num_cols'>22,835</td>
<td class='column-nonzeros'>676,439</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/Zd_Jac2_db.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/Zd_Jac2_db.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/Zd_Jac2_db.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1338</td>
<td class='column-name'><a href="/VanVelzen/Zd_Jac2">Zd_Jac2</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>22,835</td>
<td class='column-num_cols'>22,835</td>
<td class='column-nonzeros'>1,642,407</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/Zd_Jac2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/Zd_Jac2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/Zd_Jac2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1339</td>
<td class='column-name'><a href="/VanVelzen/Zd_Jac3_db">Zd_Jac3_db</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>22,835</td>
<td class='column-num_cols'>22,835</td>
<td class='column-nonzeros'>713,907</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/Zd_Jac3_db.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/Zd_Jac3_db.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/Zd_Jac3_db.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1340</td>
<td class='column-name'><a href="/VanVelzen/Zd_Jac3">Zd_Jac3</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>22,835</td>
<td class='column-num_cols'>22,835</td>
<td class='column-nonzeros'>1,915,726</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/Zd_Jac3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/Zd_Jac3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/Zd_Jac3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1341</td>
<td class='column-name'><a href="/VanVelzen/Zd_Jac6_db">Zd_Jac6_db</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>22,835</td>
<td class='column-num_cols'>22,835</td>
<td class='column-nonzeros'>663,643</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/Zd_Jac6_db.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/Zd_Jac6_db.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/Zd_Jac6_db.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1342</td>
<td class='column-name'><a href="/VanVelzen/Zd_Jac6">Zd_Jac6</a></td>
<td class='column-group'><a href="/VanVelzen">VanVelzen</a></td>
<td class='column-num_rows'>22,835</td>
<td class='column-num_cols'>22,835</td>
<td class='column-nonzeros'>1,711,557</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Process Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VanVelzen/Zd_Jac6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VanVelzen/Zd_Jac6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VanVelzen/Zd_Jac6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1343</td>
<td class='column-name'><a href="/Rajat/rajat16">rajat16</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>94,294</td>
<td class='column-num_cols'>94,294</td>
<td class='column-nonzeros'>476,766</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat16.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat16.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat16.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1344</td>
<td class='column-name'><a href="/Rajat/rajat17">rajat17</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>94,294</td>
<td class='column-num_cols'>94,294</td>
<td class='column-nonzeros'>479,246</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat17.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat17.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat17.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1345</td>
<td class='column-name'><a href="/Rajat/rajat18">rajat18</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>94,294</td>
<td class='column-num_cols'>94,294</td>
<td class='column-nonzeros'>479,151</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat18.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat18.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat18.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1348</td>
<td class='column-name'><a href="/PARSEC/benzene">benzene</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>8,219</td>
<td class='column-num_cols'>8,219</td>
<td class='column-nonzeros'>242,669</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/benzene.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/benzene.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/benzene.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1349</td>
<td class='column-name'><a href="/PARSEC/CO">CO</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>221,119</td>
<td class='column-num_cols'>221,119</td>
<td class='column-nonzeros'>7,666,057</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/CO.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/CO.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/CO.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1350</td>
<td class='column-name'><a href="/PARSEC/Ga10As10H30">Ga10As10H30</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>113,081</td>
<td class='column-num_cols'>113,081</td>
<td class='column-nonzeros'>6,115,633</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Ga10As10H30.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Ga10As10H30.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Ga10As10H30.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1351</td>
<td class='column-name'><a href="/PARSEC/Ga19As19H42">Ga19As19H42</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>133,123</td>
<td class='column-num_cols'>133,123</td>
<td class='column-nonzeros'>8,884,839</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Ga19As19H42.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Ga19As19H42.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Ga19As19H42.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1352</td>
<td class='column-name'><a href="/PARSEC/Ga3As3H12">Ga3As3H12</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>61,349</td>
<td class='column-num_cols'>61,349</td>
<td class='column-nonzeros'>5,970,947</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Ga3As3H12.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Ga3As3H12.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Ga3As3H12.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1353</td>
<td class='column-name'><a href="/PARSEC/Ga41As41H72">Ga41As41H72</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>268,096</td>
<td class='column-num_cols'>268,096</td>
<td class='column-nonzeros'>18,488,476</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Ga41As41H72.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Ga41As41H72.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Ga41As41H72.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1354</td>
<td class='column-name'><a href="/PARSEC/GaAsH6">GaAsH6</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>61,349</td>
<td class='column-num_cols'>61,349</td>
<td class='column-nonzeros'>3,381,809</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/GaAsH6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/GaAsH6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/GaAsH6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1355</td>
<td class='column-name'><a href="/PARSEC/Ge87H76">Ge87H76</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>112,985</td>
<td class='column-num_cols'>112,985</td>
<td class='column-nonzeros'>7,892,195</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Ge87H76.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Ge87H76.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Ge87H76.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1356</td>
<td class='column-name'><a href="/PARSEC/Ge99H100">Ge99H100</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>112,985</td>
<td class='column-num_cols'>112,985</td>
<td class='column-nonzeros'>8,451,395</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Ge99H100.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Ge99H100.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Ge99H100.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1357</td>
<td class='column-name'><a href="/PARSEC/H2O">H2O</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>67,024</td>
<td class='column-num_cols'>67,024</td>
<td class='column-nonzeros'>2,216,736</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/H2O.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/H2O.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/H2O.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1358</td>
<td class='column-name'><a href="/PARSEC/Na5">Na5</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>5,832</td>
<td class='column-num_cols'>5,832</td>
<td class='column-nonzeros'>305,630</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Na5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Na5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Na5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1359</td>
<td class='column-name'><a href="/PARSEC/Si10H16">Si10H16</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>17,077</td>
<td class='column-num_cols'>17,077</td>
<td class='column-nonzeros'>875,923</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Si10H16.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Si10H16.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Si10H16.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1361</td>
<td class='column-name'><a href="/PARSEC/Si34H36">Si34H36</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>97,569</td>
<td class='column-num_cols'>97,569</td>
<td class='column-nonzeros'>5,156,379</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Si34H36.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Si34H36.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Si34H36.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1362</td>
<td class='column-name'><a href="/PARSEC/Si41Ge41H72">Si41Ge41H72</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>185,639</td>
<td class='column-num_cols'>185,639</td>
<td class='column-nonzeros'>15,011,265</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Si41Ge41H72.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Si41Ge41H72.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Si41Ge41H72.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1363</td>
<td class='column-name'><a href="/PARSEC/Si5H12">Si5H12</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>19,896</td>
<td class='column-num_cols'>19,896</td>
<td class='column-nonzeros'>738,598</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Si5H12.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Si5H12.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Si5H12.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1364</td>
<td class='column-name'><a href="/PARSEC/Si87H76">Si87H76</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>240,369</td>
<td class='column-num_cols'>240,369</td>
<td class='column-nonzeros'>10,661,631</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/Si87H76.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/Si87H76.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/Si87H76.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1365</td>
<td class='column-name'><a href="/PARSEC/SiH4">SiH4</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>5,041</td>
<td class='column-num_cols'>5,041</td>
<td class='column-nonzeros'>171,903</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/SiH4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/SiH4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/SiH4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1366</td>
<td class='column-name'><a href="/PARSEC/SiNa">SiNa</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>5,743</td>
<td class='column-num_cols'>5,743</td>
<td class='column-nonzeros'>198,787</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/SiNa.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/SiNa.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/SiNa.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1367</td>
<td class='column-name'><a href="/PARSEC/SiO2">SiO2</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>155,331</td>
<td class='column-num_cols'>155,331</td>
<td class='column-nonzeros'>11,283,503</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/SiO2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/SiO2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/SiO2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1368</td>
<td class='column-name'><a href="/PARSEC/SiO">SiO</a></td>
<td class='column-group'><a href="/PARSEC">PARSEC</a></td>
<td class='column-num_rows'>33,401</td>
<td class='column-num_cols'>33,401</td>
<td class='column-nonzeros'>1,317,655</td>
<td class='column-kind d-none d-md-table-cell'>Theoretical/Quantum Chemistry Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PARSEC/SiO.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PARSEC/SiO.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PARSEC/SiO.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1369</td>
<td class='column-name'><a href="/Rajat/rajat20">rajat20</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>86,916</td>
<td class='column-num_cols'>86,916</td>
<td class='column-nonzeros'>604,299</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat20.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat20.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat20.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1370</td>
<td class='column-name'><a href="/Rajat/rajat21">rajat21</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>411,676</td>
<td class='column-num_cols'>411,676</td>
<td class='column-nonzeros'>1,876,011</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat21.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat21.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat21.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1371</td>
<td class='column-name'><a href="/Rajat/rajat22">rajat22</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>39,899</td>
<td class='column-num_cols'>39,899</td>
<td class='column-nonzeros'>195,429</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat22.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat22.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat22.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1372</td>
<td class='column-name'><a href="/Rajat/rajat23">rajat23</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>110,355</td>
<td class='column-num_cols'>110,355</td>
<td class='column-nonzeros'>555,441</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat23.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat23.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat23.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1373</td>
<td class='column-name'><a href="/Rajat/rajat24">rajat24</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>358,172</td>
<td class='column-num_cols'>358,172</td>
<td class='column-nonzeros'>1,946,979</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat24.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat24.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat24.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1374</td>
<td class='column-name'><a href="/Rajat/rajat25">rajat25</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>87,190</td>
<td class='column-num_cols'>87,190</td>
<td class='column-nonzeros'>606,489</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat25.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat25.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat25.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1375</td>
<td class='column-name'><a href="/Rajat/rajat26">rajat26</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>51,032</td>
<td class='column-num_cols'>51,032</td>
<td class='column-nonzeros'>247,528</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat26.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat26.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat26.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1377</td>
<td class='column-name'><a href="/Rajat/rajat28">rajat28</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>87,190</td>
<td class='column-num_cols'>87,190</td>
<td class='column-nonzeros'>606,489</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat28.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat28.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat28.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1395</td>
<td class='column-name'><a href="/MKS/fp">fp</a></td>
<td class='column-group'><a href="/MKS">MKS</a></td>
<td class='column-num_rows'>7,548</td>
<td class='column-num_cols'>7,548</td>
<td class='column-nonzeros'>834,222</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/MKS/fp.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/MKS/fp.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/MKS/fp.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1396</td>
<td class='column-name'><a href="/Rajat/rajat29">rajat29</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>643,994</td>
<td class='column-num_cols'>643,994</td>
<td class='column-nonzeros'>3,760,246</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat29.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat29.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat29.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1397</td>
<td class='column-name'><a href="/Rajat/rajat30">rajat30</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>643,994</td>
<td class='column-num_cols'>643,994</td>
<td class='column-nonzeros'>6,175,244</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat30.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat30.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat30.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1398</td>
<td class='column-name'><a href="/Rajat/rajat31">rajat31</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>4,690,002</td>
<td class='column-num_cols'>4,690,002</td>
<td class='column-nonzeros'>20,316,253</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/rajat31.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/rajat31.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/rajat31.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1399</td>
<td class='column-name'><a href="/Raju/laminar_duct3D">laminar_duct3D</a></td>
<td class='column-group'><a href="/Raju">Raju</a></td>
<td class='column-num_rows'>67,173</td>
<td class='column-num_cols'>67,173</td>
<td class='column-nonzeros'>3,788,857</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Raju/laminar_duct3D.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Raju/laminar_duct3D.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Raju/laminar_duct3D.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1405</td>
<td class='column-name'><a href="/Bindel/ted_A">ted_A</a></td>
<td class='column-group'><a href="/Bindel">Bindel</a></td>
<td class='column-num_rows'>10,605</td>
<td class='column-num_cols'>10,605</td>
<td class='column-nonzeros'>424,587</td>
<td class='column-kind d-none d-md-table-cell'>Thermal Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bindel/ted_A.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bindel/ted_A.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bindel/ted_A.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1408</td>
<td class='column-name'><a href="/Bindel/ted_A_unscaled">ted_A_unscaled</a></td>
<td class='column-group'><a href="/Bindel">Bindel</a></td>
<td class='column-num_rows'>10,605</td>
<td class='column-num_cols'>10,605</td>
<td class='column-nonzeros'>424,587</td>
<td class='column-kind d-none d-md-table-cell'>Thermal Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bindel/ted_A_unscaled.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bindel/ted_A_unscaled.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bindel/ted_A_unscaled.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1411</td>
<td class='column-name'><a href="/Koutsovasilis/F1">F1</a></td>
<td class='column-group'><a href="/Koutsovasilis">Koutsovasilis</a></td>
<td class='column-num_rows'>343,791</td>
<td class='column-num_cols'>343,791</td>
<td class='column-nonzeros'>26,837,113</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Koutsovasilis/F1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Koutsovasilis/F1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Koutsovasilis/F1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1413</td>
<td class='column-name'><a href="/IBM_EDA/ckt11752_dc_1">ckt11752_dc_1</a></td>
<td class='column-group'><a href="/IBM_EDA">IBM_EDA</a></td>
<td class='column-num_rows'>49,702</td>
<td class='column-num_cols'>49,702</td>
<td class='column-nonzeros'>333,029</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IBM_EDA/ckt11752_dc_1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IBM_EDA/ckt11752_dc_1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IBM_EDA/ckt11752_dc_1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1414</td>
<td class='column-name'><a href="/IBM_EDA/ckt11752_tr_0">ckt11752_tr_0</a></td>
<td class='column-group'><a href="/IBM_EDA">IBM_EDA</a></td>
<td class='column-num_rows'>49,702</td>
<td class='column-num_cols'>49,702</td>
<td class='column-nonzeros'>332,807</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IBM_EDA/ckt11752_tr_0.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IBM_EDA/ckt11752_tr_0.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IBM_EDA/ckt11752_tr_0.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1415</td>
<td class='column-name'><a href="/Sandia/ASIC_100k">ASIC_100k</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>99,340</td>
<td class='column-num_cols'>99,340</td>
<td class='column-nonzeros'>940,621</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/ASIC_100k.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/ASIC_100k.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/ASIC_100k.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1416</td>
<td class='column-name'><a href="/Sandia/ASIC_100ks">ASIC_100ks</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>99,190</td>
<td class='column-num_cols'>99,190</td>
<td class='column-nonzeros'>578,890</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/ASIC_100ks.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/ASIC_100ks.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/ASIC_100ks.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1417</td>
<td class='column-name'><a href="/Sandia/ASIC_320k">ASIC_320k</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>321,821</td>
<td class='column-num_cols'>321,821</td>
<td class='column-nonzeros'>1,931,828</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/ASIC_320k.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/ASIC_320k.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/ASIC_320k.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1418</td>
<td class='column-name'><a href="/Sandia/ASIC_320ks">ASIC_320ks</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>321,671</td>
<td class='column-num_cols'>321,671</td>
<td class='column-nonzeros'>1,316,085</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/ASIC_320ks.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/ASIC_320ks.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/ASIC_320ks.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1419</td>
<td class='column-name'><a href="/Sandia/ASIC_680k">ASIC_680k</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>682,862</td>
<td class='column-num_cols'>682,862</td>
<td class='column-nonzeros'>2,638,997</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/ASIC_680k.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/ASIC_680k.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/ASIC_680k.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1420</td>
<td class='column-name'><a href="/Sandia/ASIC_680ks">ASIC_680ks</a></td>
<td class='column-group'><a href="/Sandia">Sandia</a></td>
<td class='column-num_rows'>682,712</td>
<td class='column-num_cols'>682,712</td>
<td class='column-nonzeros'>1,693,767</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sandia/ASIC_680ks.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sandia/ASIC_680ks.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sandia/ASIC_680ks.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1424</td>
<td class='column-name'><a href="/GHS_indef/bloweybl">bloweybl</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>30,003</td>
<td class='column-num_cols'>30,003</td>
<td class='column-nonzeros'>109,999</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>1992</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/bloweybl.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/bloweybl.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/bloweybl.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1426</td>
<td class='column-name'><a href="/GHS_indef/cvxqp3">cvxqp3</a></td>
<td class='column-group'><a href="/GHS_indef">GHS_indef</a></td>
<td class='column-num_rows'>17,500</td>
<td class='column-num_cols'>17,500</td>
<td class='column-nonzeros'>114,962</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>1995</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/GHS_indef/cvxqp3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/GHS_indef/cvxqp3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/GHS_indef/cvxqp3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1428</td>
<td class='column-name'><a href="/Oberwolfach/chipcool0">chipcool0</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>20,082</td>
<td class='column-num_cols'>20,082</td>
<td class='column-nonzeros'>281,150</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/chipcool0.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/chipcool0.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/chipcool0.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1429</td>
<td class='column-name'><a href="/Oberwolfach/chipcool1">chipcool1</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>20,082</td>
<td class='column-num_cols'>20,082</td>
<td class='column-nonzeros'>281,150</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/chipcool1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/chipcool1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/chipcool1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1431</td>
<td class='column-name'><a href="/Oberwolfach/filter3D">filter3D</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>106,437</td>
<td class='column-num_cols'>106,437</td>
<td class='column-nonzeros'>2,707,179</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/filter3D.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/filter3D.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/filter3D.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1434</td>
<td class='column-name'><a href="/Oberwolfach/gas_sensor">gas_sensor</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>66,917</td>
<td class='column-num_cols'>66,917</td>
<td class='column-nonzeros'>1,703,365</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/gas_sensor.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/gas_sensor.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/gas_sensor.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1436</td>
<td class='column-name'><a href="/Oberwolfach/inlet">inlet</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>11,730</td>
<td class='column-num_cols'>11,730</td>
<td class='column-nonzeros'>328,323</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/inlet.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/inlet.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/inlet.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1441</td>
<td class='column-name'><a href="/Oberwolfach/piston">piston</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>2,025</td>
<td class='column-num_cols'>2,025</td>
<td class='column-nonzeros'>100,015</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/piston.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/piston.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/piston.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1443</td>
<td class='column-name'><a href="/Oberwolfach/rail_20209">rail_20209</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>20,209</td>
<td class='column-num_cols'>20,209</td>
<td class='column-nonzeros'>139,233</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2002</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/rail_20209.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/rail_20209.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/rail_20209.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1445</td>
<td class='column-name'><a href="/Oberwolfach/rail_79841">rail_79841</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>79,841</td>
<td class='column-num_cols'>79,841</td>
<td class='column-nonzeros'>553,921</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2002</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/rail_79841.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/rail_79841.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/rail_79841.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1447</td>
<td class='column-name'><a href="/Oberwolfach/t2dah">t2dah</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>11,445</td>
<td class='column-num_cols'>11,445</td>
<td class='column-nonzeros'>176,117</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/t2dah.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/t2dah.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/t2dah.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1450</td>
<td class='column-name'><a href="/Oberwolfach/t3dh">t3dh</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>79,171</td>
<td class='column-num_cols'>79,171</td>
<td class='column-nonzeros'>4,352,105</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/t3dh.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/t3dh.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/t3dh.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1451</td>
<td class='column-name'><a href="/Oberwolfach/t3dl">t3dl</a></td>
<td class='column-group'><a href="/Oberwolfach">Oberwolfach</a></td>
<td class='column-num_rows'>20,360</td>
<td class='column-num_cols'>20,360</td>
<td class='column-nonzeros'>509,866</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2004</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Oberwolfach/t3dl.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Oberwolfach/t3dl.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Oberwolfach/t3dl.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1513</td>
<td class='column-name'><a href="/Pajek/patents_main">patents_main</a></td>
<td class='column-group'><a href="/Pajek">Pajek</a></td>
<td class='column-num_rows'>240,547</td>
<td class='column-num_cols'>240,547</td>
<td class='column-nonzeros'>560,943</td>
<td class='column-kind d-none d-md-table-cell'>Directed Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Pajek/patents_main.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Pajek/patents_main.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Pajek/patents_main.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1558</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-39">c-39</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>9,271</td>
<td class='column-num_cols'>9,271</td>
<td class='column-nonzeros'>116,587</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-39.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-39.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-39.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1560</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-41">c-41</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>9,769</td>
<td class='column-num_cols'>9,769</td>
<td class='column-nonzeros'>101,635</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-41.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-41.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-41.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1561</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-42">c-42</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>10,471</td>
<td class='column-num_cols'>10,471</td>
<td class='column-nonzeros'>110,285</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-42.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-42.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-42.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1562</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-43">c-43</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>11,125</td>
<td class='column-num_cols'>11,125</td>
<td class='column-nonzeros'>123,659</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-43.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-43.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-43.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1564</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-45">c-45</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>13,206</td>
<td class='column-num_cols'>13,206</td>
<td class='column-nonzeros'>174,452</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-45.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-45.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-45.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1565</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-46">c-46</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>14,913</td>
<td class='column-num_cols'>14,913</td>
<td class='column-nonzeros'>130,397</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-46.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-46.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-46.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1566</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-47">c-47</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>15,343</td>
<td class='column-num_cols'>15,343</td>
<td class='column-nonzeros'>211,401</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-47.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-47.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-47.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1567</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-48">c-48</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>18,354</td>
<td class='column-num_cols'>18,354</td>
<td class='column-nonzeros'>166,080</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-48.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-48.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-48.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1568</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-49">c-49</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>21,132</td>
<td class='column-num_cols'>21,132</td>
<td class='column-nonzeros'>157,040</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-49.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-49.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-49.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1569</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-50">c-50</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>22,401</td>
<td class='column-num_cols'>22,401</td>
<td class='column-nonzeros'>180,245</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-50.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-50.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-50.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1570</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-51">c-51</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>23,196</td>
<td class='column-num_cols'>23,196</td>
<td class='column-nonzeros'>203,048</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-51.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-51.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-51.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1571</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-52">c-52</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>23,948</td>
<td class='column-num_cols'>23,948</td>
<td class='column-nonzeros'>202,708</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-52.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-52.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-52.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1572</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-53">c-53</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>30,235</td>
<td class='column-num_cols'>30,235</td>
<td class='column-nonzeros'>355,139</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-53.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-53.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-53.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1573</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-54">c-54</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>31,793</td>
<td class='column-num_cols'>31,793</td>
<td class='column-nonzeros'>385,987</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-54.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-54.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-54.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1574</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-56">c-56</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>35,910</td>
<td class='column-num_cols'>35,910</td>
<td class='column-nonzeros'>380,240</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-56.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-56.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-56.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1575</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-57">c-57</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>37,833</td>
<td class='column-num_cols'>37,833</td>
<td class='column-nonzeros'>403,373</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-57.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-57.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-57.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1576</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-60">c-60</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>43,640</td>
<td class='column-num_cols'>43,640</td>
<td class='column-nonzeros'>298,570</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-60.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-60.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-60.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1577</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-61">c-61</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>43,618</td>
<td class='column-num_cols'>43,618</td>
<td class='column-nonzeros'>310,016</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-61.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-61.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-61.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1578</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-65">c-65</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>48,066</td>
<td class='column-num_cols'>48,066</td>
<td class='column-nonzeros'>360,428</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-65.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-65.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-65.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1579</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-big">c-big</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>345,241</td>
<td class='column-num_cols'>345,241</td>
<td class='column-nonzeros'>2,340,859</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-big.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-big.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-big.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1586</td>
<td class='column-name'><a href="/Schenk_AFE/af_shell10">af_shell10</a></td>
<td class='column-group'><a href="/Schenk_AFE">Schenk_AFE</a></td>
<td class='column-num_rows'>1,508,065</td>
<td class='column-num_cols'>1,508,065</td>
<td class='column-nonzeros'>52,259,885</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_AFE/af_shell10.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_AFE/af_shell10.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_AFE/af_shell10.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1587</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-64b">c-64b</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>51,035</td>
<td class='column-num_cols'>51,035</td>
<td class='column-nonzeros'>707,601</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-64b.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-64b.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-64b.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1588</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-66b">c-66b</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>49,989</td>
<td class='column-num_cols'>49,989</td>
<td class='column-nonzeros'>444,851</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-66b.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-66b.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-66b.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1589</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-67b">c-67b</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>57,975</td>
<td class='column-num_cols'>57,975</td>
<td class='column-nonzeros'>530,583</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-67b.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-67b.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-67b.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1590</td>
<td class='column-name'><a href="/Schenk_IBMNA/c-73b">c-73b</a></td>
<td class='column-group'><a href="/Schenk_IBMNA">Schenk_IBMNA</a></td>
<td class='column-num_rows'>169,422</td>
<td class='column-num_cols'>169,422</td>
<td class='column-nonzeros'>1,279,274</td>
<td class='column-kind d-none d-md-table-cell'>Subsequent Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2006</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk_IBMNA/c-73b.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk_IBMNA/c-73b.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk_IBMNA/c-73b.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1624</td>
<td class='column-name'><a href="/Bai/mhd4800a">mhd4800a</a></td>
<td class='column-group'><a href="/Bai">Bai</a></td>
<td class='column-num_rows'>4,800</td>
<td class='column-num_cols'>4,800</td>
<td class='column-nonzeros'>102,252</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>1994</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bai/mhd4800a.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bai/mhd4800a.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bai/mhd4800a.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1642</td>
<td class='column-name'><a href="/POLYFLOW/invextr1_new">invextr1_new</a></td>
<td class='column-group'><a href="/POLYFLOW">POLYFLOW</a></td>
<td class='column-num_rows'>30,412</td>
<td class='column-num_cols'>30,412</td>
<td class='column-nonzeros'>1,793,881</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/POLYFLOW/invextr1_new.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/POLYFLOW/invextr1_new.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/POLYFLOW/invextr1_new.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1643</td>
<td class='column-name'><a href="/POLYFLOW/mixtank_new">mixtank_new</a></td>
<td class='column-group'><a href="/POLYFLOW">POLYFLOW</a></td>
<td class='column-num_rows'>29,957</td>
<td class='column-num_cols'>29,957</td>
<td class='column-nonzeros'>1,990,919</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/POLYFLOW/mixtank_new.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/POLYFLOW/mixtank_new.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/POLYFLOW/mixtank_new.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1851</td>
<td class='column-name'><a href="/Botonakis/FEM_3D_thermal1">FEM_3D_thermal1</a></td>
<td class='column-group'><a href="/Botonakis">Botonakis</a></td>
<td class='column-num_rows'>17,880</td>
<td class='column-num_cols'>17,880</td>
<td class='column-nonzeros'>430,740</td>
<td class='column-kind d-none d-md-table-cell'>Thermal Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Botonakis/FEM_3D_thermal1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Botonakis/FEM_3D_thermal1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Botonakis/FEM_3D_thermal1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1852</td>
<td class='column-name'><a href="/Botonakis/FEM_3D_thermal2">FEM_3D_thermal2</a></td>
<td class='column-group'><a href="/Botonakis">Botonakis</a></td>
<td class='column-num_rows'>147,900</td>
<td class='column-num_cols'>147,900</td>
<td class='column-nonzeros'>3,489,300</td>
<td class='column-kind d-none d-md-table-cell'>Thermal Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Botonakis/FEM_3D_thermal2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Botonakis/FEM_3D_thermal2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Botonakis/FEM_3D_thermal2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1854</td>
<td class='column-name'><a href="/Watson/chem_master1">chem_master1</a></td>
<td class='column-group'><a href="/Watson">Watson</a></td>
<td class='column-num_rows'>40,401</td>
<td class='column-num_cols'>40,401</td>
<td class='column-nonzeros'>201,201</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Watson/chem_master1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Watson/chem_master1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Watson/chem_master1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1855</td>
<td class='column-name'><a href="/Watson/Baumann">Baumann</a></td>
<td class='column-group'><a href="/Watson">Watson</a></td>
<td class='column-num_rows'>112,211</td>
<td class='column-num_cols'>112,211</td>
<td class='column-nonzeros'>748,331</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Watson/Baumann.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Watson/Baumann.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Watson/Baumann.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1858</td>
<td class='column-name'><a href="/QLi/crashbasis">crashbasis</a></td>
<td class='column-group'><a href="/QLi">QLi</a></td>
<td class='column-num_rows'>160,000</td>
<td class='column-num_cols'>160,000</td>
<td class='column-nonzeros'>1,750,416</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/QLi/crashbasis.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/QLi/crashbasis.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/QLi/crashbasis.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1859</td>
<td class='column-name'><a href="/QLi/majorbasis">majorbasis</a></td>
<td class='column-group'><a href="/QLi">QLi</a></td>
<td class='column-num_rows'>160,000</td>
<td class='column-num_cols'>160,000</td>
<td class='column-nonzeros'>1,750,416</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/QLi/majorbasis.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/QLi/majorbasis.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/QLi/majorbasis.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1861</td>
<td class='column-name'><a href="/Koutsovasilis/F2">F2</a></td>
<td class='column-group'><a href="/Koutsovasilis">Koutsovasilis</a></td>
<td class='column-num_rows'>71,505</td>
<td class='column-num_cols'>71,505</td>
<td class='column-nonzeros'>5,294,285</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Koutsovasilis/F2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Koutsovasilis/F2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Koutsovasilis/F2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1862</td>
<td class='column-name'><a href="/Szczerba/Ill_Stokes">Ill_Stokes</a></td>
<td class='column-group'><a href="/Szczerba">Szczerba</a></td>
<td class='column-num_rows'>20,896</td>
<td class='column-num_cols'>20,896</td>
<td class='column-nonzeros'>191,368</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Szczerba/Ill_Stokes.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Szczerba/Ill_Stokes.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Szczerba/Ill_Stokes.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1863</td>
<td class='column-name'><a href="/Rajat/Raj1">Raj1</a></td>
<td class='column-group'><a href="/Rajat">Rajat</a></td>
<td class='column-num_rows'>263,743</td>
<td class='column-num_cols'>263,743</td>
<td class='column-nonzeros'>1,300,261</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rajat/Raj1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rajat/Raj1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rajat/Raj1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1867</td>
<td class='column-name'><a href="/Muite/Chebyshev4">Chebyshev4</a></td>
<td class='column-group'><a href="/Muite">Muite</a></td>
<td class='column-num_rows'>68,121</td>
<td class='column-num_cols'>68,121</td>
<td class='column-nonzeros'>5,377,761</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Muite/Chebyshev4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Muite/Chebyshev4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Muite/Chebyshev4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1869</td>
<td class='column-name'><a href="/Quaglino/viscoplastic2">viscoplastic2</a></td>
<td class='column-group'><a href="/Quaglino">Quaglino</a></td>
<td class='column-num_rows'>32,769</td>
<td class='column-num_cols'>32,769</td>
<td class='column-nonzeros'>381,326</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Quaglino/viscoplastic2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Quaglino/viscoplastic2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Quaglino/viscoplastic2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1874</td>
<td class='column-name'><a href="/HVDC/hvdc1">hvdc1</a></td>
<td class='column-group'><a href="/HVDC">HVDC</a></td>
<td class='column-num_rows'>24,842</td>
<td class='column-num_cols'>24,842</td>
<td class='column-nonzeros'>158,426</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/HVDC/hvdc1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/HVDC/hvdc1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/HVDC/hvdc1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1875</td>
<td class='column-name'><a href="/HVDC/hvdc2">hvdc2</a></td>
<td class='column-group'><a href="/HVDC">HVDC</a></td>
<td class='column-num_rows'>189,860</td>
<td class='column-num_cols'>189,860</td>
<td class='column-nonzeros'>1,339,638</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/HVDC/hvdc2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/HVDC/hvdc2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/HVDC/hvdc2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1876</td>
<td class='column-name'><a href="/Zaoui/kkt_power">kkt_power</a></td>
<td class='column-group'><a href="/Zaoui">Zaoui</a></td>
<td class='column-num_rows'>2,063,494</td>
<td class='column-num_cols'>2,063,494</td>
<td class='column-nonzeros'>12,771,361</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Zaoui/kkt_power.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Zaoui/kkt_power.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Zaoui/kkt_power.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1879</td>
<td class='column-name'><a href="/Mancktelow/viscorocks">viscorocks</a></td>
<td class='column-group'><a href="/Mancktelow">Mancktelow</a></td>
<td class='column-num_rows'>37,762</td>
<td class='column-num_cols'>37,762</td>
<td class='column-nonzeros'>1,133,641</td>
<td class='column-kind d-none d-md-table-cell'>Materials Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Mancktelow/viscorocks.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Mancktelow/viscorocks.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Mancktelow/viscorocks.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1880</td>
<td class='column-name'><a href="/Rudnyi/water_tank">water_tank</a></td>
<td class='column-group'><a href="/Rudnyi">Rudnyi</a></td>
<td class='column-num_rows'>60,740</td>
<td class='column-num_cols'>60,740</td>
<td class='column-nonzeros'>2,035,281</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2007</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rudnyi/water_tank.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rudnyi/water_tank.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rudnyi/water_tank.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1882</td>
<td class='column-name'><a href="/McRae/ecology1">ecology1</a></td>
<td class='column-group'><a href="/McRae">McRae</a></td>
<td class='column-num_rows'>1,000,000</td>
<td class='column-num_cols'>1,000,000</td>
<td class='column-nonzeros'>4,996,000</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/McRae/ecology1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/McRae/ecology1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/McRae/ecology1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1893</td>
<td class='column-name'><a href="/QLi/largebasis">largebasis</a></td>
<td class='column-group'><a href="/QLi">QLi</a></td>
<td class='column-num_rows'>440,020</td>
<td class='column-num_cols'>440,020</td>
<td class='column-nonzeros'>5,240,084</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/QLi/largebasis.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/QLi/largebasis.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/QLi/largebasis.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1898</td>
<td class='column-name'><a href="/CEMW/tmt_unsym">tmt_unsym</a></td>
<td class='column-group'><a href="/CEMW">CEMW</a></td>
<td class='column-num_rows'>917,825</td>
<td class='column-num_cols'>917,825</td>
<td class='column-nonzeros'>4,584,801</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/CEMW/tmt_unsym.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/CEMW/tmt_unsym.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/CEMW/tmt_unsym.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1901</td>
<td class='column-name'><a href="/Schenk/nlpkkt80">nlpkkt80</a></td>
<td class='column-group'><a href="/Schenk">Schenk</a></td>
<td class='column-num_rows'>1,062,400</td>
<td class='column-num_cols'>1,062,400</td>
<td class='column-nonzeros'>28,192,672</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk/nlpkkt80.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk/nlpkkt80.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk/nlpkkt80.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1902</td>
<td class='column-name'><a href="/Schenk/nlpkkt120">nlpkkt120</a></td>
<td class='column-group'><a href="/Schenk">Schenk</a></td>
<td class='column-num_rows'>3,542,400</td>
<td class='column-num_cols'>3,542,400</td>
<td class='column-nonzeros'>95,117,792</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk/nlpkkt120.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk/nlpkkt120.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk/nlpkkt120.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1903</td>
<td class='column-name'><a href="/Schenk/nlpkkt160">nlpkkt160</a></td>
<td class='column-group'><a href="/Schenk">Schenk</a></td>
<td class='column-num_rows'>8,345,600</td>
<td class='column-num_cols'>8,345,600</td>
<td class='column-nonzeros'>225,422,112</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk/nlpkkt160.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk/nlpkkt160.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk/nlpkkt160.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1904</td>
<td class='column-name'><a href="/Schenk/nlpkkt200">nlpkkt200</a></td>
<td class='column-group'><a href="/Schenk">Schenk</a></td>
<td class='column-num_rows'>16,240,000</td>
<td class='column-num_cols'>16,240,000</td>
<td class='column-nonzeros'>440,225,632</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk/nlpkkt200.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk/nlpkkt200.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk/nlpkkt200.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>1905</td>
<td class='column-name'><a href="/Schenk/nlpkkt240">nlpkkt240</a></td>
<td class='column-group'><a href="/Schenk">Schenk</a></td>
<td class='column-num_rows'>27,993,600</td>
<td class='column-num_cols'>27,993,600</td>
<td class='column-nonzeros'>760,648,352</td>
<td class='column-kind d-none d-md-table-cell'>Optimization Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Schenk/nlpkkt240.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Schenk/nlpkkt240.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Schenk/nlpkkt240.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2136</td>
<td class='column-name'><a href="/QY/case39">case39</a></td>
<td class='column-group'><a href="/QY">QY</a></td>
<td class='column-num_rows'>40,216</td>
<td class='column-num_cols'>40,216</td>
<td class='column-nonzeros'>1,042,160</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/QY/case39.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/QY/case39.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/QY/case39.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2214</td>
<td class='column-name'><a href="/QY/case9">case9</a></td>
<td class='column-group'><a href="/QY">QY</a></td>
<td class='column-num_rows'>14,454</td>
<td class='column-num_cols'>14,454</td>
<td class='column-nonzeros'>147,972</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem Sequence</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/QY/case9.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/QY/case9.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/QY/case9.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2216</td>
<td class='column-name'><a href="/Freescale/Freescale1">Freescale1</a></td>
<td class='column-group'><a href="/Freescale">Freescale</a></td>
<td class='column-num_rows'>3,428,755</td>
<td class='column-num_cols'>3,428,755</td>
<td class='column-nonzeros'>17,052,626</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Freescale/Freescale1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Freescale/Freescale1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Freescale/Freescale1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2219</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b2383">TSOPF_RS_b2383</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>38,120</td>
<td class='column-num_cols'>38,120</td>
<td class='column-nonzeros'>16,171,169</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b2383.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b2383.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b2383.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2220</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b300">TSOPF_FS_b300</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>29,214</td>
<td class='column-num_cols'>29,214</td>
<td class='column-nonzeros'>4,400,122</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b300.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b300.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b300.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2221</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b162_c1">TSOPF_FS_b162_c1</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>10,798</td>
<td class='column-num_cols'>10,798</td>
<td class='column-nonzeros'>608,540</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b162_c1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b162_c1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b162_c1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2222</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b162_c3">TSOPF_FS_b162_c3</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>30,798</td>
<td class='column-num_cols'>30,798</td>
<td class='column-nonzeros'>1,801,300</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b162_c3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b162_c3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b162_c3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2223</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b162_c4">TSOPF_FS_b162_c4</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>40,798</td>
<td class='column-num_cols'>40,798</td>
<td class='column-nonzeros'>2,398,220</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b162_c4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b162_c4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b162_c4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2224</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b300_c1">TSOPF_FS_b300_c1</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>29,214</td>
<td class='column-num_cols'>29,214</td>
<td class='column-nonzeros'>4,400,122</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b300_c1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b300_c1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b300_c1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2225</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b300_c2">TSOPF_FS_b300_c2</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>56,814</td>
<td class='column-num_cols'>56,814</td>
<td class='column-nonzeros'>8,767,466</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b300_c2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b300_c2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b300_c2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2226</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b300_c3">TSOPF_FS_b300_c3</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>84,414</td>
<td class='column-num_cols'>84,414</td>
<td class='column-nonzeros'>13,135,930</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b300_c3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b300_c3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b300_c3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2227</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b39_c19">TSOPF_FS_b39_c19</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>76,216</td>
<td class='column-num_cols'>76,216</td>
<td class='column-nonzeros'>1,977,600</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b39_c19.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b39_c19.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b39_c19.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2228</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b39_c30">TSOPF_FS_b39_c30</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>120,216</td>
<td class='column-num_cols'>120,216</td>
<td class='column-nonzeros'>3,121,160</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b39_c30.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b39_c30.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b39_c30.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2229</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b39_c7">TSOPF_FS_b39_c7</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>28,216</td>
<td class='column-num_cols'>28,216</td>
<td class='column-nonzeros'>730,080</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b39_c7.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b39_c7.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b39_c7.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2231</td>
<td class='column-name'><a href="/TSOPF/TSOPF_FS_b9_c6">TSOPF_FS_b9_c6</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>14,454</td>
<td class='column-num_cols'>14,454</td>
<td class='column-nonzeros'>147,972</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_FS_b9_c6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_FS_b9_c6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_FS_b9_c6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2232</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b162_c1">TSOPF_RS_b162_c1</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>5,374</td>
<td class='column-num_cols'>5,374</td>
<td class='column-nonzeros'>205,399</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b162_c1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b162_c1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b162_c1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2233</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b162_c3">TSOPF_RS_b162_c3</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>15,374</td>
<td class='column-num_cols'>15,374</td>
<td class='column-nonzeros'>610,299</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b162_c3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b162_c3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b162_c3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2234</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b162_c4">TSOPF_RS_b162_c4</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>20,374</td>
<td class='column-num_cols'>20,374</td>
<td class='column-nonzeros'>812,749</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b162_c4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b162_c4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b162_c4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2235</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b2052_c1">TSOPF_RS_b2052_c1</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>25,626</td>
<td class='column-num_cols'>25,626</td>
<td class='column-nonzeros'>6,761,100</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b2052_c1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b2052_c1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b2052_c1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2236</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b2383_c1">TSOPF_RS_b2383_c1</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>38,120</td>
<td class='column-num_cols'>38,120</td>
<td class='column-nonzeros'>16,171,169</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b2383_c1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b2383_c1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b2383_c1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2237</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b300_c1">TSOPF_RS_b300_c1</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>14,538</td>
<td class='column-num_cols'>14,538</td>
<td class='column-nonzeros'>1,474,325</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b300_c1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b300_c1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b300_c1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2238</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b300_c2">TSOPF_RS_b300_c2</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>28,338</td>
<td class='column-num_cols'>28,338</td>
<td class='column-nonzeros'>2,943,887</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b300_c2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b300_c2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b300_c2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2239</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b300_c3">TSOPF_RS_b300_c3</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>42,138</td>
<td class='column-num_cols'>42,138</td>
<td class='column-nonzeros'>4,413,449</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b300_c3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b300_c3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b300_c3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2240</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b39_c19">TSOPF_RS_b39_c19</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>38,098</td>
<td class='column-num_cols'>38,098</td>
<td class='column-nonzeros'>684,206</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b39_c19.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b39_c19.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b39_c19.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2241</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b39_c30">TSOPF_RS_b39_c30</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>60,098</td>
<td class='column-num_cols'>60,098</td>
<td class='column-nonzeros'>1,079,986</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b39_c30.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b39_c30.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b39_c30.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2242</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b39_c7">TSOPF_RS_b39_c7</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>14,098</td>
<td class='column-num_cols'>14,098</td>
<td class='column-nonzeros'>252,446</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b39_c7.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b39_c7.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b39_c7.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2243</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b678_c1">TSOPF_RS_b678_c1</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>18,696</td>
<td class='column-num_cols'>18,696</td>
<td class='column-nonzeros'>4,396,289</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b678_c1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b678_c1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b678_c1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2244</td>
<td class='column-name'><a href="/TSOPF/TSOPF_RS_b678_c2">TSOPF_RS_b678_c2</a></td>
<td class='column-group'><a href="/TSOPF">TSOPF</a></td>
<td class='column-num_rows'>35,696</td>
<td class='column-num_cols'>35,696</td>
<td class='column-nonzeros'>8,781,949</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TSOPF/TSOPF_RS_b678_c2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TSOPF/TSOPF_RS_b678_c2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TSOPF/TSOPF_RS_b678_c2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2260</td>
<td class='column-name'><a href="/Botonakis/thermomech_dK">thermomech_dK</a></td>
<td class='column-group'><a href="/Botonakis">Botonakis</a></td>
<td class='column-num_rows'>204,316</td>
<td class='column-num_cols'>204,316</td>
<td class='column-nonzeros'>2,846,228</td>
<td class='column-kind d-none d-md-table-cell'>Thermal Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Botonakis/thermomech_dK.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Botonakis/thermomech_dK.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Botonakis/thermomech_dK.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2265</td>
<td class='column-name'><a href="/Bourchtein/atmosmodd">atmosmodd</a></td>
<td class='column-group'><a href="/Bourchtein">Bourchtein</a></td>
<td class='column-num_rows'>1,270,432</td>
<td class='column-num_cols'>1,270,432</td>
<td class='column-nonzeros'>8,814,880</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bourchtein/atmosmodd.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bourchtein/atmosmodd.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bourchtein/atmosmodd.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2266</td>
<td class='column-name'><a href="/Bourchtein/atmosmodj">atmosmodj</a></td>
<td class='column-group'><a href="/Bourchtein">Bourchtein</a></td>
<td class='column-num_rows'>1,270,432</td>
<td class='column-num_cols'>1,270,432</td>
<td class='column-nonzeros'>8,814,880</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bourchtein/atmosmodj.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bourchtein/atmosmodj.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bourchtein/atmosmodj.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2267</td>
<td class='column-name'><a href="/Bourchtein/atmosmodl">atmosmodl</a></td>
<td class='column-group'><a href="/Bourchtein">Bourchtein</a></td>
<td class='column-num_rows'>1,489,752</td>
<td class='column-num_cols'>1,489,752</td>
<td class='column-nonzeros'>10,319,760</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bourchtein/atmosmodl.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bourchtein/atmosmodl.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bourchtein/atmosmodl.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2269</td>
<td class='column-name'><a href="/Puri/ABACUS_shell_ud">ABACUS_shell_ud</a></td>
<td class='column-group'><a href="/Puri">Puri</a></td>
<td class='column-num_rows'>23,412</td>
<td class='column-num_cols'>23,412</td>
<td class='column-nonzeros'>218,484</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2009</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Puri/ABACUS_shell_ud.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Puri/ABACUS_shell_ud.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Puri/ABACUS_shell_ud.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2274</td>
<td class='column-name'><a href="/Freescale/memchip">memchip</a></td>
<td class='column-group'><a href="/Freescale">Freescale</a></td>
<td class='column-num_rows'>2,707,524</td>
<td class='column-num_cols'>2,707,524</td>
<td class='column-nonzeros'>13,343,948</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Freescale/memchip.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Freescale/memchip.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Freescale/memchip.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2275</td>
<td class='column-name'><a href="/Freescale/transient">transient</a></td>
<td class='column-group'><a href="/Freescale">Freescale</a></td>
<td class='column-num_rows'>178,866</td>
<td class='column-num_cols'>178,866</td>
<td class='column-nonzeros'>961,368</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Freescale/transient.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Freescale/transient.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Freescale/transient.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2276</td>
<td class='column-name'><a href="/Freescale/circuit5M">circuit5M</a></td>
<td class='column-group'><a href="/Freescale">Freescale</a></td>
<td class='column-num_rows'>5,558,326</td>
<td class='column-num_cols'>5,558,326</td>
<td class='column-nonzeros'>59,524,291</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Freescale/circuit5M.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Freescale/circuit5M.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Freescale/circuit5M.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2277</td>
<td class='column-name'><a href="/Freescale/circuit5M_dc">circuit5M_dc</a></td>
<td class='column-group'><a href="/Freescale">Freescale</a></td>
<td class='column-num_rows'>3,523,317</td>
<td class='column-num_cols'>3,523,317</td>
<td class='column-nonzeros'>14,865,409</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Freescale/circuit5M_dc.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Freescale/circuit5M_dc.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Freescale/circuit5M_dc.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2280</td>
<td class='column-name'><a href="/Belcastro/human_gene1">human_gene1</a></td>
<td class='column-group'><a href="/Belcastro">Belcastro</a></td>
<td class='column-num_rows'>22,283</td>
<td class='column-num_cols'>22,283</td>
<td class='column-nonzeros'>24,669,643</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Belcastro/human_gene1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Belcastro/human_gene1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Belcastro/human_gene1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2281</td>
<td class='column-name'><a href="/Belcastro/human_gene2">human_gene2</a></td>
<td class='column-group'><a href="/Belcastro">Belcastro</a></td>
<td class='column-num_rows'>14,340</td>
<td class='column-num_cols'>14,340</td>
<td class='column-nonzeros'>18,068,388</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Belcastro/human_gene2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Belcastro/human_gene2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Belcastro/human_gene2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2282</td>
<td class='column-name'><a href="/Belcastro/mouse_gene">mouse_gene</a></td>
<td class='column-group'><a href="/Belcastro">Belcastro</a></td>
<td class='column-num_rows'>45,101</td>
<td class='column-num_cols'>45,101</td>
<td class='column-nonzeros'>28,967,291</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Belcastro/mouse_gene.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Belcastro/mouse_gene.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Belcastro/mouse_gene.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2329</td>
<td class='column-name'><a href="/Dziekonski/gsm_106857">gsm_106857</a></td>
<td class='column-group'><a href="/Dziekonski">Dziekonski</a></td>
<td class='column-num_rows'>589,446</td>
<td class='column-num_cols'>589,446</td>
<td class='column-nonzeros'>21,758,924</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Dziekonski/gsm_106857.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Dziekonski/gsm_106857.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Dziekonski/gsm_106857.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2335</td>
<td class='column-name'><a href="/Fluorem/GT01R">GT01R</a></td>
<td class='column-group'><a href="/Fluorem">Fluorem</a></td>
<td class='column-num_rows'>7,980</td>
<td class='column-num_cols'>7,980</td>
<td class='column-nonzeros'>430,909</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Fluorem/GT01R.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Fluorem/GT01R.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Fluorem/GT01R.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2336</td>
<td class='column-name'><a href="/Fluorem/PR02R">PR02R</a></td>
<td class='column-group'><a href="/Fluorem">Fluorem</a></td>
<td class='column-num_rows'>161,070</td>
<td class='column-num_cols'>161,070</td>
<td class='column-nonzeros'>8,185,136</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Fluorem/PR02R.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Fluorem/PR02R.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Fluorem/PR02R.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2337</td>
<td class='column-name'><a href="/Fluorem/RM07R">RM07R</a></td>
<td class='column-group'><a href="/Fluorem">Fluorem</a></td>
<td class='column-num_rows'>381,689</td>
<td class='column-num_cols'>381,689</td>
<td class='column-nonzeros'>37,464,962</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Fluorem/RM07R.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Fluorem/RM07R.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Fluorem/RM07R.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2344</td>
<td class='column-name'><a href="/Rommes/juba40k">juba40k</a></td>
<td class='column-group'><a href="/Rommes">Rommes</a></td>
<td class='column-num_rows'>40,337</td>
<td class='column-num_cols'>40,337</td>
<td class='column-nonzeros'>144,945</td>
<td class='column-kind d-none d-md-table-cell'>Eigenvalue/Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rommes/juba40k.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rommes/juba40k.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rommes/juba40k.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2345</td>
<td class='column-name'><a href="/Rommes/bauru5727">bauru5727</a></td>
<td class='column-group'><a href="/Rommes">Rommes</a></td>
<td class='column-num_rows'>40,366</td>
<td class='column-num_cols'>40,366</td>
<td class='column-nonzeros'>145,019</td>
<td class='column-kind d-none d-md-table-cell'>Eigenvalue/Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2010</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Rommes/bauru5727.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Rommes/bauru5727.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Rommes/bauru5727.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2376</td>
<td class='column-name'><a href="/Williams/mac_econ_fwd500">mac_econ_fwd500</a></td>
<td class='column-group'><a href="/Williams">Williams</a></td>
<td class='column-num_rows'>206,500</td>
<td class='column-num_cols'>206,500</td>
<td class='column-nonzeros'>1,273,389</td>
<td class='column-kind d-none d-md-table-cell'>Economic Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Williams/mac_econ_fwd500.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Williams/mac_econ_fwd500.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Williams/mac_econ_fwd500.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2378</td>
<td class='column-name'><a href="/Williams/cop20k_A">cop20k_A</a></td>
<td class='column-group'><a href="/Williams">Williams</a></td>
<td class='column-num_rows'>121,192</td>
<td class='column-num_cols'>121,192</td>
<td class='column-nonzeros'>2,624,331</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Williams/cop20k_A.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Williams/cop20k_A.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Williams/cop20k_A.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2379</td>
<td class='column-name'><a href="/Williams/webbase-1M">webbase-1M</a></td>
<td class='column-group'><a href="/Williams">Williams</a></td>
<td class='column-num_rows'>1,000,005</td>
<td class='column-num_cols'>1,000,005</td>
<td class='column-nonzeros'>3,105,536</td>
<td class='column-kind d-none d-md-table-cell'>Weighted Directed Graph</td>
<td class='column-date d-none d-md-table-cell'>2008</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Williams/webbase-1M.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Williams/webbase-1M.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Williams/webbase-1M.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2380</td>
<td class='column-name'><a href="/Freescale/FullChip">FullChip</a></td>
<td class='column-group'><a href="/Freescale">Freescale</a></td>
<td class='column-num_rows'>2,987,012</td>
<td class='column-num_cols'>2,987,012</td>
<td class='column-nonzeros'>26,621,983</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Freescale/FullChip.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Freescale/FullChip.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Freescale/FullChip.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2384</td>
<td class='column-name'><a href="/Fluorem/HV15R">HV15R</a></td>
<td class='column-group'><a href="/Fluorem">Fluorem</a></td>
<td class='column-num_rows'>2,017,169</td>
<td class='column-num_cols'>2,017,169</td>
<td class='column-nonzeros'>283,073,458</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Fluorem/HV15R.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Fluorem/HV15R.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Fluorem/HV15R.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2386</td>
<td class='column-name'><a href="/Dziekonski/dielFilterV2real">dielFilterV2real</a></td>
<td class='column-group'><a href="/Dziekonski">Dziekonski</a></td>
<td class='column-num_rows'>1,157,456</td>
<td class='column-num_cols'>1,157,456</td>
<td class='column-nonzeros'>48,538,952</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Dziekonski/dielFilterV2real.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Dziekonski/dielFilterV2real.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Dziekonski/dielFilterV2real.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2388</td>
<td class='column-name'><a href="/Dziekonski/dielFilterV3real">dielFilterV3real</a></td>
<td class='column-group'><a href="/Dziekonski">Dziekonski</a></td>
<td class='column-num_rows'>1,102,824</td>
<td class='column-num_cols'>1,102,824</td>
<td class='column-nonzeros'>89,306,020</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Dziekonski/dielFilterV3real.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Dziekonski/dielFilterV3real.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Dziekonski/dielFilterV3real.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2391</td>
<td class='column-name'><a href="/Newman/astro-ph">astro-ph</a></td>
<td class='column-group'><a href="/Newman">Newman</a></td>
<td class='column-num_rows'>16,706</td>
<td class='column-num_cols'>16,706</td>
<td class='column-nonzeros'>242,502</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2001</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Newman/astro-ph.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Newman/astro-ph.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Newman/astro-ph.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2394</td>
<td class='column-name'><a href="/Newman/cond-mat-2003">cond-mat-2003</a></td>
<td class='column-group'><a href="/Newman">Newman</a></td>
<td class='column-num_rows'>31,163</td>
<td class='column-num_cols'>31,163</td>
<td class='column-nonzeros'>240,058</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2003</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Newman/cond-mat-2003.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Newman/cond-mat-2003.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Newman/cond-mat-2003.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2395</td>
<td class='column-name'><a href="/Newman/cond-mat-2005">cond-mat-2005</a></td>
<td class='column-group'><a href="/Newman">Newman</a></td>
<td class='column-num_rows'>40,421</td>
<td class='column-num_cols'>40,421</td>
<td class='column-nonzeros'>351,382</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2005</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Newman/cond-mat-2005.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Newman/cond-mat-2005.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Newman/cond-mat-2005.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2534</td>
<td class='column-name'><a href="/IPSO/HTC_336_4438">HTC_336_4438</a></td>
<td class='column-group'><a href="/IPSO">IPSO</a></td>
<td class='column-num_rows'>226,340</td>
<td class='column-num_cols'>226,340</td>
<td class='column-nonzeros'>783,496</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IPSO/HTC_336_4438.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IPSO/HTC_336_4438.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IPSO/HTC_336_4438.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2535</td>
<td class='column-name'><a href="/IPSO/HTC_336_9129">HTC_336_9129</a></td>
<td class='column-group'><a href="/IPSO">IPSO</a></td>
<td class='column-num_rows'>226,340</td>
<td class='column-num_cols'>226,340</td>
<td class='column-nonzeros'>762,969</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IPSO/HTC_336_9129.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IPSO/HTC_336_9129.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IPSO/HTC_336_9129.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2536</td>
<td class='column-name'><a href="/IPSO/OPF_10000">OPF_10000</a></td>
<td class='column-group'><a href="/IPSO">IPSO</a></td>
<td class='column-num_rows'>43,887</td>
<td class='column-num_cols'>43,887</td>
<td class='column-nonzeros'>426,898</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IPSO/OPF_10000.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IPSO/OPF_10000.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IPSO/OPF_10000.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2537</td>
<td class='column-name'><a href="/IPSO/OPF_3754">OPF_3754</a></td>
<td class='column-group'><a href="/IPSO">IPSO</a></td>
<td class='column-num_rows'>15,435</td>
<td class='column-num_cols'>15,435</td>
<td class='column-nonzeros'>141,478</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IPSO/OPF_3754.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IPSO/OPF_3754.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IPSO/OPF_3754.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2538</td>
<td class='column-name'><a href="/IPSO/OPF_6000">OPF_6000</a></td>
<td class='column-group'><a href="/IPSO">IPSO</a></td>
<td class='column-num_rows'>29,902</td>
<td class='column-num_cols'>29,902</td>
<td class='column-nonzeros'>274,697</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IPSO/OPF_6000.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IPSO/OPF_6000.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IPSO/OPF_6000.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2539</td>
<td class='column-name'><a href="/IPSO/TSC_OPF_1047">TSC_OPF_1047</a></td>
<td class='column-group'><a href="/IPSO">IPSO</a></td>
<td class='column-num_rows'>8,140</td>
<td class='column-num_cols'>8,140</td>
<td class='column-nonzeros'>2,012,833</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IPSO/TSC_OPF_1047.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IPSO/TSC_OPF_1047.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IPSO/TSC_OPF_1047.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2540</td>
<td class='column-name'><a href="/IPSO/TSC_OPF_300">TSC_OPF_300</a></td>
<td class='column-group'><a href="/IPSO">IPSO</a></td>
<td class='column-num_rows'>9,774</td>
<td class='column-num_cols'>9,774</td>
<td class='column-nonzeros'>820,783</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2011</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/IPSO/TSC_OPF_300.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/IPSO/TSC_OPF_300.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/IPSO/TSC_OPF_300.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2548</td>
<td class='column-name'><a href="/Janna/Cube_Coup_dt0">Cube_Coup_dt0</a></td>
<td class='column-group'><a href="/Janna">Janna</a></td>
<td class='column-num_rows'>2,164,760</td>
<td class='column-num_cols'>2,164,760</td>
<td class='column-nonzeros'>124,406,070</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Janna/Cube_Coup_dt0.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Janna/Cube_Coup_dt0.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Janna/Cube_Coup_dt0.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2549</td>
<td class='column-name'><a href="/Janna/Cube_Coup_dt6">Cube_Coup_dt6</a></td>
<td class='column-group'><a href="/Janna">Janna</a></td>
<td class='column-num_rows'>2,164,760</td>
<td class='column-num_cols'>2,164,760</td>
<td class='column-nonzeros'>124,406,070</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Janna/Cube_Coup_dt6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Janna/Cube_Coup_dt6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Janna/Cube_Coup_dt6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2550</td>
<td class='column-name'><a href="/Janna/Long_Coup_dt0">Long_Coup_dt0</a></td>
<td class='column-group'><a href="/Janna">Janna</a></td>
<td class='column-num_rows'>1,470,152</td>
<td class='column-num_cols'>1,470,152</td>
<td class='column-nonzeros'>84,422,970</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Janna/Long_Coup_dt0.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Janna/Long_Coup_dt0.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Janna/Long_Coup_dt0.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2551</td>
<td class='column-name'><a href="/Janna/Long_Coup_dt6">Long_Coup_dt6</a></td>
<td class='column-group'><a href="/Janna">Janna</a></td>
<td class='column-num_rows'>1,470,152</td>
<td class='column-num_cols'>1,470,152</td>
<td class='column-nonzeros'>84,422,970</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Janna/Long_Coup_dt6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Janna/Long_Coup_dt6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Janna/Long_Coup_dt6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2565</td>
<td class='column-name'><a href="/CPM/cz10228">cz10228</a></td>
<td class='column-group'><a href="/CPM">CPM</a></td>
<td class='column-num_rows'>10,228</td>
<td class='column-num_cols'>10,228</td>
<td class='column-nonzeros'>102,876</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/CPM/cz10228.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/CPM/cz10228.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/CPM/cz10228.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2566</td>
<td class='column-name'><a href="/CPM/cz20468">cz20468</a></td>
<td class='column-group'><a href="/CPM">CPM</a></td>
<td class='column-num_rows'>20,468</td>
<td class='column-num_cols'>20,468</td>
<td class='column-nonzeros'>206,076</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/CPM/cz20468.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/CPM/cz20468.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/CPM/cz20468.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2567</td>
<td class='column-name'><a href="/CPM/cz40948">cz40948</a></td>
<td class='column-group'><a href="/CPM">CPM</a></td>
<td class='column-num_rows'>40,948</td>
<td class='column-num_cols'>40,948</td>
<td class='column-nonzeros'>412,148</td>
<td class='column-kind d-none d-md-table-cell'>2D/3D Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/CPM/cz40948.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/CPM/cz40948.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/CPM/cz40948.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2569</td>
<td class='column-name'><a href="/Bodendiek/CurlCurl_0">CurlCurl_0</a></td>
<td class='column-group'><a href="/Bodendiek">Bodendiek</a></td>
<td class='column-num_rows'>11,083</td>
<td class='column-num_cols'>11,083</td>
<td class='column-nonzeros'>113,343</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bodendiek/CurlCurl_0.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bodendiek/CurlCurl_0.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bodendiek/CurlCurl_0.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2570</td>
<td class='column-name'><a href="/Bodendiek/CurlCurl_1">CurlCurl_1</a></td>
<td class='column-group'><a href="/Bodendiek">Bodendiek</a></td>
<td class='column-num_rows'>226,451</td>
<td class='column-num_cols'>226,451</td>
<td class='column-nonzeros'>2,472,071</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bodendiek/CurlCurl_1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bodendiek/CurlCurl_1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bodendiek/CurlCurl_1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2571</td>
<td class='column-name'><a href="/Bodendiek/CurlCurl_2">CurlCurl_2</a></td>
<td class='column-group'><a href="/Bodendiek">Bodendiek</a></td>
<td class='column-num_rows'>806,529</td>
<td class='column-num_cols'>806,529</td>
<td class='column-nonzeros'>8,921,789</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bodendiek/CurlCurl_2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bodendiek/CurlCurl_2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bodendiek/CurlCurl_2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2572</td>
<td class='column-name'><a href="/Bodendiek/CurlCurl_3">CurlCurl_3</a></td>
<td class='column-group'><a href="/Bodendiek">Bodendiek</a></td>
<td class='column-num_rows'>1,219,574</td>
<td class='column-num_cols'>1,219,574</td>
<td class='column-nonzeros'>13,544,618</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bodendiek/CurlCurl_3.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bodendiek/CurlCurl_3.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bodendiek/CurlCurl_3.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2573</td>
<td class='column-name'><a href="/Bodendiek/CurlCurl_4">CurlCurl_4</a></td>
<td class='column-group'><a href="/Bodendiek">Bodendiek</a></td>
<td class='column-num_rows'>2,380,515</td>
<td class='column-num_cols'>2,380,515</td>
<td class='column-nonzeros'>26,515,867</td>
<td class='column-kind d-none d-md-table-cell'>Model Reduction Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Bodendiek/CurlCurl_4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Bodendiek/CurlCurl_4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Bodendiek/CurlCurl_4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2647</td>
<td class='column-name'><a href="/Janna/CoupCons3D">CoupCons3D</a></td>
<td class='column-group'><a href="/Janna">Janna</a></td>
<td class='column-num_rows'>416,800</td>
<td class='column-num_cols'>416,800</td>
<td class='column-nonzeros'>17,277,420</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Janna/CoupCons3D.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Janna/CoupCons3D.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Janna/CoupCons3D.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2648</td>
<td class='column-name'><a href="/Janna/ML_Laplace">ML_Laplace</a></td>
<td class='column-group'><a href="/Janna">Janna</a></td>
<td class='column-num_rows'>377,002</td>
<td class='column-num_cols'>377,002</td>
<td class='column-nonzeros'>27,582,698</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Janna/ML_Laplace.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Janna/ML_Laplace.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Janna/ML_Laplace.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2649</td>
<td class='column-name'><a href="/Janna/Transport">Transport</a></td>
<td class='column-group'><a href="/Janna">Janna</a></td>
<td class='column-num_rows'>1,602,111</td>
<td class='column-num_cols'>1,602,111</td>
<td class='column-nonzeros'>23,487,281</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Janna/Transport.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Janna/Transport.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Janna/Transport.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2650</td>
<td class='column-name'><a href="/Janna/ML_Geer">ML_Geer</a></td>
<td class='column-group'><a href="/Janna">Janna</a></td>
<td class='column-num_rows'>1,504,002</td>
<td class='column-num_cols'>1,504,002</td>
<td class='column-nonzeros'>110,686,677</td>
<td class='column-kind d-none d-md-table-cell'>Structural Problem</td>
<td class='column-date d-none d-md-table-cell'>2012</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Janna/ML_Geer.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Janna/ML_Geer.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Janna/ML_Geer.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2657</td>
<td class='column-name'><a href="/LeGresley/LeGresley_87936">LeGresley_87936</a></td>
<td class='column-group'><a href="/LeGresley">LeGresley</a></td>
<td class='column-num_rows'>87,936</td>
<td class='column-num_cols'>87,936</td>
<td class='column-nonzeros'>593,276</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2013</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/LeGresley/LeGresley_87936.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/LeGresley/LeGresley_87936.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/LeGresley/LeGresley_87936.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2662</td>
<td class='column-name'><a href="/Freescale/Freescale2">Freescale2</a></td>
<td class='column-group'><a href="/Freescale">Freescale</a></td>
<td class='column-num_rows'>2,999,349</td>
<td class='column-num_cols'>2,999,349</td>
<td class='column-nonzeros'>14,313,235</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Matrix</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Freescale/Freescale2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Freescale/Freescale2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Freescale/Freescale2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2694</td>
<td class='column-name'><a href="/VDOL/hangGlider_4">hangGlider_4</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>15,561</td>
<td class='column-num_cols'>15,561</td>
<td class='column-nonzeros'>149,532</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/hangGlider_4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/hangGlider_4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/hangGlider_4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2695</td>
<td class='column-name'><a href="/VDOL/hangGlider_5">hangGlider_5</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>16,011</td>
<td class='column-num_cols'>16,011</td>
<td class='column-nonzeros'>155,246</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/hangGlider_5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/hangGlider_5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/hangGlider_5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2708</td>
<td class='column-name'><a href="/VDOL/lowThrust_4">lowThrust_4</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>13,562</td>
<td class='column-num_cols'>13,562</td>
<td class='column-nonzeros'>160,947</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_4.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_4.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_4.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2709</td>
<td class='column-name'><a href="/VDOL/lowThrust_5">lowThrust_5</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>16,262</td>
<td class='column-num_cols'>16,262</td>
<td class='column-nonzeros'>198,369</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_5.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_5.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_5.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2710</td>
<td class='column-name'><a href="/VDOL/lowThrust_6">lowThrust_6</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>16,928</td>
<td class='column-num_cols'>16,928</td>
<td class='column-nonzeros'>207,349</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_6.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_6.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_6.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2711</td>
<td class='column-name'><a href="/VDOL/lowThrust_7">lowThrust_7</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>17,378</td>
<td class='column-num_cols'>17,378</td>
<td class='column-nonzeros'>211,561</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_7.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_7.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_7.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2712</td>
<td class='column-name'><a href="/VDOL/lowThrust_8">lowThrust_8</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>17,702</td>
<td class='column-num_cols'>17,702</td>
<td class='column-nonzeros'>216,445</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_8.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_8.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_8.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2713</td>
<td class='column-name'><a href="/VDOL/lowThrust_9">lowThrust_9</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>18,044</td>
<td class='column-num_cols'>18,044</td>
<td class='column-nonzeros'>219,589</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_9.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_9.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_9.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2714</td>
<td class='column-name'><a href="/VDOL/lowThrust_10">lowThrust_10</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>18,260</td>
<td class='column-num_cols'>18,260</td>
<td class='column-nonzeros'>222,005</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_10.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_10.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_10.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2715</td>
<td class='column-name'><a href="/VDOL/lowThrust_11">lowThrust_11</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>18,368</td>
<td class='column-num_cols'>18,368</td>
<td class='column-nonzeros'>223,801</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_11.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_11.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_11.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2716</td>
<td class='column-name'><a href="/VDOL/lowThrust_12">lowThrust_12</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>18,458</td>
<td class='column-num_cols'>18,458</td>
<td class='column-nonzeros'>224,593</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_12.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_12.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_12.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2717</td>
<td class='column-name'><a href="/VDOL/lowThrust_13">lowThrust_13</a></td>
<td class='column-group'><a href="/VDOL">VDOL</a></td>
<td class='column-num_rows'>18,476</td>
<td class='column-num_cols'>18,476</td>
<td class='column-nonzeros'>224,897</td>
<td class='column-kind d-none d-md-table-cell'>Optimal Control Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VDOL/lowThrust_13.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VDOL/lowThrust_13.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VDOL/lowThrust_13.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2810</td>
<td class='column-name'><a href="/Sybrandt/MOLIERE_2016">MOLIERE_2016</a></td>
<td class='column-group'><a href="/Sybrandt">Sybrandt</a></td>
<td class='column-num_rows'>30,239,687</td>
<td class='column-num_cols'>30,239,687</td>
<td class='column-nonzeros'>6,669,254,694</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2017</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Sybrandt/MOLIERE_2016.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Sybrandt/MOLIERE_2016.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Sybrandt/MOLIERE_2016.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2811</td>
<td class='column-name'><a href="/Guettel/TEM27623">TEM27623</a></td>
<td class='column-group'><a href="/Guettel">Guettel</a></td>
<td class='column-num_rows'>27,623</td>
<td class='column-num_cols'>27,623</td>
<td class='column-nonzeros'>439,469</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Guettel/TEM27623.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Guettel/TEM27623.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Guettel/TEM27623.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2812</td>
<td class='column-name'><a href="/Guettel/TEM152078">TEM152078</a></td>
<td class='column-group'><a href="/Guettel">Guettel</a></td>
<td class='column-num_rows'>152,078</td>
<td class='column-num_cols'>152,078</td>
<td class='column-nonzeros'>6,459,326</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Guettel/TEM152078.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Guettel/TEM152078.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Guettel/TEM152078.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2813</td>
<td class='column-name'><a href="/Guettel/TEM181302">TEM181302</a></td>
<td class='column-group'><a href="/Guettel">Guettel</a></td>
<td class='column-num_rows'>181,302</td>
<td class='column-num_cols'>181,302</td>
<td class='column-nonzeros'>7,839,010</td>
<td class='column-kind d-none d-md-table-cell'>Electromagnetics Problem</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Guettel/TEM181302.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Guettel/TEM181302.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Guettel/TEM181302.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2814</td>
<td class='column-name'><a href="/Grueninger/windtunnel_evap2d">windtunnel_evap2d</a></td>
<td class='column-group'><a href="/Grueninger">Grueninger</a></td>
<td class='column-num_rows'>8,256</td>
<td class='column-num_cols'>8,256</td>
<td class='column-nonzeros'>109,368</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2017</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Grueninger/windtunnel_evap2d.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Grueninger/windtunnel_evap2d.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Grueninger/windtunnel_evap2d.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2815</td>
<td class='column-name'><a href="/Grueninger/windtunnel_evap3d">windtunnel_evap3d</a></td>
<td class='column-group'><a href="/Grueninger">Grueninger</a></td>
<td class='column-num_rows'>40,816</td>
<td class='column-num_cols'>40,816</td>
<td class='column-nonzeros'>803,978</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics Problem</td>
<td class='column-date d-none d-md-table-cell'>2017</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Grueninger/windtunnel_evap3d.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Grueninger/windtunnel_evap3d.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Grueninger/windtunnel_evap3d.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2816</td>
<td class='column-name'><a href="/PowerSystem/power197k">power197k</a></td>
<td class='column-group'><a href="/PowerSystem">PowerSystem</a></td>
<td class='column-num_rows'>197,156</td>
<td class='column-num_cols'>197,156</td>
<td class='column-nonzeros'>805,839</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2017</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/PowerSystem/power197k.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/PowerSystem/power197k.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/PowerSystem/power197k.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2820</td>
<td class='column-name'><a href="/Goodwin/Goodwin_023">Goodwin_023</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>6,005</td>
<td class='column-num_cols'>6,005</td>
<td class='column-nonzeros'>182,168</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/Goodwin_023.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/Goodwin_023.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/Goodwin_023.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2821</td>
<td class='column-name'><a href="/Goodwin/Goodwin_030">Goodwin_030</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>10,142</td>
<td class='column-num_cols'>10,142</td>
<td class='column-nonzeros'>312,814</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/Goodwin_030.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/Goodwin_030.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/Goodwin_030.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2822</td>
<td class='column-name'><a href="/Goodwin/Goodwin_040">Goodwin_040</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>17,922</td>
<td class='column-num_cols'>17,922</td>
<td class='column-nonzeros'>561,677</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/Goodwin_040.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/Goodwin_040.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/Goodwin_040.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2823</td>
<td class='column-name'><a href="/Goodwin/Goodwin_054">Goodwin_054</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>32,510</td>
<td class='column-num_cols'>32,510</td>
<td class='column-nonzeros'>1,030,878</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/Goodwin_054.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/Goodwin_054.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/Goodwin_054.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2824</td>
<td class='column-name'><a href="/Goodwin/Goodwin_071">Goodwin_071</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>56,021</td>
<td class='column-num_cols'>56,021</td>
<td class='column-nonzeros'>1,797,934</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/Goodwin_071.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/Goodwin_071.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/Goodwin_071.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2825</td>
<td class='column-name'><a href="/Goodwin/Goodwin_095">Goodwin_095</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>100,037</td>
<td class='column-num_cols'>100,037</td>
<td class='column-nonzeros'>3,226,066</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/Goodwin_095.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/Goodwin_095.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/Goodwin_095.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2826</td>
<td class='column-name'><a href="/Goodwin/Goodwin_127">Goodwin_127</a></td>
<td class='column-group'><a href="/Goodwin">Goodwin</a></td>
<td class='column-num_rows'>178,437</td>
<td class='column-num_cols'>178,437</td>
<td class='column-nonzeros'>5,778,545</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Goodwin/Goodwin_127.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Goodwin/Goodwin_127.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Goodwin/Goodwin_127.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2828</td>
<td class='column-name'><a href="/TAMU_SmartGridCenter/ACTIVSg10K">ACTIVSg10K</a></td>
<td class='column-group'><a href="/TAMU_SmartGridCenter">TAMU_SmartGridCenter</a></td>
<td class='column-num_rows'>20,000</td>
<td class='column-num_cols'>20,000</td>
<td class='column-nonzeros'>135,888</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TAMU_SmartGridCenter/ACTIVSg10K.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TAMU_SmartGridCenter/ACTIVSg10K.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TAMU_SmartGridCenter/ACTIVSg10K.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2829</td>
<td class='column-name'><a href="/TAMU_SmartGridCenter/ACTIVSg70K">ACTIVSg70K</a></td>
<td class='column-group'><a href="/TAMU_SmartGridCenter">TAMU_SmartGridCenter</a></td>
<td class='column-num_rows'>69,999</td>
<td class='column-num_cols'>69,999</td>
<td class='column-nonzeros'>238,627</td>
<td class='column-kind d-none d-md-table-cell'>Power Network Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/TAMU_SmartGridCenter/ACTIVSg70K.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/TAMU_SmartGridCenter/ACTIVSg70K.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/TAMU_SmartGridCenter/ACTIVSg70K.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2830</td>
<td class='column-name'><a href="/Embree/ifiss_mat">ifiss_mat</a></td>
<td class='column-group'><a href="/Embree">Embree</a></td>
<td class='column-num_rows'>96,307</td>
<td class='column-num_cols'>96,307</td>
<td class='column-nonzeros'>3,599,932</td>
<td class='column-kind d-none d-md-table-cell'>Computational Fluid Dynamics</td>
<td class='column-date d-none d-md-table-cell'>2015</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Embree/ifiss_mat.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Embree/ifiss_mat.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Embree/ifiss_mat.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2834</td>
<td class='column-name'><a href="/VLSI/nv1">nv1</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>75,468</td>
<td class='column-num_cols'>75,468</td>
<td class='column-nonzeros'>1,635,003</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/nv1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/nv1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/nv1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2835</td>
<td class='column-name'><a href="/VLSI/nv2">nv2</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>1,453,908</td>
<td class='column-num_cols'>1,453,908</td>
<td class='column-nonzeros'>37,475,646</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/nv2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/nv2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/nv2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2836</td>
<td class='column-name'><a href="/VLSI/imagesensor">imagesensor</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>118,758</td>
<td class='column-num_cols'>118,758</td>
<td class='column-nonzeros'>1,446,396</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/imagesensor.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/imagesensor.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/imagesensor.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2837</td>
<td class='column-name'><a href="/VLSI/mosfet2">mosfet2</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>46,994</td>
<td class='column-num_cols'>46,994</td>
<td class='column-nonzeros'>1,013,062</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/mosfet2.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/mosfet2.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/mosfet2.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2838</td>
<td class='column-name'><a href="/VLSI/power9">power9</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>155,376</td>
<td class='column-num_cols'>155,376</td>
<td class='column-nonzeros'>1,887,730</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/power9.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/power9.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/power9.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2839</td>
<td class='column-name'><a href="/VLSI/radiation">radiation</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>223,104</td>
<td class='column-num_cols'>223,104</td>
<td class='column-nonzeros'>5,526,637</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/radiation.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/radiation.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/radiation.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2840</td>
<td class='column-name'><a href="/VLSI/test1">test1</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>392,908</td>
<td class='column-num_cols'>392,908</td>
<td class='column-nonzeros'>9,447,535</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/test1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/test1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/test1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2841</td>
<td class='column-name'><a href="/VLSI/dgreen">dgreen</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>1,200,611</td>
<td class='column-num_cols'>1,200,611</td>
<td class='column-nonzeros'>26,606,169</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Device Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/dgreen.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/dgreen.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/dgreen.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2842</td>
<td class='column-name'><a href="/VLSI/vas_stokes_1M">vas_stokes_1M</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>1,090,664</td>
<td class='column-num_cols'>1,090,664</td>
<td class='column-nonzeros'>34,767,207</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Process Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/vas_stokes_1M.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/vas_stokes_1M.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/vas_stokes_1M.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2843</td>
<td class='column-name'><a href="/VLSI/vas_stokes_2M">vas_stokes_2M</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>2,146,677</td>
<td class='column-num_cols'>2,146,677</td>
<td class='column-nonzeros'>65,129,037</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Process Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/vas_stokes_2M.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/vas_stokes_2M.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/vas_stokes_2M.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2844</td>
<td class='column-name'><a href="/VLSI/vas_stokes_4M">vas_stokes_4M</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>4,382,246</td>
<td class='column-num_cols'>4,382,246</td>
<td class='column-nonzeros'>131,577,616</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Process Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/vas_stokes_4M.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/vas_stokes_4M.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/vas_stokes_4M.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2845</td>
<td class='column-name'><a href="/VLSI/stokes">stokes</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>11,449,533</td>
<td class='column-num_cols'>11,449,533</td>
<td class='column-nonzeros'>349,321,980</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Process Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/stokes.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/stokes.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/stokes.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2846</td>
<td class='column-name'><a href="/VLSI/ss1">ss1</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>205,282</td>
<td class='column-num_cols'>205,282</td>
<td class='column-nonzeros'>845,089</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Process Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/ss1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/ss1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/ss1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2847</td>
<td class='column-name'><a href="/VLSI/ss">ss</a></td>
<td class='column-group'><a href="/VLSI">VLSI</a></td>
<td class='column-num_rows'>1,652,680</td>
<td class='column-num_cols'>1,652,680</td>
<td class='column-nonzeros'>34,753,577</td>
<td class='column-kind d-none d-md-table-cell'>Semiconductor Process Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/VLSI/ss.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/VLSI/ss.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/VLSI/ss.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2848</td>
<td class='column-name'><a href="/Freescale/nxp1">nxp1</a></td>
<td class='column-group'><a href="/Freescale">Freescale</a></td>
<td class='column-num_rows'>414,604</td>
<td class='column-num_cols'>414,604</td>
<td class='column-nonzeros'>2,655,880</td>
<td class='column-kind d-none d-md-table-cell'>Circuit Simulation Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Freescale/nxp1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Freescale/nxp1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Freescale/nxp1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2849</td>
<td class='column-name'><a href="/Martin/marine1">marine1</a></td>
<td class='column-group'><a href="/Martin">Martin</a></td>
<td class='column-num_rows'>400,320</td>
<td class='column-num_cols'>400,320</td>
<td class='column-nonzeros'>6,226,538</td>
<td class='column-kind d-none d-md-table-cell'>Chemical Oceanography Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Martin/marine1.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Martin/marine1.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Martin/marine1.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2851</td>
<td class='column-name'><a href="/Precima/analytics">analytics</a></td>
<td class='column-group'><a href="/Precima">Precima</a></td>
<td class='column-num_rows'>303,813</td>
<td class='column-num_cols'>303,813</td>
<td class='column-nonzeros'>2,006,126</td>
<td class='column-kind d-none d-md-table-cell'>Data Analytics Problem</td>
<td class='column-date d-none d-md-table-cell'>2018</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/Precima/analytics.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/Precima/analytics.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/Precima/analytics.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2868</td>
<td class='column-name'><a href="/ML_Graph/Fashion_MNIST_norm_10NN">Fashion_MNIST_norm_10NN</a></td>
<td class='column-group'><a href="/ML_Graph">ML_Graph</a></td>
<td class='column-num_rows'>10,000</td>
<td class='column-num_cols'>10,000</td>
<td class='column-nonzeros'>158,304</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2020</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ML_Graph/Fashion_MNIST_norm_10NN.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ML_Graph/Fashion_MNIST_norm_10NN.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ML_Graph/Fashion_MNIST_norm_10NN.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2870</td>
<td class='column-name'><a href="/ML_Graph/har_10NN">har_10NN</a></td>
<td class='column-group'><a href="/ML_Graph">ML_Graph</a></td>
<td class='column-num_rows'>10,299</td>
<td class='column-num_cols'>10,299</td>
<td class='column-nonzeros'>151,736</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2020</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ML_Graph/har_10NN.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ML_Graph/har_10NN.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ML_Graph/har_10NN.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2871</td>
<td class='column-name'><a href="/ML_Graph/indianpines_10NN">indianpines_10NN</a></td>
<td class='column-group'><a href="/ML_Graph">ML_Graph</a></td>
<td class='column-num_rows'>9,144</td>
<td class='column-num_cols'>9,144</td>
<td class='column-nonzeros'>124,656</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2020</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ML_Graph/indianpines_10NN.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ML_Graph/indianpines_10NN.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ML_Graph/indianpines_10NN.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2873</td>
<td class='column-name'><a href="/ML_Graph/JapaneseVowelsSmall_10NN">JapaneseVowelsSmall_10NN</a></td>
<td class='column-group'><a href="/ML_Graph">ML_Graph</a></td>
<td class='column-num_rows'>9,961</td>
<td class='column-num_cols'>9,961</td>
<td class='column-nonzeros'>131,144</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2020</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ML_Graph/JapaneseVowelsSmall_10NN.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ML_Graph/JapaneseVowelsSmall_10NN.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ML_Graph/JapaneseVowelsSmall_10NN.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2874</td>
<td class='column-name'><a href="/ML_Graph/k49_norm_10NN">k49_norm_10NN</a></td>
<td class='column-group'><a href="/ML_Graph">ML_Graph</a></td>
<td class='column-num_rows'>38,547</td>
<td class='column-num_cols'>38,547</td>
<td class='column-nonzeros'>618,158</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2020</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ML_Graph/k49_norm_10NN.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ML_Graph/k49_norm_10NN.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ML_Graph/k49_norm_10NN.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2875</td>
<td class='column-name'><a href="/ML_Graph/kmnist_norm_10NN">kmnist_norm_10NN</a></td>
<td class='column-group'><a href="/ML_Graph">ML_Graph</a></td>
<td class='column-num_rows'>10,000</td>
<td class='column-num_cols'>10,000</td>
<td class='column-nonzeros'>156,932</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2020</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ML_Graph/kmnist_norm_10NN.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ML_Graph/kmnist_norm_10NN.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ML_Graph/kmnist_norm_10NN.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2878</td>
<td class='column-name'><a href="/ML_Graph/mnist_test_norm_10NN">mnist_test_norm_10NN</a></td>
<td class='column-group'><a href="/ML_Graph">ML_Graph</a></td>
<td class='column-num_rows'>10,000</td>
<td class='column-num_cols'>10,000</td>
<td class='column-nonzeros'>145,600</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2020</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ML_Graph/mnist_test_norm_10NN.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ML_Graph/mnist_test_norm_10NN.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ML_Graph/mnist_test_norm_10NN.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
<tr>
<td class='column-id'>2889</td>
<td class='column-name'><a href="/ML_Graph/worms20_10NN">worms20_10NN</a></td>
<td class='column-group'><a href="/ML_Graph">ML_Graph</a></td>
<td class='column-num_rows'>20,055</td>
<td class='column-num_cols'>20,055</td>
<td class='column-nonzeros'>240,826</td>
<td class='column-kind d-none d-md-table-cell'>Undirected Weighted Graph</td>
<td class='column-date d-none d-md-table-cell'>2020</td>
<td class='column-download d-none d-lg-table-cell'>
<a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/mat/ML_Graph/worms20_10NN.mat">MATLAB
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/RB/ML_Graph/worms20_10NN.tar.gz">Rutherford Boeing
<span aria-hidden='true' class='fa fa-download'></span>
</a><a class="btn btn-outline-dark btn-sm" href="https://suitesparse-collection-website.herokuapp.com/MM/ML_Graph/worms20_10NN.tar.gz">Matrix Market
<span aria-hidden='true' class='fa fa-download'></span>
</a></td>
</tr>
</tbody>
</table>
</div>
<!-- Bottom Pagination Bar -->
<div class='pagination-container container px-2'>
<div class='row'>
<div class='col'></div>
<div class='col-md-auto p-0'>

</div>
<div class='col col-lg-3 p-2 text-right'>
<label for="per_page_top">Display per page:</label>
<select name="per_page_top" id="per_page_top" onchange="if(this.value){window.location=&#39;?per_page=&#39;+this.value;}"><option value="20">20</option>
<option value="50">50</option>
<option value="100">100</option>
<option selected="selected" value="All">All</option></select>
</div>
</div>
</div>

</div>
<script>
  $(function() {
      // Check if alert has been closed
      if( Cookies.get('about-box') === 'closed' ){
          $('.about-alert').hide();
      }
      $('.about-close').click(function( e ){
          // Do not perform default action when button is clicked
          e.preventDefault();
          Cookies.set('about-box', 'closed');
      });
  });
</script>
<script>
  $(function() {
    $(".filter-checkbox").change(function() {
      if(this.checked) {
        $($(this).data("target")).removeClass('filter-hidden');
      } else {
        $($(this).data("target")).addClass('filter-hidden');
        $($(this).data("target")).find("input").each(function() {
          $(this).val('');
        });
        $($(this).data("target")).find("select").each(function() {
          $(this)[0].selectedIndex = 0;
          $(this).trigger('change');
        });
      }
    });
  });
</script>
<script>
  $( document ).on('turbolinks:load', function() {
    $(".filter-checkbox").each(function() {
      if(this.checked) {
        $($(this).data("target")).removeClass('filter-hidden');
      }
    });
  });
</script>
<script>
  $(function() {
    $('.dropdown-menu').find('.small').click(function(e) {
      if(e.target.type !== 'checkbox' && e.target.nodeName !== 'LABEL') {
        // If the click is on the checkbox or label, no need to click twice
        $($(this).data("target")).trigger('click');
      }
      // Keep the dropdown menu open until we click elsewhere
      e.stopPropagation();
    });
  });
</script>

</div>
</body>
<footer class='text-center'>
<div class='container'>
<a href="https://www.tamu.edu">Texas A&amp;M University</a>
 |
<a href="https://engineering.tamu.edu/cse/">Computer Science &amp; Engineering Department</a>
 |
<a href="https://github.com/ScottKolo/suitesparse-matrix-collection-website">Code on GitHub
<span aria-hidden='true' class='fab fa-github'></span>
</a></div>
</footer>
<script>
  WebFontConfig = {
    google: { families: ['Cutive'] }
  };
  (function() {
    var wf = document.createElement('script');
    wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })();
</script>
</html>

"""

# 正则表达式
pattern = r"https://suitesparse-collection-website.herokuapp.com/MM/.*?\.tar\.gz"

# 查找所有匹配的 URL
matches = re.findall(pattern, text)
print(len(matches))

import os
import requests
from urllib.parse import urlparse
import re
import time

DOWNLOAD_DIR = "/Users/mainf/其他/"  # 文件保存目录
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}
DELAY = 1  # 请求间隔时间（秒）


def download_file(url, save_dir=DOWNLOAD_DIR):
    """下载单个文件并保存到指定目录"""
    try:
        # 创建保存目录
        os.makedirs(save_dir, exist_ok=True)

        # 提取文件名
        parsed_url = urlparse(url)
        filename = os.path.basename(parsed_url.path)
        save_path = os.path.join(save_dir, filename)

        # 发送 HTTP 请求（流式传输）
        response = requests.get(url, headers=HEADERS, stream=True, timeout=30)
        response.raise_for_status()  # 检查状态码

        # 获取文件大小（字节）
        file_size = int(response.headers.get('Content-Length', 0))

        # 下载并显示进度
        print(f"正在下载: {filename} ({file_size / 1024 / 1024:.2f} MB)")
        downloaded = 0

        with open(save_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
                downloaded += len(chunk)
                if file_size > 0:
                    progress = downloaded / file_size * 100
                    print(f"\r进度: {progress:.1f}%", end='', flush=True)
        print("\n下载完成！")

    except Exception as e:
        print(f"\n下载失败: {str(e)}")
        if os.path.exists(save_path):  # 删除可能不完整的文件
            os.remove(save_path)




i=0
for url in matches:
    i+=1
    print(f"[{i}]download:"+url)
    download_file(url)

from bs4 import BeautifulSoup
import csv

soup = BeautifulSoup(text, 'html.parser')

# 存储结果的列表
results = []

# 遍历所有表格
for table in soup.find_all('table'):
    # 遍历表格中的每一行
    for tr in table.find_all('tr'):
        # 使用 CSS 选择器精准定位
        td_name = tr.select_one('td.column-name')
        td_dim = tr.select_one('td.column-num_cols')
        td_nnz = tr.select_one('td.column-nonzeros')
        td_kind = tr.select_one('td.column-kind')

        # 处理数据提取和空值
        row_data = {
            'Matrix_Name': td_name.get_text(strip=True) if td_name else None,
            'dim': td_dim.get_text(strip=True) if td_dim else None,
            'nonzeros': td_nnz.get_text(strip=True) if td_nnz else None,
            'kind': td_kind.get_text(strip=True) if td_kind else None
        }

        # 过滤空行（可选）
        if any(row_data.values()):
            results.append(row_data)


# 写入CSV文件
csv_file = 'sparse_matrix.csv'
csv_columns = ['Matrix_Name', 'dim', 'nonzeros', 'kind']  # 控制列顺序

with open(csv_file, 'w', newline='', encoding='utf-8-sig') as f:  # utf-8-sig 兼容Excel
    writer = csv.DictWriter(f, fieldnames=csv_columns)

    # 写入带中文的标题（可选）
    header_mapping = {
        'Matrix_Name': 'Matrix_Name',
        'dim': 'dim',
        'nonzeros': 'nonzeros',
        'kind': 'kind'
    }
    writer.writerow(header_mapping)  # 写入中文列名

    for row in results:
        # 自动处理None值，保持数据整洁
        cleaned_row = {k: v if v is not None else '' for k, v in row.items()}
        writer.writerow(cleaned_row)

print(f"成功导出 {len(results)} 条记录到 {csv_file}")