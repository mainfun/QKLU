#include <btf.h>
#include <float.h>
#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <numeric/SpTSTRF.h>
#include <numeric/sp_factor.h>
#include <preprocess/etree.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>
#include "SuiteSparse_config.h"
#include "base/sort.h"

Config config;

int main(int argc, char *argv[]) {
    parse_arguments(argc, argv, &config);
    CSRMatrix *original_matrix = load_matrix_csr(argv[1], false);
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    CSRMatrix *A = reordering(original_matrix, info,true,true);
    //------------符号分析--------------
    INDEX_TYPE *etree = create_etree_force2sym(A);
    INDEX_TYPE *Up, *Ui, *Lp, *Li;
    get_u_row_patterns_naive(A->row_pointers, A->col_indices, A->num_col, etree,
                             &Up, &Ui, info->cut_point1, info->cut_point2);
    get_l_row_patterns_naive(A->row_pointers, A->col_indices, etree,
                             A->num_col, A->num_col, &Lp, &Li);
    LOG_DEBUG("估算FMA个数：%lld",compute_fma_count(A->num_row,Lp,Li,Up));
    long long l_nnz = Lp[A->num_row];
    long long u_nnz = Up[A->num_row];
    lu_free(etree);
    //------------绘图--------------
    // CSRMatrix *l = init_csr_matrix(A->num_col, A->num_col, l_nnz);
    // l->row_pointers = Lp, l->col_indices = Li;
    // csr2image_RGB(l,"l_k3plates.jpeg",4000,4000);
    // CSRMatrix *u = init_csr_matrix(A->num_col, A->num_col, u_nnz);
    // u->row_pointers = Up, u->col_indices = Ui;
    // csr2image_RGB(u,"u_k3plates.jpeg",4000,4000);
    // LOG_DEBUG("绘制完成");
    //-------------数值分解-------------
    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = 0; i < A->num_col; ++i) {
        ELE_TYPE sum = 0;
        for (INDEX_TYPE j = A->row_pointers[i]; j < A->row_pointers[i + 1]; ++j) {
            sum += A->csr_values[j];
        }
        b[i] = sum;
    }
    // random_vector(b, A->num_row);

    ELE_TYPE *Lx = (ELE_TYPE *) lu_malloc(l_nnz * sizeof(ELE_TYPE));
    ELE_TYPE *Ux = (ELE_TYPE *) lu_malloc(u_nnz * sizeof(ELE_TYPE));
    ELE_TYPE *U_diag = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    // print_dense_matrix(csr2dense(A),A->num_row);

    sp_factor_v6(A->row_pointers, A->col_indices, A->csr_values,
                 Lp, Li, Lx, Up, Ui, Ux, U_diag, A->num_row);
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    lower_solver_csr(Lp, Li, Lx, A->num_row, y, b);
    upper_solver_csr_exclude_diag(Up, Ui, Ux, U_diag, A->num_row, x, y);
    check_solving(A, x, b);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);

    lu_free(x);
    lu_free(y);
    lu_free(b);
    lu_free(Up);
    lu_free(Ui);
    lu_free(Lx);
    lu_free(Ux);
    lu_free(U_diag);
    free_csr_matrix(A);
    free_csr_matrix(original_matrix);
    free_preprocess_info(info);
    free_config(&config);
    return 0;
}
