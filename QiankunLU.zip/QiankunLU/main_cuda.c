#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <preprocess/etree.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>
#include <solve/solving_cuda.h>

#include "SuiteSparse_config.h"
#include "btf.h"

Config config;

///支持无序
INDEX_TYPE calc_l_nnz(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const INDEX_TYPE n, const INDEX_TYPE parent[]) {
    double start_time = omp_get_wtime();
    if (parent == NULL)
        LOG_ERROR("parent==NULL");
    INDEX_TYPE count = 0;
    INDEX_TYPE *mark = lu_calloc(n, sizeof(INDEX_TYPE));

    for (INDEX_TYPE r = 0; r < n; ++r) {
        mark[r] = r; //标记是否被添加过
        for (INDEX_TYPE k = Ap[r]; k < Ap[r + 1]; ++k) {
            INDEX_TYPE c = Ai[k];
            if (c < r) { //只算下三角
                INDEX_TYPE j = c;
                while (mark[j] != r) {
                    mark[j] = r;
                    j = parent[j];
                    count++;
                }
            }
        }
    }
    lu_free(mark);
    LOG_TIME("calc_l_nz time: %f ms", (omp_get_wtime()-start_time)*1000);
    return count + n;
}

void get_l_col_patterns(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                        const INDEX_TYPE n, const INDEX_TYPE *etree,
                        INDEX_TYPE *Lp, INDEX_TYPE *Li,INDEX_TYPE cut_point1,INDEX_TYPE cut_point2) {
    double start_time = omp_get_wtime();
    long fma_count = 0;
    //双亲表示法转孩子兄弟表示法
    INDEX_TYPE *first_kid = lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    for (INDEX_TYPE v = 0; v <= n; first_kid[v++] = -1);
    for (INDEX_TYPE v = 0; v <= n; next_kid[v++] = -1);
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = etree[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }
    INDEX_TYPE *mark = lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE l_col_count = 0;
    Lp[0] = 0;
    for (INDEX_TYPE i = 0; i < n; ++i) {
        int row_count = 0;
        //复制自己
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE row = Ai[j];
            if (row <= i) continue;
            Li[l_col_count++] = row;
            mark[row] = i;
            row_count++;
        }
        //查孩子
        INDEX_TYPE child = first_kid[i];
        while (child != -1) {
            // printf("Child of node %lld: %lld\n", i + 1, child + 1);
            //求并集
            for (INDEX_TYPE k = Lp[child + 1] - 1; k >= Lp[child]; k--) {
                INDEX_TYPE row = Li[k];
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Li[l_col_count++] = row;
                    row_count++;
                }
            }
            child = next_kid[child];
        }
        Lp[i + 1] = l_col_count;
        fma_count += row_count * row_count;
        if (i == cut_point1 || i == cut_point2) {
            LOG_DEBUG("cut_point(%lld) fma_count:%ld G", i, fma_count/1024/1024/1024);
        }
    }
    lu_free(mark);
    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    LOG_DEBUG("fma_count:%ld", fma_count);
    LOG_DEBUG("fma_count:%ld G", fma_count/1024/1024/1024);
    LOG_TIME("get_l_col_patterns time: %f ms", (omp_get_wtime()-start_time)*1000);
}

//todo GPT relloc Li，避免执行calc_l_nz
void get_l_row_patterns(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                        const INDEX_TYPE n, const INDEX_TYPE *etree,
                        INDEX_TYPE *Lp, INDEX_TYPE *Li) {
    double start_time = omp_get_wtime();
    INDEX_TYPE *mark = lu_calloc(n, sizeof(INDEX_TYPE));
    Lp[0] = 0;
    INDEX_TYPE l_row_count = 0;
    for (INDEX_TYPE r = 0; r < n; ++r) {
        mark[r] = r; //标记是否被添加过
        for (INDEX_TYPE k = Ap[r]; k < Ap[r + 1]; ++k) {
            INDEX_TYPE c = Ai[k];
            if (c < r) {
                //只算下三角
                while (mark[c] != r) {
                    mark[c] = r;
                    Li[l_row_count++] = c;
                    c = etree[c];
                }
            }
        }
        Lp[r + 1] = l_row_count;
    }
    lu_free(mark);
    LOG_TIME("get_l_row_patterns time: %f ms", (omp_get_wtime()-start_time)*1000);
}

typedef struct {
    INDEX_TYPE num_row; // 行数
    INDEX_TYPE num_col; // 列数
    ELE_TYPE *data; // 行优先密集存储
    INDEX_TYPE *row_idx; //存储本 Supernode 中出现非零的行号
    int row_count; // row_idx 的有效长度
} Supernode;

void get_supernode_patterns(
    const INDEX_TYPE n,
    const INDEX_TYPE *Lp,
    const INDEX_TYPE *Li,
    INDEX_TYPE *Sp,
    INDEX_TYPE *Si
) {
    // mark 数组用于去重
    INDEX_TYPE *mark = lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE idx = 0; // 全局写指针（Si 的当前位置）
    int step = 80;

    Sp[0] = 0;
    for (INDEX_TYPE i = 0; i < n + step; i += step) {
        //第i个supernode
        INDEX_TYPE nn = MAX(i + step, n);
        for (INDEX_TYPE c = i; c < nn; ++c) {
            for (INDEX_TYPE p = Lp[c]; p < Lp[c + 1]; ++p) {
                INDEX_TYPE r = Li[p]; //行号
                // 若 c 在当前 supernode 尚未加入，则加入
                if (mark[r] != i + 1) {
                    mark[r] = i + 1; // 标记为已加入
                    Si[idx++] = r;
                }
            }
        }
        Sp[i + 1] = idx;
        for (INDEX_TYPE j = Sp[i]; j < Sp[i + 1]; j++) {
            printf("%lld, ", Si[j]);
        }
        printf("\n");
    }
    lu_free(mark);
}

int main(int argc, char *argv[]) {
    parse_arguments(argc, argv, &config);
    CSRMatrix *original_matrix = load_matrix_csr(argv[1], false);
    // double maxwork = 0.0, work;
    // int64_t P[original_matrix->num_col], Q[original_matrix->num_col], R[original_matrix->num_col], nmatch;
    // int64_t Workspace[original_matrix->num_col * 5];
    // int64_t btf_x=btf_l_order(original_matrix->num_col, (int64_t*)original_matrix->row_pointers, (int64_t*)original_matrix->col_indices,
    //             maxwork,&work,P, Q, R,&nmatch,Workspace);
    // printf("\nbtf_l_order:%lld\n",btf_x);
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    CSRMatrix *A = reordering(original_matrix, info,true,true);
    CSRMatrix A11, A12, A21, A22;
    blocking_csr_4m(A->num_row, A->row_pointers, A->col_indices, A->csr_values,
                    info->cut_point1, &A11, &A12, &A21, &A22);
    //--------------------------
    double time = omp_get_wtime();
    INDEX_TYPE *etree = lu_malloc(A->num_col * sizeof(INDEX_TYPE));
    INDEX_TYPE *b_ptr, *b_idx;
    INDEX_TYPE bnz = A->nnz * 2;
    a_plus_at(A->num_col, A->nnz, A->row_pointers, A->col_indices, &bnz, &b_ptr, &b_idx);
    sym_etree(b_ptr, b_ptr + 1, b_idx, A->num_col, etree);
    INDEX_TYPE nnz = calc_l_nnz(b_ptr, b_idx, A->num_col, etree);
    LOG_DEBUG("nnz:%ld", nnz);
    LOG_TIME("calc_l_nz total time:%f s", omp_get_wtime()-time);
    INDEX_TYPE *Lp = lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Li = lu_malloc((nnz - A->num_col) * sizeof(INDEX_TYPE));
    get_l_col_patterns(b_ptr, b_idx, A->num_col, etree, Lp, Li, info->cut_point1, info->cut_point2);
    CSRMatrix *l = init_csr_matrix(A->num_col, A->num_col, nnz);
    l->row_pointers = Lp, l->col_indices = Li;
    INDEX_TYPE *Sp = lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Si = lu_malloc((nnz - A->num_col) * sizeof(INDEX_TYPE));
    // get_supernode_patterns(400, Lp, Li, Sp, Si);
    // print_matrix_csr(Sp, Si, 3);
    lu_free(b_ptr);
    lu_free(b_idx);
    lu_free(Lp);
    lu_free(Li);
    lu_free(etree);
    lu_free(Sp);
    lu_free(Si);
    //--------------------------

    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(A11.num_row * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) lu_malloc(A11.num_row * sizeof(ELE_TYPE));
    random_vector(b, A11.num_row);
    solve_sp_diagonal_v0_cuda(A11.row_pointers, A11.col_indices, A11.csr_values,
                         A11.num_row, A11.nnz, x, b);
    check_solving(&A11, x, b);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);
    lu_free(x);
    lu_free(b);
    free_csr_matrix_ptr(&A11);
    free_csr_matrix_ptr(&A12);
    free_csr_matrix_ptr(&A21);
    free_csr_matrix_ptr(&A22);
    free_csr_matrix(A);
    free_csr_matrix(original_matrix);
    free_preprocess_info(info);
    free_config(&config);
    return 0;
}
