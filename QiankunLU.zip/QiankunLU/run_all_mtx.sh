#!/bin/bash

base_dir="/dev/test/mtx"
output_dir="/dev/test/pic"
plot_cmd="/home/wanrenqian/code/QiankunLU/bin/QiankunLU_CPU"

# 创建输出目录（如果不存在）
mkdir -p "$output_dir"

# 遍历所有子目录
for dir in "$base_dir"/*/; do
    # 提取目录名（如 xenon2）
    dir_name=$(basename "$dir")
    # 拼接.mtx文件路径（如 /dev/test/mtx/xenon2/xenon2.mtx）
    mtx_file="${dir}${dir_name}.mtx"
    # 拼接输出图片路径（如 /dev/test/pic/xenon2.jpeg）
    output_file="${output_dir}/${dir_name}.jpeg"

    # 检查.mtx文件是否存在
    if [[ -f "$mtx_file" ]]; then
        # 执行plot命令
        echo "Processing: $mtx_file → $output_file"
        OMP_NUM_THREADS=32 "$plot_cmd" "$mtx_file" "$output_file"
        # 检查命令是否执行成功
        if [[ $? -ne 0 ]]; then
            echo "Error: Failed to process $mtx_file"
        fi
    else
        echo "Warning: $mtx_file does not exist"
    fi
done