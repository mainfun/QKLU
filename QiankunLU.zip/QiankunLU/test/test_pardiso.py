import numpy as np
import scipy.io
import scipy.sparse
from pypardiso import spsolve
import time

# 读取 Matrix Market 文件
matrix_path = '/dev/test/mtx/memchip/memchip.mtx'
A = scipy.io.mmread(matrix_path).tocsr()

# 创建随机右侧向量 b
b = np.random.rand(A.shape[0])

# 测量分解和求解时间
start_time = time.time()
x = spsolve(A, b)
end_time = time.time()

print(f"PyPardiso LU 分解和求解耗时: {(end_time - start_time)*1000:.2f} 毫秒")
