#include <lapacke.h>
#include <base/log.h>
#include <base/matrix.h>
#include <preprocess/etree.h>
#include <preprocess/pivoting.h>
#include "base/file.h"
#include "solve/solving.h"

/**
* 该版本小型超级稀疏矩阵上性能良好
*/
INDEX_TYPE main(INDEX_TYPE argc, char **argv) {
    //-------------- 解析main参数 --------------
    if (argc < 2) {
        LOG_ERROR("错误: 必须指定矩阵名\n用法: %s <矩阵名>", argv[0]);
    }
    CSC o_matrix;
    load_csc(argv[1], &o_matrix);
    left_looking_solve_small_matrix(o_matrix);
    return 0;
}
