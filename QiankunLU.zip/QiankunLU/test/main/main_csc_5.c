#include <float.h>
#include <lapacke.h>
#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <numeric/SpTSTRF.h>
#include <numeric/SpGESSM.h>
#include <numeric/SpSSSSM.h>
#include <numeric/sp_factor.h>
#include <preprocess/etree.h>
#include <preprocess/pivoting.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>
#include "numeric/blocked_csr.h"

extern void swap_index(INDEX_TYPE *a,INDEX_TYPE *b);

/**
* 该版本中型矩阵上性能良好
*/
INDEX_TYPE main(INDEX_TYPE argc, char **argv) {
    //-------------- 解析main参数 --------------
    if (argc < 2) {
        LOG_ERROR("错误: 必须指定矩阵名\n用法: %s <矩阵名>", argv[0]);
    }
    //-------------- 读文件 --------------
    // /dev/test/mtx/g7jac180/g7jac180.mtx
    // ../mtx/test01.mtx
    // /dev/test/mtx/stokes128/stokes128.mtx
    CSC o_matrix;
    load_csc(argv[1], &o_matrix);
    INDEX_TYPE n = o_matrix.num_row;
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    //-------------- reordering --------------
    CSC *A = (CSC *) reordering((CSRMatrix *) &o_matrix, info,true,true);
    // info->cut_point1 = n;
    //-------------- blocking --------------
    CSC A11, A12, A21, A22;
    //把CSC格式的A当成CSR的，这相当于在计算A^T，算出来的结果L+U也是转置的
    blocking_csr_4m(A->num_row, A->col_ptr, A->row_idx, A->values, info->cut_point1,
                    (CSRMatrix *) &A11, (CSRMatrix *) &A21,
                    (CSRMatrix *) &A12, (CSRMatrix *) &A22);
    swap_index(&A21.num_row, &A21.num_col);
    swap_index(&A12.num_row, &A12.num_col);
    //-------------- symbolic analysis --------------
    INDEX_TYPE *etree = create_etree_force2sym((CSRMatrix *) A);
    CSC U11, U12, L11, L21;
    //把CSC格式的A当成CSR的，这相当于在计算A^T，算出来的结果L+U也是转置的
    symbolic_analysis_block(etree, (CSRMatrix *) A, info,
                            (CSRMatrix *) &L11, (CSRMatrix *) &L21,
                            (CSRMatrix *) &U11, (CSRMatrix *) &U12);
    lu_free(etree);
    swap_index(&U12.num_row, &U12.num_col);
    swap_index(&L21.num_row, &L21.num_col);
    double preprocess_time = omp_get_wtime() - start_time;
    //-------------- numerical decomposition --------------
    double numeric_time = omp_get_wtime();
    // print_csc(A);

    int BLOCK_SIDE = 2000;
    int *Sp, *Si, *Bp, *Bi;
    INDEX_TYPE *Sx;
    ELE_TYPE *Bx;
    csr_block(L11.col_ptr, L11.row_idx, BLOCK_SIDE,
              L11.num_row, L11.num_col, L11.nnz, &Sp, &Si, &Sx, &Bp, &Bi, &Bx);
    // print_blocked_csr_dense(n, n, BLOCK_SIDE, Sp, Si, Sx, Bp, Bi,NULL);
    LOG_TIME("numerical time %lf ms", 1000*(omp_get_wtime()-numeric_time));
    //-------------- free memory --------------
    free_preprocess_info(info);
    return 0;
}
