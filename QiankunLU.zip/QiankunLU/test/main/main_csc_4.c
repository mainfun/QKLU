#include <float.h>
#include <lapacke.h>
#include <cblas.h>
#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <numeric/SpTSTRF.h>
#include <numeric/SpGESSM.h>
#include <numeric/SpSSSSM.h>
#include <numeric/sp_factor.h>
#include <preprocess/etree.h>
#include <preprocess/pivoting.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>

extern void swap_index(INDEX_TYPE *a,INDEX_TYPE *b);
double start_time=0;
extern void dtrsm_(char const *, char const *, char const *, char const *,
    int const *, int const *, double const *, double const *, int const *,
    double *, int const *);

/**
* 该版本中型矩阵上性能良好
*/
INDEX_TYPE main(INDEX_TYPE argc, char **argv) {
    //-------------- 解析main参数 --------------
    if (argc < 2) {
        LOG_ERROR("错误: 必须指定矩阵名\n用法: %s <矩阵名>", argv[0]);
    }
    //-------------- 读文件 --------------
    // /dev/test/mtx/g7jac180/g7jac180.mtx
    // ../mtx/test01.mtx
    // /dev/test/mtx/stokes128/stokes128.mtx
    bool is_draw = 1;
    CSC o_matrix;
    load_csc(argv[1], &o_matrix);
    INDEX_TYPE n = o_matrix.num_row;
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    //-------------- reordering --------------
    //传入(CSRMatrix *) &o_matrix相当于传入的是o_matrix的转置，如果o_matrix的转置是对角占优的，那么o_matrix也是
    CSC *A = (CSC *) reordering((CSRMatrix *) &o_matrix, info,true,true);
    // info->cut_point1 = info->cut_point2;
    if (is_draw) info->cut_point1 = n;
    if (is_draw) csr2image_RGB((CSRMatrix*)A, "temp_mc64.jpeg", 4000, 4000);
    if (is_draw) csr2image_RGB((CSRMatrix*)&o_matrix, "temp_o.jpeg", 1000, 1000);
    //-------------- blocking --------------
    CSC A11, A12, A21, A22;
    //把CSC格式的A当成CSR的，这相当于在计算A^T，算出来的结果L+U也是转置的
    blocking_csr_4m(A->num_row, A->col_ptr, A->row_idx, A->values, info->cut_point1,
                    (CSRMatrix *) &A11, (CSRMatrix *) &A21,
                    (CSRMatrix *) &A12, (CSRMatrix *) &A22);
    swap_index(&A21.num_row, &A21.num_col);
    swap_index(&A12.num_row, &A12.num_col);
    //-------------- symbolic analysis --------------
//    INDEX_TYPE *b_ptr, *b_idx;
//    INDEX_TYPE bnz = A->nnz * 2;
//    a_plus_at(A->num_col, A->nnz, A->col_ptr, A->row_idx, &bnz, &b_ptr, &b_idx);
//    CSC B;
//    B.col_ptr=b_ptr;
//    B.row_idx=b_idx;
//    B.num_row=B.num_col=n;
//    B.nnz=bnz;
    //-----------------------------------------------------

    INDEX_TYPE *etree = create_etree_force2sym((CSRMatrix *) A);
    CSC U11, U12, L11, L21;
    //把CSC格式的A当成CSR的，这相当于在计算A^T，算出来的结果L+U也是转置的
    symbolic_analysis_block(etree, (CSRMatrix *) &A, info,
                            (CSRMatrix *) &L11, (CSRMatrix *) &L21,
                            (CSRMatrix *) &U11, (CSRMatrix *) &U12);
    lu_free(etree);
    swap_index(&U12.num_row, &U12.num_col);
    swap_index(&L21.num_row, &L21.num_col);
    double preprocess_time = omp_get_wtime() - start_time;
    if (is_draw) {
        INDEX_TYPE *cuts = info->layer2_splits;
        INDEX_TYPE cuts_len = info->layer2_splits_num;
        INDEX_TYPE start = cuts[0];
        INDEX_TYPE end = cuts[cuts_len - 1];
        // end = n;
        CSRMatrix *pattern = init_csr_matrix(n, n, L11.nnz + U11.nnz);
        INDEX_TYPE *Rp = pattern->row_pointers;
        INDEX_TYPE *Ri = pattern->col_indices;
        //L+U
        INDEX_TYPE index_size = 0;
        Rp[0] = 0;
        for (INDEX_TYPE i = 0; i < n; i++) {
            for (INDEX_TYPE j = U11.col_ptr[i]; j < U11.col_ptr[i + 1]; j++) {
                Ri[index_size++] = U11.row_idx[j];
            }
            for (INDEX_TYPE j = L11.col_ptr[i]; j < L11.col_ptr[i + 1]; j++) {
                Ri[index_size++] = L11.row_idx[j];
            }
            Rp[i + 1] = index_size;
        }
        if (1) {
            csr2image_block_cut(pattern->row_pointers, pattern->col_indices,
                                "LU_2000.jpeg", 0, MIN(2000,n), 0, MIN(2000,n),
                                cuts, 0);
            // csr2image_block_cut(pattern->row_pointers, pattern->col_indices,
            //                     "LU_cut.jpeg", start, end, start, end,
            //                     cuts,
            //                     cuts_len);
        }
        csr2image_RGB(pattern, "temp.jpeg", 4000, 4000);
        // csr2image_RGB((CSRMatrix *) &L11, "L11.jpeg", 2000, 2000);
        // csr2image_RGB((CSRMatrix *) &U11, "U11.jpeg", 2000, 2000);
        exit(1);
    }

    //-------------- numerical decomposition --------------
    //todo L11 U11是空时出错
    double numeric_time = omp_get_wtime();
    // INDEX_TYPE split_points_num;
    // INDEX_TYPE *split_points = dispatch_find_split_points_sym(A11.col_ptr, A11.row_idx,
    //                                                           A11.num_row, &split_points_num);
    // printf("split_points(%lld): ", split_points_num);
    // for (int i = 0; i <= split_points_num; ++i) {
    //     printf("%lld, ", split_points[i]);
    // }
    INDEX_TYPE split_points_num = info->layer1_splits_num;
    INDEX_TYPE *split_points = info->layer1_splits;
    printf("\n");
    L11.values = (ELE_TYPE *) lu_malloc(L11.nnz * sizeof(ELE_TYPE));
    L21.values = (ELE_TYPE *) lu_malloc(L21.nnz * sizeof(ELE_TYPE));
    U11.values = (ELE_TYPE *) lu_malloc((U11.nnz + U12.nnz) * sizeof(ELE_TYPE));
    U12.values = U11.values; //把原来的偏移补上;
    ELE_TYPE *U_diag = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    sp_factor_v7_parallel(A11.col_ptr, A11.row_idx, A11.values,
                          L11.col_ptr, L11.row_idx, L11.values,
                          U11.col_ptr, U11.row_idx, U11.values, U_diag, A11.num_row,
                          split_points_num, split_points);

    SpTSTRF_v2_parallel(&U11, &A21, &L21, U_diag, split_points_num, split_points);
    SpGESSM_v2(&L11, &A12, &U12);

    L2_TYPE *R;
    SpSSSSM_DENSE_v2(&L21, &U12, &A22, &R);
    // print_csc(A);
    // print_dense_matrix(R, A22.num_row);
//    exit(1);
    printf("layer2 split_points(%lld): ", info->layer2_splits_num);
    for (int i = 0; i <= info->layer2_splits_num; ++i) {
        printf("%lld, ", info->layer2_splits[i]);
    }
    printf("\n");
    int dim11 = (int) (info->cut_point2 - info->cut_point1);
    int dim22 = (int) (n - info->cut_point2);
    BBD_Dense *bbd = malloc_BBD_Dense(dim11, dim22, info->layer2_splits, info->layer2_splits_num);
    SpSSSSM_BBD_DENSE(&L21, &U12, &A22, bbd);
    LOG_TIME("sp numeric time:%f s", omp_get_wtime()-numeric_time);
    double bbd_time = omp_get_wtime();
    //todo B11
    LOG_DEBUG("B11 dim:%d", dim11);
    int *ipiv_l2_B11 = (int *) lu_malloc(A22.num_row * sizeof(int));
    for (int i = 0; i < info->layer2_splits_num; ++i) {
        int side = info->layer2_splits[i + 1] - info->layer2_splits[i];
        LAPACK_LU(
            LAPACK_COL_MAJOR,
            side, side,
            bbd->B11_block_ptr[i],
            side,
            ipiv_l2_B11 + info->layer2_splits[i]
        );
        // dtrsm_("Right", "Upper", "No Transpose", "Not unit triangular",
        //        &height, &dsize, &one, blocks[i][i], &ldA, blocks[j][i], &ldA);
        // dtrsm_("Left", "Lower", "No transpose", "Unit triangular",
        //         &dsize, &width, &one, blocks[i][i], &ldA, blocks[i][j], &ldA);
    }

    LOG_TIME("分解B11 time:%f ms", (omp_get_wtime()-numeric_time)*1000);
    double dgemm_time = omp_get_wtime();
    cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans,
                dim22, dim22, dim11,
                -1.0,
                bbd->B12, dim22,
                bbd->B21, dim11,
                1.0,
                bbd->B22, dim22
    );
    LOG_TIME("舒尔补 time:%f ms", (omp_get_wtime()-dgemm_time)*1000);
    double b22_time = omp_get_wtime();
    LOG_DEBUG("B22 dim:%d", dim22);
    int *ipiv_l3_B22 = (int *) lu_malloc(A22.num_row * sizeof(int));
    int lapacke_info_l3 = LAPACK_LU(
        LAPACK_COL_MAJOR,
        dim22, dim22,
        bbd->B22,
        dim22,
        ipiv_l3_B22
    );
    if (lapacke_info_l3 != 0) {
        fprintf(stderr, "LAPACKE_dgetrf failed: info=%d\n", lapacke_info_l3);
        //return 1;
    }
    LOG_TIME("分解B22 time:%f ms", (omp_get_wtime()-b22_time)*1000);
    LOG_TIME("bbd time:%f s", omp_get_wtime()-bbd_time);
    // printf("ipiv_l3:\n");
    // for (int i = 0; i < dim22; ++i) {
    //     printf("%d, ", ipiv_l3_B22[i]);
    // }
    // printf("ipiv_l3:\n");
    // print_csc(A);
    // print_BBD_Dense(bbd, info->layer2_splits, info->layer2_splits_num);
    // exit(2);
    // print_csc(A);
    // print_csc(&L11);
    // print_csc(&U11);
    // print_csc(&L21);
    // print_csc(&U12);
    // printf("U_diag:");
    // for (int i = 0; i < A11.num_row; ++i) {
    //     printf("%.13lf, ", U_diag[i]);
    // }
    // LOG_DEBUG();

    double lapacke_time = omp_get_wtime();
    LOG_DEBUG("dim:%lld", A22.num_row);
    int *ipiv = (int *) lu_malloc(A22.num_row * sizeof(int));
    int lapacke_info = LAPACK_LU(
        LAPACK_COL_MAJOR,
        A22.num_row, A22.num_row,
        R,
        A22.num_row,
        ipiv
    );
    if (lapacke_info != 0) {
        fprintf(stderr, "LAPACKE_dgetrf failed: info=%d\n", lapacke_info);
        //return 1;
    }
    // print_dense_matrix(R, A22.num_row);
    // for (int i = 0; i < A22.num_row; ++i) {
    //     printf("%d, ", ipiv[i]);
    // }
    LOG_DEBUG();
    // print_dense_matrix(R, A22.num_row);
    LOG_TIME("LAPACKE_dgetrf total time:%f s", omp_get_wtime()-lapacke_time);
    LOG_TIME("numeric total time:%f s", omp_get_wtime()-numeric_time);
    LOG_TIME("预处理 time:%f s", preprocess_time);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);

    //-------------- solving --------------
    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) lu_calloc(n, sizeof(ELE_TYPE));
    init_b_csc(&o_matrix, b);
    // random_sp_vector(b,n);
    ELE_TYPE *perm_b = permute_b_csc(b, n, info);
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    lower_solver_csc_block(&L11, &L21, y, perm_b);

    L2_TYPE *lapack_b = (L2_TYPE *) lu_malloc(A22.num_row * sizeof(L2_TYPE));
    for (INDEX_TYPE i = A11.num_row; i < n; ++i) {
        lapack_b[i - A11.num_row] = (L2_TYPE) y[i];
    }
    // printf("lapacke_b:");
    // for (int i = 0; i < A22.num_row; ++i) {
    //     printf("%.13lf, ", lapack_b[i]);
    // }
    // LOG_DEBUG();
    LOG_DEBUG();
    lapacke_info = LAPACK_SOLVE(
        LAPACK_COL_MAJOR,
        'N',
        A22.num_row, 1,
        R, A22.num_row,
        ipiv,
        lapack_b, A22.num_row
    );
    if (lapacke_info != 0) {
        fprintf(stderr, "dgetrs failed, lapacke_info = %d\n", (int) lapacke_info);
        return 1;
    }
    // printf("lapacke_b:");
    // for (int i = 0; i < A22.num_row; ++i) {
    //     printf("%.13lf, ", lapack_b[i]);
    // }
    LOG_DEBUG();
    for (INDEX_TYPE i = A11.num_row; i < n; ++i) {
        y[i] = lapack_b[i - A11.num_row];
        // y[i] = 1;
    }
    upper_solver_csc_exclude_diag_block(&U11, &U12, U_diag, x, y);
    ELE_TYPE *perm_x = permute_x_csc(x, n, info);
    // printf("x        :");
    // for (int i = 0; i < n; ++i) {
    //     printf("%.13lf, ", x[i]);
    // }
    printf("\n");
    check_solving_csc(&o_matrix, perm_x, b);
    LOG_TIME("Total time:%f s", omp_get_wtime()-start_time);
    //-------------- free memory --------------
    lu_free(ipiv);
    lu_free(b);
    lu_free(x);
    lu_free(y);
    lu_free(perm_b);
    lu_free(perm_x);
    lu_free(R);
    free_csc3(&o_matrix);
    free_csc3(A);
    // lu_free(A);
    free_csc3(&A11), free_csc3(&A12), free_csc3(&A21), free_csc3(&A22);
    free_csc3(&L11);
    // free_csc3(&U11);
    free_csc3(&L21);
    lu_free(U_diag);
    free_preprocess_info(info);
    return 0;
}
