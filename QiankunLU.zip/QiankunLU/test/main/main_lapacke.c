#include <lapacke.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_util.h>
#include <preprocess/etree.h>
#include <preprocess/pivoting.h>
#include "base/file.h"
#include "solve/check.h"

INDEX_TYPE main() {
    CSC o_matrix;
    char *f;
    f = "../mtx/test01.mtx";
    f = "/dev/test/mtx/k3plates/k3plates.mtx";
    f = "/dev/test/mtx/onetone1/onetone1.mtx";
    load_csc(f, &o_matrix);
    int n = o_matrix.num_row;
    ELE_TYPE *b = (ELE_TYPE *) lu_calloc(n, sizeof(ELE_TYPE));
    init_b_csc(&o_matrix, b);
    // for (int i = 0; i < n; ++i) {
    //     printf("%.13lf, ", b[i]);
    // }
    ELE_TYPE *D = csr2dense((CSRMatrix*)&o_matrix);
    // print_dense_matrix(D, n);
    LOG_DEBUG();
    // print_csc(&o_matrix);
    LOG_DEBUG("dim:%d", n);
    int *ipiv = (int *) lu_malloc(n * sizeof(int));
    int lapacke_info = LAPACKE_dgetrf(
        LAPACK_COL_MAJOR,
        n, n,
        D,
        n,
        ipiv
    );
    if (lapacke_info != 0) {
        fprintf(stderr, "LAPACKE_dgetrf failed: info=%d\n", lapacke_info);
        return 1;
    }
    lapacke_info = LAPACKE_dgetrs(
        LAPACK_COL_MAJOR,
        'N',
        n, 1,
        D, n,
        ipiv,
        b, n
    );
    if (lapacke_info != 0) {
        fprintf(stderr, "dgetrs failed, lapacke_info = %d\n", (int) lapacke_info);
        return 1;
    }
    LOG_DEBUG();
    // print_dense_matrix(D, n);
    for (int i = 0; i < n; ++i) {
        printf("%lf, ", b[i]);
    }
    return 0;
}
