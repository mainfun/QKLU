#include <float.h>
#include <lapacke.h>
#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <numeric/SpTSTRF.h>
#include <numeric/SpGESSM.h>
#include <numeric/SpSSSSM.h>
#include <numeric/sp_factor.h>
#include <preprocess/etree.h>
#include <preprocess/pivoting.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>
#include <numeric/dense_lu.cuh>

extern void swap_index(INDEX_TYPE *a,INDEX_TYPE *b);

/**
* 该版本添加了GPU分解
*/
INDEX_TYPE main(INDEX_TYPE argc, char **argv) {
    //-------------- 解析main参数 --------------
    if (argc < 2) {
        LOG_ERROR("错误: 必须指定矩阵名\n用法: %s <矩阵名>", argv[0]);
    }
    //-------------- 读文件 --------------
    // /dev/test/mtx/g7jac180/g7jac180.mtx
    // ../mtx/test01.mtx
    // /dev/test/mtx/stokes128/stokes128.mtx
    CSC o_matrix;
    load_csc(argv[1], &o_matrix);
     double warmup_time = omp_get_wtime();
     warmup_cuda_async();
     LOG_TIME("warmup_time:%f s", omp_get_wtime()-warmup_time);
    INDEX_TYPE n = o_matrix.num_row;
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    //-------------- reordering --------------
    CSC *A = (CSC *) reordering((CSRMatrix *) &o_matrix, info,true,true);
    // info->cut_point1 = info->cut_point2;
    // info->cut_point1 = 0;
    //-------------- blocking --------------
    CSC A11, A12, A21, A22;
    //把CSC格式的A当成CSR的，这相当于在计算A^T，算出来的结果L+U也是转置的
    blocking_csr_4m(A->num_row, A->col_ptr, A->row_idx, A->values, info->cut_point1,
                    (CSRMatrix *) &A11, (CSRMatrix *) &A21,
                    (CSRMatrix *) &A12, (CSRMatrix *) &A22);
    swap_index(&A21.num_row, &A21.num_col);
    swap_index(&A12.num_row, &A12.num_col);
    //-------------- symbolic analysis --------------
    INDEX_TYPE *etree = create_etree_force2sym((CSRMatrix *) A);
    CSC U11, U12, L11, L21;
    //把CSC格式的A当成CSR的，这相当于在计算A^T，算出来的结果L+U也是转置的
    symbolic_analysis_block(etree, (CSRMatrix *) A, info,
                            (CSRMatrix *) &L11, (CSRMatrix *) &L21,
                            (CSRMatrix *) &U11, (CSRMatrix *) &U12);
    lu_free(etree);
    swap_index(&U12.num_row, &U12.num_col);
    swap_index(&L21.num_row, &L21.num_col);
    double preprocess_time = omp_get_wtime() - start_time;
    //-------------- numerical decomposition --------------
    double numeric_time = omp_get_wtime();
    INDEX_TYPE split_points_num;
    INDEX_TYPE *split_points = dispatch_find_split_points_sym(A11.col_ptr, A11.row_idx,
                                                              A11.num_row, &split_points_num);
    L11.values = (ELE_TYPE *) lu_malloc(L11.nnz * sizeof(ELE_TYPE));
    L21.values = (ELE_TYPE *) lu_malloc(L21.nnz * sizeof(ELE_TYPE));
    U11.values = (ELE_TYPE *) lu_malloc((U11.nnz + U12.nnz) * sizeof(ELE_TYPE));
    U12.values = U11.values; //把原来的偏移补上;

    ELE_TYPE *U_diag = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    sp_factor_v7_parallel(A11.col_ptr, A11.row_idx, A11.values,
                          L11.col_ptr, L11.row_idx, L11.values,
                          U11.col_ptr, U11.row_idx, U11.values, U_diag, A11.num_row,
                          split_points_num, split_points);

    SpTSTRF_v2_parallel(&U11, &A21, &L21, U_diag, split_points_num, split_points);
    SpGESSM_v2(&L11, &A12, &U12);
    L2_TYPE *R;
    SpSSSSM_DENSE_v2(&L21, &U12, &A22, &R);

    // print_csc(A);
    // print_csc(&L11);
    // print_csc(&U11);
    // print_csc(&L21);
    // print_csc(&U12);
    // printf("U_diag:");
    // for (int i = 0; i < A11.num_row; ++i) {
    //     printf("%.13lf, ", U_diag[i]);
    // }
    // LOG_DEBUG();

    LOG_TIME("sp numeric time:%f s", omp_get_wtime()-numeric_time);
    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) lu_calloc(n, sizeof(ELE_TYPE));
    init_b_csc(&o_matrix, b);
    // random_sp_vector(b,n);
    ELE_TYPE *perm_b = permute_b_csc(b, n, info);
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    lower_solver_csc_block(&L11, &L21, y, perm_b);
    L2_TYPE *lapack_b = (L2_TYPE *) lu_malloc(A22.num_row * sizeof(L2_TYPE));
    for (INDEX_TYPE i = A11.num_row; i < n; ++i) {
        lapack_b[i - A11.num_row] = (L2_TYPE) y[i];
    }

    double lapacke_time = omp_get_wtime();
    LOG_DEBUG("dim:%lld", A22.num_row);
    //-----------------------dgesv---------------------------
    if (0) {
        int *ipiv = (int *) lu_malloc(A22.num_row * sizeof(int));
        int lapacke_info = LAPACKE_dgesv(
            LAPACK_COL_MAJOR,
            A22.num_row, 1,
            R, A22.num_row,
            ipiv,
            lapack_b, A22.num_row
        );
        if (lapacke_info != 0) {
            fprintf(stderr, "LAPACKE_dgetrf failed: info=%d\n", lapacke_info);
            //return 1;
        }
        lu_free(ipiv);
    }else {
        solve_dense_lu(A22.num_row, 1, R, A22.num_row, lapack_b, A22.num_row);
    }
    //-----------------------dgesv---------------------------
    for (INDEX_TYPE i = A11.num_row; i < n; ++i) {
        y[i] = lapack_b[i - A11.num_row];
        // y[i] = 1;
    }
    LOG_TIME("LAPACKE_dgetrf total time:%f s", omp_get_wtime()-lapacke_time);
    LOG_TIME("numeric total time:%f s", omp_get_wtime()-numeric_time);
    LOG_TIME("预处理 time:%f s", preprocess_time);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);

    //-------------- solving --------------
    upper_solver_csc_exclude_diag_block(&U11, &U12, U_diag, x, y);
    ELE_TYPE *perm_x = permute_x_csc(x, n, info);
    // printf("x        :");
    // for (int i = 0; i < n; ++i) {
    //     printf("%.13lf, ", x[i]);
    // }
    printf("\n");
    check_solving_csc(&o_matrix, perm_x, b);
    LOG_TIME("Total time:%f s", omp_get_wtime()-start_time);
    //-------------- free memory --------------
    lu_free(b);
    lu_free(x);
    lu_free(y);
    lu_free(perm_b);
    lu_free(perm_x);
    lu_free(R);
    free_csc3(&o_matrix);
    free_csc3(A);
    // lu_free(A);
    free_csc3(&A11), free_csc3(&A12), free_csc3(&A21), free_csc3(&A22);
    free_csc3(&L11);
    // free_csc3(&U11);
    free_csc3(&L21);
    lu_free(U_diag);
    free_preprocess_info(info);
    return 0;
}
