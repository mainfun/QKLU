#include <stdio.h>
#include <math.h>

#define N 3  // 固定为3x3矩阵

// 稠密LU分解（含部分选主元）
int lu_decompose(double A[N][N], int p[N]) {
    int i, j, k;

    // 初始化置换向量
    for (i = 0; i < N; i++) p[i] = i;

    for (k = 0; k < N; k++) {
        // 部分选主元
        int max_row = k;
        double max_val = fabs(A[k][k]);
        for (i = k + 1; i < N; i++) {
            if (fabs(A[i][k]) > max_val) {
                max_row = i;
                max_val = fabs(A[i][k]);
            }
        }

        if (max_val < 1e-12) return -1;  // 矩阵奇异

        // 交换行数据（完整复制行元素）
        if (max_row != k) {
            // 交换置换向量
            int temp_p = p[k];
            p[k] = p[max_row];
            p[max_row] = temp_p;

            // 交换矩阵行
            double temp_row[N];
            for (j = 0; j < N; j++) {
                temp_row[j] = A[k][j];
                A[k][j] = A[max_row][j];
                A[max_row][j] = temp_row[j];
            }
        }

        // LU分解核心计算
        for (i = k + 1; i < N; i++) {
            A[i][k] /= A[k][k];
            for (j = k + 1; j < N; j++) {
                A[i][j] -= A[i][k] * A[k][j];
            }
        }
    }
    return 0;
}

// 前代法求解Ly = Pb
void forward_substitution(const double L[N][N], const double pb[N], double y[N]) {
    for (int i = 0; i < N; i++) {
        y[i] = pb[i];
        for (int j = 0; j < i; j++) {
            y[i] -= L[i][j] * y[j];
        }
    }
}

// 回代法求解Ux = y
void backward_substitution(const double U[N][N], const double y[N], double x[N]) {
    for (int i = N - 1; i >= 0; i--) {
        x[i] = y[i];
        for (int j = i + 1; j < N; j++) {
            x[i] -= U[i][j] * x[j];
        }
        x[i] /= U[i][i];
    }
}

int main() {
    // 完全固定的矩阵和向量 (编译期初始化)
    double A[N][N] = {
        { 2, -1, -2},    // 系数矩阵
        {-4,  6,  3},
        {-4, -2,  8}
    };
    double b[N] = {5, -7, 22};  // 右侧向量

    // 备份原始矩阵用于显示（可选）
    double A_copy[N][N];
    int p[N];  // 置换向量

    // 保留原始矩阵的副本
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            A_copy[i][j] = A[i][j];

    // 执行LU分解
    if (lu_decompose(A, p) != 0) {
        printf("矩阵奇异，无法求解\n");
        return -1;
    }

    // 应用置换到向量b
    double pb[N];
    for (int i = 0; i < N; i++)
        pb[i] = b[p[i]];

    // 解方程
    double y[N], x[N];
    forward_substitution(A, pb, y);
    backward_substitution(A, y, x);

    // 打印结果
    printf("L/U合并矩阵:\n");
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%8.4f ", (i > j) ? A[i][j] : A[i][j]);  // 显示L和U的合并存储
        }
        printf("\n");
    }

    printf("\n解向量:\n");
    for (int i = 0; i < N; i++) {
        printf("x[%d] = %8.4f\n", i, x[i]);
    }

    return 0;
}