#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cblas.h>

double get_time_in_seconds() {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

// 随机填充 rows x cols 的矩阵
void random_fill(double* A, int rows, int cols) {
    for (int i = 0; i < rows * cols; ++i) {
        A[i] = (double)rand() / RAND_MAX;
    }
}


int main(int argc, char *argv[]) {
    // 矩阵尺寸：A 是 N x M，B 是 M x K，C 是 N x K
    if (argc != 5) {
        fprintf(stderr,
                "Usage: %s N M K repeat\n"
                "  N      number of rows of A and C\n"
                "  M      number of cols of A and rows of B\n"
                "  K      number of cols of B and C\n"
                "  repeat number of times to repeat the GEMM\n",
                argv[0]);
        return EXIT_FAILURE;
    }

    int N      = atoi(argv[1]);
    int M      = atoi(argv[2]);
    int K      = atoi(argv[3]);
    int repeat = atoi(argv[4]);

    if (N <= 0 || M <= 0 || K <= 0 || repeat <= 0) {
        fprintf(stderr, "All parameters must be positive integers.\n");
        return EXIT_FAILURE;
    }

    srand((unsigned)time(NULL));


    // 分配指针数组
    double **A_list = (double**)malloc(repeat * sizeof(double*));
    double **B_list = (double**)malloc(repeat * sizeof(double*));
    double **C_list = (double**)malloc(repeat * sizeof(double*));

    // 为每一次乘法准备不同的数据块
    for (int i = 0; i < repeat; ++i) {
        A_list[i] = (double*)malloc(N * M * sizeof(double));
        B_list[i] = (double*)malloc(M * K * sizeof(double));
        C_list[i] = (double*)malloc(N * K * sizeof(double));
        random_fill(A_list[i], N, M);
        random_fill(B_list[i], M, K);
        // C 可以不初始化，beta=0 时直接写入
    }

    double alpha = 1.0, beta = 0.0;
    double start = get_time_in_seconds();

    for (int i = 0; i < repeat; ++i) {
        // RowMajor 下： A(N×M), B(M×K), C(N×K)
        // 参数：M = 内维，lda = M，ldb = K，ldc = K
        cblas_dgemm(
            CblasRowMajor,
            CblasNoTrans, CblasNoTrans,
            /* M */ N,   /* N */ K,   /* K */ M,
            alpha,
            A_list[i], M,
            B_list[i], K,
            beta,
            C_list[i], K
        );
    }

    double end = get_time_in_seconds();
    double elapsed = end - start;
    // 以“乘加”计 2 FLOP：总计 2*N*M*K*repeat
    double gflops = 2.0 * N * M * K * repeat / (elapsed * 1e9);

    printf("A: %dx%d, B: %dx%d, repeat=%d\n", N, M, M, K, repeat);
    printf("Time: %.6f s, Performance: %.3f GFLOPS\n", elapsed, gflops);

    // 释放内存
    for (int i = 0; i < repeat; ++i) {
        free(A_list[i]);
        free(B_list[i]);
        free(C_list[i]);
    }
    free(A_list); free(B_list); free(C_list);
    return 0;
}
