#include <stdio.h>
#include <base/file.h>
#include <base/vector_util.h>
#include <solve/check.h>

#include "klu.h"

int main(void) {
    INDEX_TYPE M, N;
    INDEX_TYPE nnz;
    INDEX_TYPE *Ap, *Ai;
    ELE_TYPE *Ax;
    // const char *filename = "/dev/test/mtx/onetone1/onetone1.mtx";
    // const char *filename = "../mtx/9A.mtx";
    const char *filename = "/dev/test/mtx/ASIC_680ks/ASIC_680ks.mtx";
    read_mtx_csc(filename, &M, &N, &nnz, &Ap, &Ai, &Ax);
    if (M != N) {
        LOG_ERROR("非方阵没有LU分解");
    }
    double time = omp_get_wtime();
    int n = N;
    /* Create KLU common and symbolic/numeric objects */
    klu_l_common Common;
    klu_l_symbolic *Symbolic;
    klu_l_numeric *Numeric;

    /* Initialize Common */
    klu_l_defaults(&Common);

    /* Symbolic analysis */
    Symbolic = klu_l_analyze(n, (int64_t *) Ap, (int64_t *) Ai, &Common);
    if (!Symbolic) {
        printf("Symbolic analysis failed.\n");
        return 1;
    }
    double fator_time = omp_get_wtime();
    /* Numeric factorization */
    Numeric = klu_l_factor((int64_t *) Ap, (int64_t *) Ai, Ax, Symbolic, &Common);
    if (!Numeric) {
        printf("Numeric factorization failed.\n");
        klu_l_free_symbolic(&Symbolic, &Common);
        return 2;
    }
    LOG_TIME("fator time : %lf ms", 1000*(omp_get_wtime()-fator_time));
    LOG_TIME("total time : %lf ms", 1000*(omp_get_wtime()-time));
    ELE_TYPE *b = (ELE_TYPE *) lu_calloc(n, sizeof(ELE_TYPE));
    for (INDEX_TYPE col = 0; col < n; ++col) {
        for (INDEX_TYPE k = Ap[col]; k < Ap[col + 1]; ++k) {
            INDEX_TYPE row = Ai[k];
            b[row] += Ax[k];
        }
    }
    /* Solve A*x = b (overwrites b with solution x) */
    klu_l_solve(Symbolic, Numeric, n, 1, b, &Common);

    /* Print solution */
    printf("Solution x:\n");
    for (int i = 0; i < 3; i++) {
        printf("x[%d] = %g\n", i, b[i]);
    }
    // check_solving_csc(&o_matrix, x, b);
    /* Free resources */
    klu_l_free_numeric(&Numeric, &Common);
    klu_l_free_symbolic(&Symbolic, &Common);
    return 0;
}
