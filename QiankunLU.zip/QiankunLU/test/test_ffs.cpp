#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <cuda_runtime.h>
#include <cusparse.h>

#define CHECK_CUDA(func)                                                       \
{                                                                              \
    cudaError_t status = (func);                                               \
    if (status != cudaSuccess) {                                               \
        printf("CUDA failed at %s:%d with error: %s (%d)\n", __FILE__, __LINE__,\
               cudaGetErrorString(status), status);                            \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}

#define CHECK_CUSPARSE(func)                                                   \
{                                                                              \
    cusparseStatus_t status = (func);                                          \
    if (status != CUSPARSE_STATUS_SUCCESS) {                                   \
        printf("CUSPARSE failed at %s:%d with error: %s\n", __FILE__, __LINE__, \
               cusparseGetErrorString(status));                                \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}

void generate_random_sparse_csr(int M, int N, int nnz_per_row,
                                 std::vector<int>& csrRowPtr,
                                 std::vector<int>& csrColInd,
                                 std::vector<float>& values) {
    csrRowPtr.resize(M + 1);
    csrColInd.resize(M * nnz_per_row);
    values.resize(M * nnz_per_row, 1.0f);

    csrRowPtr[0] = 0;
    for (int i = 0; i < M; ++i) {
        std::vector<int> cols(N);
        for (int j = 0; j < N; ++j) cols[j] = j;
        std::random_shuffle(cols.begin(), cols.end());
        std::sort(cols.begin(), cols.begin() + nnz_per_row);
        for (int j = 0; j < nnz_per_row; ++j)
            csrColInd[i * nnz_per_row + j] = cols[j];
        csrRowPtr[i + 1] = csrRowPtr[i] + nnz_per_row;
    }
}

int main() {
    const int N = 16384;       // 矩阵维度 N x N
    const int nnz_per_row = 16; // 每行非零元素数
    const int num_runs = 10;    // 运行次数取平均

    // 生成主机端CSR格式的稀疏矩阵A和B
    std::vector<int> hA_csrRowPtr, hA_csrColInd;
    std::vector<float> hA_values;
    generate_random_sparse_csr(N, N, nnz_per_row, hA_csrRowPtr, hA_csrColInd, hA_values);
    int nnz_A = hA_csrRowPtr.back();

    std::vector<int> hB_csrRowPtr, hB_csrColInd;
    std::vector<float> hB_values;
    generate_random_sparse_csr(N, N, nnz_per_row, hB_csrRowPtr, hB_csrColInd, hB_values);
    int nnz_B = hB_csrRowPtr.back();

    // 计算理论FLOP（基于稀疏结构）
    int64_t total_flops = 0;
    for (int i = 0; i < nnz_A; ++i) {
        int k = hA_csrColInd[i];
        int b_nnz = hB_csrRowPtr[k + 1] - hB_csrRowPtr[k];
        total_flops += b_nnz;
    }
    total_flops *= 2; // 每个乘加算2 FLOP
    printf("Total FLOPs: %ld\n", total_flops);

    // 分配设备端内存并拷贝数据
    int *dA_csrRowPtr, *dA_csrColInd;
    float *dA_values;
    CHECK_CUDA(cudaMalloc(&dA_csrRowPtr, (N + 1) * sizeof(int)));
    CHECK_CUDA(cudaMemcpy(dA_csrRowPtr, hA_csrRowPtr.data(), (N + 1) * sizeof(int), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMalloc(&dA_csrColInd, nnz_A * sizeof(int)));
    CHECK_CUDA(cudaMemcpy(dA_csrColInd, hA_csrColInd.data(), nnz_A * sizeof(int), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMalloc(&dA_values, nnz_A * sizeof(float)));
    CHECK_CUDA(cudaMemcpy(dA_values, hA_values.data(), nnz_A * sizeof(float), cudaMemcpyHostToDevice));

    int *dB_csrRowPtr, *dB_csrColInd;
    float *dB_values;
    CHECK_CUDA(cudaMalloc(&dB_csrRowPtr, (N + 1) * sizeof(int)));
    CHECK_CUDA(cudaMemcpy(dB_csrRowPtr, hB_csrRowPtr.data(), (N + 1) * sizeof(int), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMalloc(&dB_csrColInd, nnz_B * sizeof(int)));
    CHECK_CUDA(cudaMemcpy(dB_csrColInd, hB_csrColInd.data(), nnz_B * sizeof(int), cudaMemcpyHostToDevice));
    CHECK_CUDA(cudaMalloc(&dB_values, nnz_B * sizeof(float)));
    CHECK_CUDA(cudaMemcpy(dB_values, hB_values.data(), nnz_B * sizeof(float), cudaMemcpyHostToDevice));

    // 初始化cuSPARSE
    cusparseHandle_t handle;
    CHECK_CUSPARSE(cusparseCreate(&handle));

    // 创建稀疏矩阵描述符
    cusparseSpMatDescr_t matA, matB, matC;
    CHECK_CUSPARSE(cusparseCreateCsr(&matA, N, N, nnz_A, dA_csrRowPtr, dA_csrColInd, dA_values,
                                     CUSPARSE_INDEX_32I, CUSPARSE_INDEX_32I,
                                     CUSPARSE_INDEX_BASE_ZERO, CUDA_R_32F));
    CHECK_CUSPARSE(cusparseCreateCsr(&matB, N, N, nnz_B, dB_csrRowPtr, dB_csrColInd, dB_values,
                                     CUSPARSE_INDEX_32I, CUSPARSE_INDEX_32I,
                                     CUSPARSE_INDEX_BASE_ZERO, CUDA_R_32F));
    CHECK_CUSPARSE(cusparseCreateCsr(&matC, N, N, 0, nullptr, nullptr, nullptr,
                                     CUSPARSE_INDEX_32I, CUSPARSE_INDEX_32I,
                                     CUSPARSE_INDEX_BASE_ZERO, CUDA_R_32F));

    // 创建SPGEMM描述符
    cusparseSpGEMMDescr_t spgemmDesc;
    CHECK_CUSPARSE(cusparseSpGEMM_createDescr(&spgemmDesc));

    // 参数设置
    float alpha = 1.0f, beta = 0.0f;

    // 估算工作缓冲区大小
    size_t workBufferSize;
    CHECK_CUSPARSE(cusparseSpGEMM_workEstimation(handle, CUSPARSE_OPERATION_NON_TRANSPOSE, CUSPARSE_OPERATION_NON_TRANSPOSE,
                                                 &alpha, matA, matB, &beta, matC, CUDA_R_32F,
                                                 CUSPARSE_SPGEMM_DEFAULT, spgemmDesc, &workBufferSize, nullptr));
    void* workBuffer;
    CHECK_CUDA(cudaMalloc(&workBuffer, workBufferSize));
    CHECK_CUSPARSE(cusparseSpGEMM_workEstimation(handle, CUSPARSE_OPERATION_NON_TRANSPOSE, CUSPARSE_OPERATION_NON_TRANSPOSE,
                                                 &alpha, matA, matB, &beta, matC, CUDA_R_32F,
                                                 CUSPARSE_SPGEMM_DEFAULT, spgemmDesc, &workBufferSize, workBuffer));

    // 计算缓冲区大小
    size_t computeBufferSize1, computeBufferSize2;
    CHECK_CUSPARSE(cusparseSpGEMM_compute(handle, CUSPARSE_OPERATION_NON_TRANSPOSE, CUSPARSE_OPERATION_NON_TRANSPOSE,
                                          &alpha, matA, matB, &beta, matC, CUDA_R_32F,
                                          CUSPARSE_SPGEMM_DEFAULT, spgemmDesc, &computeBufferSize1, nullptr, &computeBufferSize2, nullptr));
    void* computeBuffer1, *computeBuffer2;
    CHECK_CUDA(cudaMalloc(&computeBuffer1, computeBufferSize1));
    CHECK_CUDA(cudaMalloc(&computeBuffer2, computeBufferSize2));

    // 预热运行
    CHECK_CUSPARSE(cusparseSpGEMM_compute(handle, CUSPARSE_OPERATION_NON_TRANSPOSE, CUSPARSE_OPERATION_NON_TRANSPOSE,
                                          &alpha, matA, matB, &beta, matC, CUDA_R_32F,
                                          CUSPARSE_SPGEMM_DEFAULT, spgemmDesc, &computeBufferSize1, computeBuffer1, &computeBufferSize2, computeBuffer2));

    // 时间测量
    cudaEvent_t start, stop;
    CHECK_CUDA(cudaEventCreate(&start));
    CHECK_CUDA(cudaEventCreate(&stop));
    float total_time = 0;

    for (int run = 0; run < num_runs; ++run) {
        CHECK_CUDA(cudaEventRecord(start));
        CHECK_CUSPARSE(cusparseSpGEMM_compute(handle, CUSPARSE_OPERATION_NON_TRANSPOSE, CUSPARSE_OPERATION_NON_TRANSPOSE,
                                              &alpha, matA, matB, &beta, matC, CUDA_R_32F,
                                              CUSPARSE_SPGEMM_DEFAULT, spgemmDesc, &computeBufferSize1, computeBuffer1, &computeBufferSize2, computeBuffer2));
        CHECK_CUSPARSE(cusparseSpGEMM_copy(handle, CUSPARSE_OPERATION_NON_TRANSPOSE, CUSPARSE_OPERATION_NON_TRANSPOSE,
                                           &alpha, matA, matB, &beta, matC, CUDA_R_32F,
                                           CUSPARSE_SPGEMM_DEFAULT, spgemmDesc));
        CHECK_CUDA(cudaEventRecord(stop));
        CHECK_CUDA(cudaEventSynchronize(stop));
        float ms;
        CHECK_CUDA(cudaEventElapsedTime(&ms, start, stop));
        total_time += ms;
    }

    // 计算平均时间和FLOPS
    float avg_time = total_time / num_runs;
    float flops = total_flops / (avg_time / 1000.0f);
    printf("Average SPGEMM time: %.3f ms\n", avg_time);
    printf("Achieved FLOPS: %.2e\n", flops);

    // 清理资源
    CHECK_CUSPARSE(cusparseSpGEMM_destroyDescr(spgemmDesc));
    CHECK_CUSPARSE(cusparseDestroySpMat(matA));
    CHECK_CUSPARSE(cusparseDestroySpMat(matB));
    CHECK_CUSPARSE(cusparseDestroySpMat(matC));
    CHECK_CUSPARSE(cusparseDestroy(handle));
    cudaFree(dA_csrRowPtr);
    cudaFree(dA_csrColInd);
    cudaFree(dA_values);
    cudaFree(dB_csrRowPtr);
    cudaFree(dB_csrColInd);
    cudaFree(dB_values);
    cudaFree(workBuffer);
    cudaFree(computeBuffer1);
    cudaFree(computeBuffer2);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}