#include <btf.h>
#include <float.h>
#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <numeric/SpTSTRF.h>
#include <numeric/sp_factor.h>
#include <preprocess/etree.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>
#include "SuiteSparse_config.h"
#include "base/sort.h"

Config config;

void merge_similar_columns_timestamp(
    int nrows, int ncols,
    const int *col_ptr, const int *row_idx,
    int threshold,
    int *p_new_ncols, int **p_new_col_ptr, int **p_new_row_idx) {
    // 1. 计算每列 nnz
    int *nnz = (int*)malloc(ncols * sizeof(int));
    for (int j = 0; j < ncols; ++j) {
        nnz[j] = col_ptr[j + 1] - col_ptr[j];
    }
    char *used = (char*)calloc(ncols, 1);

    // 2. 准备输出数组
    int *new_col_ptr = (int*)malloc((ncols + 1) * sizeof(int));
    int *new_row_idx = (int*)malloc((col_ptr[ncols] + ncols) * sizeof(int));
    int new_ncols = 0, out_pos = 0;
    new_col_ptr[0] = 0;

    // 3. 时间戳数组
    int *mark = (int*)calloc(nrows, sizeof(int));
    int stamp = 1;

    // 4. 对每列分组并合并
    for (int i = 0; i < ncols; ++i) {
        if (used[i]) continue;
        used[i] = 1;
        // 本组成员包含 i
        int *group = (int*)malloc(ncols * sizeof(int));
        int gsz = 0;
        group[gsz++] = i;
        // 找相似列
        for (int j = i + 1; j < ncols; ++j) {
            if (!used[j] && abs(nnz[i] - nnz[j]) <= threshold) {
                used[j] = 1;
                group[gsz++] = j;
            }
        }
        // 5. 时间戳并集
        stamp++; // 新时间戳
        for (int gi = 0; gi < gsz; ++gi) {
            int col = group[gi];
            for (int k = col_ptr[col]; k < col_ptr[col + 1]; ++k) {
                int r = row_idx[k];
                if (mark[r] != stamp) {
                    mark[r] = stamp;
                    new_row_idx[out_pos++] = r;
                }
            }
        }
        // 6. 写入 new_col_ptr
        new_col_ptr[++new_ncols] = out_pos;
        free(group);
    }

    // 7. 回缩
    new_row_idx = (int*)realloc(new_row_idx, out_pos * sizeof(int));
    new_col_ptr = (int*)realloc(new_col_ptr, (new_ncols + 1) * sizeof(int));

    // 8. 输出
    *p_new_ncols = new_ncols;
    *p_new_col_ptr = new_col_ptr;
    *p_new_row_idx = new_row_idx;

    free(nnz);
    free(used);
    free(mark);
}

void detect_supernode(const INDEX_TYPE *etree, const INDEX_TYPE *Lp, const INDEX_TYPE *Li, const INDEX_TYPE n) {
    int *sizes = (int *) lu_calloc(n, sizeof(int));
    int max_size = 0;
    int node_size = 1;
    for (INDEX_TYPE i = 1; i < n; ++i) {
        if (etree[i - 1] == i && Lp[i + 1] - Lp[i] == Lp[i] - Lp[i - 1] - 1) {
            node_size++;
            // printf("\n%lld:     ", i-1);
            // for (INDEX_TYPE j = Lp[i-1]; j < Lp[i]; ++j) {
            //     printf("%lld,", Li[j]);
            // }
            // printf("\t%lld与%lld是supernode\t", i-1,i);
            // printf("\n%lld:\n", i);
            // for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            //     printf("%lld,", Li[j]);
            // }
        } else {
            // printf("node size:%d\n", node_size);
            sizes[node_size]++;
            max_size = MAX(max_size, node_size);
            node_size = 1;
        }
    }
    printf("supernode 大小统计:\n");
    for (int i = 1; i <= max_size; ++i) {
        printf("--------");
    }
    printf("\n|");
    for (int i = 1; i <= max_size; ++i) {
        printf("%7d|", i);
    }
    printf("\n|");
    for (int i = 1; i <= max_size; ++i) {
        printf("%7d|", sizes[i]);
    }
    printf("\n");
    for (int i = 1; i <= max_size; ++i) {
        printf("--------");
    }
    printf("\n");
    printf("大小在两个以内的占比为：%.2f%%\n", (sizes[1] + sizes[2] * 2.0) / n * 100);
    printf("大小在三个以内的占比为：%.2f%%\n", (sizes[1] + sizes[2] * 2 + sizes[3] * 3.0) / n * 100);
    printf("大小在四个以内的占比为：%.2f%%\n", (sizes[1] + sizes[2] * 2 + sizes[3] * 3 + sizes[4] * 4.0) / n * 100);
    lu_free(sizes);
}

//09 metis
//01 metis supernode

int main(int argc, char *argv[]) {
    parse_arguments(argc, argv, &config);
    CSRMatrix *original_matrix = load_matrix_csr(argv[1], false);
    double start_time = omp_get_wtime();
//    double maxwork = 0.0, work;
//    int64_t *P=(int64_t*)lu_malloc(original_matrix->num_col*sizeof(int64_t));
//    int64_t *Q=(int64_t*)lu_malloc(original_matrix->num_col*sizeof(int64_t));
//    int64_t *R=(int64_t*)lu_malloc(original_matrix->num_col*sizeof(int64_t));
//    int64_t nmatch;
//    int64_t *Workspace=(int64_t*)lu_malloc(5*original_matrix->num_col*sizeof(int64_t));
//    int64_t btf_x=btf_l_order(original_matrix->num_col, (int64_t*)original_matrix->row_pointers, (int64_t*)original_matrix->col_indices,
//                maxwork,&work,P, Q, R,&nmatch,Workspace);
//    printf("\nbtf_l_order:%lld\n",btf_x);
//    LOG_TIME("btf time:%f s", omp_get_wtime()-start_time);
    PreprocessInfo *info = init_preprocess_info();
    CSRMatrix *A = reordering(original_matrix, info,true,true);
    CSRMatrix A11, A12, A21, A22;
    blocking_csr_4m(A->num_row, A->row_pointers, A->col_indices, A->csr_values,
                    info->cut_point1, &A11, &A12, &A21, &A22);
    //--------------------------
    INDEX_TYPE split_points_num;
    INDEX_TYPE *split_points = dispatch_find_split_points_sym(A11.row_pointers, A11.col_indices,
                                                              A11.num_col, &split_points_num);
    LOG_DEBUG("sp分块数：%lld", split_points_num);
    double time = omp_get_wtime();
    INDEX_TYPE *aat_ptr, *aat_idx;
    INDEX_TYPE aat_nnz = A->nnz * 2;
    a_plus_at(A->num_col, A->nnz, A->row_pointers, A->col_indices, &aat_nnz, &aat_ptr, &aat_idx);
    INDEX_TYPE *etree = (INDEX_TYPE*)lu_malloc(A->num_col * sizeof(INDEX_TYPE));
    sp_symetree(aat_ptr, aat_ptr + 1, aat_idx, A->num_col, etree);
    // INDEX_TYPE *etree = create_etree(A);
    //--------------------------

    INDEX_TYPE nnz = calc_l_nz(aat_ptr, aat_idx, etree, A->num_col, A->num_col);
    LOG_DEBUG("nnz:%ld", nnz);
    //INDEX_TYPE nnz2 = calc_l_nz_v2(aat_ptr, aat_idx, etree,
                                   // A->num_col, A->num_col,A->row_pointers,A->col_indices);
    INDEX_TYPE nnz3 = calc_l_nz(A->row_pointers, A->col_indices, etree, A->num_col, A->num_col);
    //INDEX_TYPE nnz4 = calc_l_nz_v2(A->row_pointers,A->col_indices, etree, A->num_col, A->num_col,A->row_pointers,A->col_indices);
    //LOG_DEBUG("nnz2:%ld", nnz2);
    LOG_DEBUG("nnz3:%ld", nnz3);
    //LOG_DEBUG("nnz4:%ld", nnz4);
    LOG_TIME("calc_l_nz total time:%f s", omp_get_wtime()-time);
    INDEX_TYPE *Lp = lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Li = lu_malloc((nnz) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Lp_21 = lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Li_21 = lu_malloc(nnz * sizeof(INDEX_TYPE));
    get_l_col_patterns_block(aat_ptr, aat_idx, A->num_col, etree, Lp, Li, Lp_21, Li_21, info->cut_point1,
                             info->cut_point2);
    get_l_col_patterns_naive(A->row_pointers, A->col_indices, A->num_col, etree, Lp, Li, info->cut_point1, info->cut_point2);

    CSRMatrix *l = init_csr_matrix(A->num_col, A->num_col, nnz);
    l->row_pointers = Lp, l->col_indices = Li;
    csr2image_RGB(l,"01.jpeg",4000,4000);
    LOG_DEBUG("绘制完成");

    detect_supernode(etree, Lp, Li, A11.num_col);
    lu_free(aat_ptr);
    lu_free(aat_idx);
    lu_free(etree);
    //--------------------------
    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = 0; i < A11.num_col; ++i) {
        ELE_TYPE sum = 0;
        for (INDEX_TYPE j = A11.row_pointers[i]; j < A11.row_pointers[i + 1]; ++j) {
            sum += A11.csr_values[j];
        }
        b[i] = sum;
    }
//    random_vector(b, A->num_row);

    ELE_TYPE *Lx = (ELE_TYPE *) lu_malloc(nnz * sizeof(ELE_TYPE));
    ELE_TYPE *Ux = (ELE_TYPE *) lu_malloc(nnz * sizeof(ELE_TYPE));
    ELE_TYPE *U_diag = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    // print_dense_matrix(csr2dense(A),A->num_row);

    sp_factor_v5(A11.row_pointers, A11.col_indices, A11.csr_values,
                 Lp, Li, Lx, Ux, U_diag, A11.num_row,
                 split_points_num, split_points);
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    lower_solver_csc(Lp, Li, Lx, A11.num_row, y, b);
    upper_solver_csr_exclude_diag(Lp, Li, Ux, U_diag, A11.num_row, x, y);
    check_solving(&A11, x, b);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);

    // ELE_TYPE *Lx_21 = (ELE_TYPE *) lu_malloc(Lp_21[A11.num_col] * sizeof(ELE_TYPE));
    // SpTSTRF_v0(Lp, Li, Ux,
    //            Lp_21, Li_21, Lx_21,
    //            A21.row_pointers, A21.col_indices, A21.csr_values,
    //            U_diag, A11.num_col, A11.num_row,
    //            split_points_num, split_points);

    lu_free(x);
    lu_free(y);
    lu_free(b);
    lu_free(Lp);
    lu_free(Li);
    lu_free(Lp_21);
    lu_free(Li_21);
    lu_free(Lx);
    lu_free(Ux);
    lu_free(U_diag);
    lu_free(split_points);
    free_csr_matrix_ptr(&A11);
    free_csr_matrix_ptr(&A12);
    free_csr_matrix_ptr(&A21);
    free_csr_matrix_ptr(&A22);
    free_csr_matrix(A);
    free_csr_matrix(original_matrix);
    free_preprocess_info(info);
    free_config(&config);
    return 0;
}
