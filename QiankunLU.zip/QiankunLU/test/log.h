//
// Created by mainf on 2024/9/15.
//

#ifndef QiankunLU_LOG_H
#define QiankunLU_LOG_H
#ifdef __cplusplus
extern "C" {
#endif
#include <time.h>
#include <stdio.h>
#include <string.h>

#include <stdlib.h>
#define SHOW_DEBUG

#ifdef SHOW_DEBUG
#define LOG_DEBUG(message, ...) fprintf(stdout, "[DEBUG]:" message "\n", ##__VA_ARGS__)
#else
#define LOG_DEBUG(message, ...) (void)0
#endif

#define LOG_TIME(message, ...) fprintf(stdout, "[TIME INFO]:" message "\n", ##__VA_ARGS__)

#define LOG_ERROR(message, ...) do { \
        time_t now = time(NULL); \
        char *date = ctime(&now); \
        date[strlen(date) - 1] = '\0';  /* 移除换行符 */ \
        fprintf(stderr, "[ERROR] %s:%d %s --- " message "\n", __FILE__, __LINE__, date, ##__VA_ARGS__); \
        exit(EXIT_FAILURE);                             \
    } while (0)


#ifdef __cplusplus
}
#endif
#endif //QiankunLU_LOG_H
