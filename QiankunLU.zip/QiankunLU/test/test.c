#include <stdio.h>

#include <stdlib.h>

/**
 * reorder_etree - 对称置换 P A P^T 后，重排 etree
 *
 * @n:       矩阵的维度
 * @parent:  原矩阵 A 的 etree 数组，长度 n，根节点用 -1 表示
 * @perm:    置换数组，长度 n，perm[i] = j 表示原 i 行/列 -> 新 j 行/列
 * @new_parent: 输出数组，长度 n，将被填为 A' 的 etree
 */
void reorder_etree(int n, const int *parent,
                   const int *perm, int *new_parent)
{
    int *iperm = (int*)malloc(n * sizeof(int));
    if (!iperm) return;  /* 分配失败 */

    /* 1) 构造逆置换 iperm */
    for (int i = 0; i < n; i++) {
        iperm[perm[i]] = i;
    }
    for (int k = 0; k < n; k++) {
        printf(" %d,",iperm[k]);
    }

    /* 2) 重排 parent */
    for (int k = 0; k < n; k++) {
        int orig_col = iperm[k];      /* 新编号 k 对应的原列 */
        int p = parent[orig_col];     /* 原 etree 中的父节点 */

        if (p < 0) {
            new_parent[k] = -1;        /* 根保持根 */
        } else {
            new_parent[k] = perm[p];   /* 映射到新编号 */
        }
    }

    free(iperm);
}


int main(void)
{
    int n = 5;
    /* 示例 etree: parent[i] = {-1, 0, 1, 1, 2} */
    int parent[5] = { 1, 2, 3, 4, -1 };
    /* 示例置换: 0↔2, 1↔4, 3↔3 */
    int perm[5]   = { 0, 2, 1, 3, 4 };

    int new_parent[5];
    reorder_etree(n, parent, perm, new_parent);

    printf("new etree: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", new_parent[i]);
    }
    puts("");
    return 0;
}
