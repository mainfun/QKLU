#include <stdio.h>
#include <omp.h>

int main(void) {
    // 禁用 OpenMP 的动态线程调整，确保线程数固定
    omp_set_dynamic(0);
    // 设置使用 32 个线程
    omp_set_num_threads(32);

    // 在并行区域外打印最大线程数（受 omp_set_num_threads 控制）
    //printf("OpenMP 要求的最大线程数 = %d\n", omp_get_max_threads());

    // 真正的并行区域：每个线程都会执行一次这里的代码
    #pragma omp parallel
    {
        int tid = omp_get_thread_num();    // 获取线程 ID
        int nt  = omp_get_num_threads();   // 获取线程总数
        #pragma omp critical
        printf("  线程 %d / %d 正在运行\n", tid, nt);
    }

    return 0;
}
