#include <stdio.h>
#include <stdlib.h>
#include <mkl.h>

// 你自定义的数据类型（视具体定义而定）
typedef MKL_INT INDEX_TYPE;
typedef double ELE_TYPE;

// 你的 CSR 矩阵结构
typedef struct CSR_MATRIX {
    INDEX_TYPE num_row;
    INDEX_TYPE num_col;
    INDEX_TYPE nnz;
    INDEX_TYPE *row_pointers;
    INDEX_TYPE *col_indices;
    ELE_TYPE *csr_values;
} CSRMatrix;

// 将 CSRMatrix 转为 MKL 的 sparse_matrix_t
sparse_matrix_t create_mkl_handle_from_csr(const CSRMatrix *mat) {
    sparse_matrix_t mkl_mat;
    mkl_sparse_create_csr(&mkl_mat, SPARSE_INDEX_BASE_ZERO,
                          mat->num_row, mat->num_col,
                          mat->row_pointers,
                          mat->row_pointers + 1,
                          mat->col_indices,
                          mat->csr_values);
    return mkl_mat;
}

// 从 MKL 的 sparse_matrix_t 导出为 CSRMatrix（你自定义结构）
CSRMatrix extract_csr_from_mkl(sparse_matrix_t mkl_mat) {
    CSRMatrix out;
    sparse_index_base_t indexing;
    INDEX_TYPE rows, cols;
    INDEX_TYPE *row_start, *row_end, *cols_idx;
    ELE_TYPE *vals;

    mkl_sparse_export_csr(mkl_mat, &indexing, &rows, &cols, &row_start, &row_end, &cols_idx, &vals);

    out.num_row = rows;
    out.num_col = cols;
    out.nnz = row_end[rows - 1];

    out.row_pointers = (INDEX_TYPE *)malloc((rows + 1) * sizeof(INDEX_TYPE));
    out.col_indices  = (INDEX_TYPE *)malloc(out.nnz * sizeof(INDEX_TYPE));
    out.csr_values   = (ELE_TYPE *)malloc(out.nnz * sizeof(ELE_TYPE));

    for (INDEX_TYPE i = 0; i <= rows; ++i) out.row_pointers[i] = row_start[i];
    for (INDEX_TYPE i = 0; i < out.nnz; ++i) {
        out.col_indices[i] = cols_idx[i];
        out.csr_values[i]  = vals[i];
    }

    return out;
}

// 执行 SpGEMM: C = A * B
CSRMatrix spgemm_csr(const CSRMatrix *A, const CSRMatrix *B) {
    sparse_matrix_t mkl_A = create_mkl_handle_from_csr(A);
    sparse_matrix_t mkl_B = create_mkl_handle_from_csr(B);
    sparse_matrix_t mkl_C;

    // 计算 C = A * B
    mkl_sparse_spmm(SPARSE_OPERATION_NON_TRANSPOSE, mkl_A, mkl_B, &mkl_C);

    // 导出结果到 CSRMatrix
    CSRMatrix C = extract_csr_from_mkl(mkl_C);

    // 清理 MKL handle
    mkl_sparse_destroy(mkl_A);
    mkl_sparse_destroy(mkl_B);
    mkl_sparse_destroy(mkl_C);

    return C;
}

// 释放 CSRMatrix 结构占用的内存
void free_csr_matrix(CSRMatrix *mat) {
    free(mat->row_pointers);
    free(mat->col_indices);
    free(mat->csr_values);
    mat->row_pointers = NULL;
    mat->col_indices = NULL;
    mat->csr_values = NULL;
}