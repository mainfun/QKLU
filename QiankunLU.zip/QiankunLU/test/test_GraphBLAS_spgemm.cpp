#include <stdio.h>
#include <GraphBLAS.h>
#include <base/file.h>
#include <base/log.h>
#include <base/matrix.h>
#include <omp.h>

void SpGEMM_GraphBLAS(CSRMatrix *A, CSRMatrix *B, CSRMatrix *C) {
    GrB_Matrix GA, GB, GC;
    GrB_Info info = GrB_Matrix_import_FP64(&GA, GrB_FP64, A->num_row,
                                           A->num_col,
                                           (GrB_Index *) A->row_pointers,
                                           (GrB_Index *) A->col_indices,
                                           A->csr_values,
                                           A->num_row + 1,
                                           A->nnz,
                                           A->nnz,
                                           GrB_CSR_FORMAT);
    if (info != GrB_SUCCESS) {
        fprintf(stderr, "导入失败A: %d\n", info);
        exit(1);
    }
    info = GrB_Matrix_import_FP64(&GB, GrB_FP64, B->num_row,
                                  B->num_col,
                                  (GrB_Index *) B->row_pointers,
                                  (GrB_Index *) B->col_indices,
                                  B->csr_values,
                                  B->num_row + 1,
                                  B->nnz,
                                  B->nnz,
                                  GrB_CSR_FORMAT);
    if (info != GrB_SUCCESS) {
        fprintf(stderr, "导入失败B: %d\n", info);
        exit(1);
    }

    info = GrB_Matrix_import_FP64(&GC, GrB_FP64, C->num_row,
                                  C->num_col,
                                  (GrB_Index *) C->row_pointers,
                                  (GrB_Index *) C->col_indices,
                                  C->csr_values,
                                  C->num_row + 1,
                                  C->nnz,
                                  C->nnz,
                                  GrB_CSR_FORMAT);
    if (info != GrB_SUCCESS) {
        fprintf(stderr, "导入失败C: %d\n", info);
        exit(1);
    }
    // --------------------------------
    // 2. 执行 C -= A * B
    // --------------------------------
    double start_time = omp_get_wtime();
    info = GrB_mxm(
        GC, // 目标矩阵
        GrB_NULL, // Mask（无掩码）
        GrB_MINUS_FP64, // 累减操作：C = C - (A*B)
        GxB_PLUS_TIMES_FP64, // 半环：乘法和加法
        GA, GB, // 输入矩阵
        GrB_NULL // 描述符（默认行为）
    );
    if (info != GrB_SUCCESS) {
        fprintf(stderr, "计算失败: %d\n", info);
        exit(1);
    }
    LOG_TIME("SpGEMM_GraphBLAS time:%f ms", (omp_get_wtime()-start_time)*1000);
    // --------------------------------
    // 4. 释放资源
    // --------------------------------
    GrB_Matrix_free(&GA);
    GrB_Matrix_free(&GB);
    GrB_Matrix_free(&GC);
    GrB_finalize();
}

int main(int argc, char *argv[]) {
    GrB_init(GrB_NONBLOCKING); // 初始化GraphBLAS（非阻塞模式，自动并行）

    // --------------------------------
    // 1. 定义稀疏矩阵 A, B 和初始矩阵 C
    // --------------------------------
    GrB_Matrix A, C;
    if (argc < 2) { LOG_ERROR("Usage: %s <matrix file>", argv[0]); }
    CSRMatrix *original_matrix = load_matrix_csr(argv[1], false);
    GrB_Info info = GrB_Matrix_import_FP64(&A, GrB_FP64, original_matrix->num_row,
                                           original_matrix->num_col,
                                           (GrB_Index *) original_matrix->row_pointers,
                                           (GrB_Index *) original_matrix->col_indices,
                                           original_matrix->csr_values,
                                           original_matrix->num_row + 1,
                                           original_matrix->nnz,
                                           original_matrix->nnz,
                                           GrB_CSR_FORMAT);
    if (info != GrB_SUCCESS) {
        fprintf(stderr, "导入失败1: %d\n", info);
        exit(1);
    }
    info = GrB_Matrix_import_FP64(&C, GrB_FP64, original_matrix->num_row,
                                  original_matrix->num_col,
                                  (GrB_Index *) original_matrix->row_pointers,
                                  (GrB_Index *) original_matrix->col_indices,
                                  original_matrix->csr_values,
                                  original_matrix->num_row + 1,
                                  original_matrix->nnz,
                                  original_matrix->nnz,
                                  GrB_CSR_FORMAT);
    if (info != GrB_SUCCESS) {
        fprintf(stderr, "导入失败2: %d\n", info);
        exit(1);
    }
    // --------------------------------
    // 2. 执行 C -= A * B
    // --------------------------------
    double start_time = omp_get_wtime();
    info = GrB_mxm(
        C, // 目标矩阵
        GrB_NULL, // Mask（无掩码）
        GrB_MINUS_FP64, // 累减操作：C = C - (A*B)
        GxB_PLUS_TIMES_FP64, // 半环：乘法和加法
        A, A, // 输入矩阵
        GrB_NULL // 描述符（默认行为）
    );
    if (info != GrB_SUCCESS) {
        fprintf(stderr, "计算失败: %d\n", info);
        exit(1);
    }
    LOG_TIME("time:%f ms", (omp_get_wtime()-start_time)*1000);
    // --------------------------------
    // 4. 释放资源
    // --------------------------------
    GrB_Matrix_free(&A);
    GrB_Matrix_free(&C);
    GrB_finalize();

    return 0;
}
