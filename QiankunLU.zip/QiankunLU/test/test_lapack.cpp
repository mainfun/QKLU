//
// Created by mainf on 2025/3/11.
//
#include <iostream>
#include <vector>
#include <random>
#include <omp.h>

#define ELE_TYPE double
#define A(i, j) a[(j) * dim + (i)]  // Macro for column-major access

using namespace std;

extern "C" void dgetrf_(int *dim1, int *dim2, ELE_TYPE *a, int *lda, int *ipiv, int *info);

extern "C" void dgetrs_(char *TRANS, int *N, int *NRHS, ELE_TYPE *A, int *LDA, int *IPIV, ELE_TYPE *B, int *LDB,
                        int *INFO);

extern "C" void sgetrf_(int *dim1, int *dim2, float *a, int *lda, int *ipiv, int *info);

extern "C" void sgetrs_(char *TRANS, int *N, int *NRHS, float *A, int *LDA, int *IPIV, float *B, int *LDB,
                        int *INFO);

void random_matrix(ELE_TYPE matrix[], int dim) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(-0.1, 0.1);
    for (int j = 0; j < dim; ++j) {
        for (int i = 0; i < dim; ++i) {
            matrix[j * dim + i] = dis(gen);
        }
    }
}
int DIVCEIL(int a, int b) {
    return (a + b - 1) / b;
}

int main() {
    char trans = 'N';
    int dim = 500;
    int nrhs = 1;
    int LDA = dim;
    int LDB = dim;
    int info;

    int ipiv[dim + 1];
    ELE_TYPE *a = (ELE_TYPE *) malloc(dim * dim * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) malloc(dim * sizeof(ELE_TYPE));
    // int ldA, ldB, ldC;
    // ldA = ldB = ldC = DIVCEIL(dim, 8) * 8; // align to 64 bytes
    // double *a = (double *) aligned_alloc(8, dim * dim * sizeof(double));
    // double *b = (double *) aligned_alloc(8, dim * dim * sizeof(double));

    // random_matrix(a, dim); // Use the updated function
    // for (int i = 0; i < dim; ++i) {
    //     ELE_TYPE sum = 0;
    //     for (int j = 0; j < dim; ++j) {
    //         sum += A(i, j);
    //     }
    //     b[i] = sum;
    // }

    double time = omp_get_wtime();
    dgetrf_(&dim, &dim, a, &LDA, ipiv, &info);
    printf("time:%lf ms\n", (omp_get_wtime() - time) * 1000);
    // dgetrs_(&trans, &dim, &nrhs, a, &LDA, ipiv, b, &LDB, &info);

    // printf("Solution x:\n");
    // for (int i = 0; i < dim; ++i) {
    //     printf("%lf ", b[i]);
    // }
    // printf("\n");

    return 0;
}