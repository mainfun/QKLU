g++ test_pardiso.c ./base/file.c ./base/matrix.c ./base/sort.cpp ./base/malloc.c -o test_pardiso \
-I${MKLROOT}/include \
-L${MKLROOT}/lib/intel64 \
-lmkl_intel_lp64 -lmkl_sequential -lmkl_core -lpthread -lm