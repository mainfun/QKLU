#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <base/file.h>

#include "mkl_pardiso.h"
#include "mkl_types.h"
#include "mkl_spblas.h"


int read_matrix_market(const char *filename, MKL_INT **ia, MKL_INT **ja, double **a, MKL_INT *n) {
    if (!filename || !ia || !ja || !a || !n) {
        return -1; // 参数错误
    }

    CSRMatrix *csr = load_matrix_csr(filename, false); // 使用0基索引
    // print_dense_matrix(csr2dense(csr),csr->num_col);
    if (!csr) {
        return -2; // 加载失败
    }

    // 只支持方阵（PARDISO 要求）
    if (csr->num_row != csr->num_col) {
        free(csr->row_pointers);
        free(csr->col_indices);
        free(csr->csr_values);
        free(csr);
        return -3;
    }

    *ia = csr->row_pointers;
    *ja = csr->col_indices;
    *a = csr->csr_values;
    *n = csr->num_row;

    // 注意：CSRMatrix 结构体本身不需要了，释放掉（成员已交由外部接管）
    free(csr);
    return 0;
}

MKL_INT main(void) {

    MKL_INT n;
    MKL_INT *ia, *ja;
    double *a;
    if (read_matrix_market("/dev/test/mtx/dc1/dc1.mtx", &ia, &ja, &a, &n) != 0) {
    // if (read_matrix_market("../test/test04.mtx", &ia, &ja, &a, &n) != 0) {
        printf("Failed to read matrix from file\n");
        return -1;
    }

    // printf("ia (row pointers):\n");
    // for (MKL_INT i = 0; i <= n; i++) {
    //     printf(" %d", ia[i]);
    // }
    // printf("\n");
    //
    // // 非零元总数 nnz = ia[n]
    // MKL_INT nnz = ia[n];
    //
    // // ja 和 a 的长度都是 nnz
    // printf("ja (column indices):\n");
    // for (MKL_INT k = 0; k < nnz; k++) {
    //     printf(" %d", ja[k]);
    // }
    // printf("\n");
    //
    // printf("a (values):\n");
    // for (MKL_INT k = 0; k < nnz; k++) {
    //     printf(" %g", a[k]);
    // }
    // printf("\n");

    MKL_INT mtype = 11; /* Real unsymmetric matrix */
    // Descriptor of main sparse matrix properties
    struct matrix_descr descrA;
    // Structure with sparse matrix stored in CSR format
    sparse_matrix_t csrA;
    sparse_operation_t transA;
    /* RHS and solution vectors. */
    double res, res0;
    double *b = (double*)malloc(n * sizeof(double));
    double *x = (double*)malloc(n * sizeof(double));
    double *bs = (double*)malloc(n * sizeof(double));
    MKL_INT nrhs = 1; /* Number of right hand sides. */
    /* Internal solver memory pointer pt, */
    /* 32-bit: int pt[64]; 64-bit: long int pt[64] */
    /* or void *pt[64] should be OK on both architectures */
    void *pt[64];
    /* Pardiso control parameters. */
    MKL_INT iparm[64];
    MKL_INT maxfct, mnum, phase, error, msglvl;
    /* Auxiliary variables. */
    MKL_INT i, j;
    double ddum; /* Double dummy */
    MKL_INT idum; /* Integer dummy. */
    /* -------------------------------------------------------------------- */
    /* .. Setup Pardiso control parameters. */
    /* -------------------------------------------------------------------- */
    for (i = 0; i < 64; i++) {
        iparm[i] = 0;
    }
    iparm[0] = 1; /* No solver default */
    iparm[1] = 2; /* Fill-in reordering from METIS */
    iparm[3] = 0; /* No iterative-direct algorithm */
    iparm[4] = 0; /* No user fill-in reducing permutation */
    iparm[5] = 0; /* Write solution into x */
    iparm[6] = 0; /* Not in use */
    iparm[7] = 2; /* Max numbers of iterative refinement steps */
    iparm[8] = 0; /* Not in use */
    iparm[9] = 13; /* Perturb the pivot elements with 1E-13 */
    iparm[10] = 1; /* Use nonsymmetric permutation and scaling MPS */
    iparm[11] = 0; /* Conjugate transposed/transpose solve */
    iparm[12] = 1; /* Maximum weighted matching algorithm is switched-on (default for non-symmetric) */
    iparm[13] = 0; /* Output: Number of perturbed pivots */
    iparm[14] = 0; /* Not in use */
    iparm[15] = 0; /* Not in use */
    iparm[16] = 0; /* Not in use */
    iparm[17] = -1; /* Output: Number of nonzeros in the factor LU */
    iparm[18] = -1; /* Output: Mflops for LU factorization */
    iparm[19] = 0; /* Output: Numbers of CG Iterations */
    iparm[34] = 1; /* PARDISO use C-style indexing for ia and ja arrays */
    maxfct = 1; /* Maximum number of numerical factorizations. */
    mnum = 1; /* Which factorization to use. */
    msglvl = 1; /* Print statistical information  */
    error = 0; /* Initialize error flag */
    /* -------------------------------------------------------------------- */
    /* .. Initialize the internal solver memory pointer. This is only */
    /* necessary for the FIRST call of the PARDISO solver. */
    /* -------------------------------------------------------------------- */
    for (i = 0; i < 64; i++) {
        pt[i] = 0;
    }
    /* -------------------------------------------------------------------- */
    /* .. Reordering and Symbolic Factorization. This step also allocates */
    /* all memory that is necessary for the factorization. */
    /* -------------------------------------------------------------------- */
    phase = 11;
    PARDISO(pt, &maxfct, &mnum, &mtype, &phase,
            &n, a, ia, ja, &idum, &nrhs, iparm, &msglvl, &ddum, &ddum, &error);
    if (error != 0) {
        printf("\nERROR during symbolic factorization: %d", error);
        exit(1);
    }
    printf("\nReordering completed ... ");
    printf("\nNumber of nonzeros in factors = %d", iparm[17]);
    printf("\nNumber of factorization MFLOPS = %d", iparm[18]);
    /* -------------------------------------------------------------------- */
    /* .. Numerical factorization. */
    /* -------------------------------------------------------------------- */
    phase = 22;
    PARDISO(pt, &maxfct, &mnum, &mtype, &phase,
            &n, a, ia, ja, &idum, &nrhs, iparm, &msglvl, &ddum, &ddum, &error);
    if (error != 0) {
        printf("\nERROR during numerical factorization: %d", error);
        exit(2);
    }
    printf("\nFactorization completed ... ");
    /* -------------------------------------------------------------------- */
    /* .. Back substitution and iterative refinement. */
    /* -------------------------------------------------------------------- */
    phase = 33;

    descrA.type = SPARSE_MATRIX_TYPE_GENERAL;
    descrA.mode = SPARSE_FILL_MODE_UPPER;
    descrA.diag = SPARSE_DIAG_NON_UNIT;
    mkl_sparse_d_create_csr(&csrA, SPARSE_INDEX_BASE_ZERO, n, n, ia, ia + 1, ja, a);

    /* Set right hand side to one. */
    for (i = 0; i < n; i++) {
        b[i] = 1;
    }
    //  Loop over 3 solving steps: Ax=b, AHx=b and ATx=b
    for (i = 0; i < 3; i++) {
        iparm[11] = i; /* Conjugate transposed/transpose solve */
        if (i == 0)
            transA = SPARSE_OPERATION_NON_TRANSPOSE;
        else if (i == 1)
            transA = SPARSE_OPERATION_CONJUGATE_TRANSPOSE;
        else
            transA = SPARSE_OPERATION_TRANSPOSE;

        printf("\n\nSolving system with iparm[11] = %d ...\n", (int) iparm[11]);
        PARDISO(pt, &maxfct, &mnum, &mtype, &phase,
                &n, a, ia, ja, &idum, &nrhs, iparm, &msglvl, b, x, &error);
        if (error != 0) {
            printf("\nERROR during solution: %d", error);
            exit(3);
        }

        // printf ("\nThe solution of the system is: ");
        // for ( j = 0; j < n; j++ )
        // {
        //     printf ("\n x [%d] = % f", j, x[j]);
        // }
        // printf ("\n");
        // Compute residual
        mkl_sparse_d_mv(transA, 1.0, csrA, descrA, x, 0.0, bs);
        res = 0.0;
        res0 = 0.0;
        for (j = 1; j <= n; j++) {
            res += (bs[j - 1] - b[j - 1]) * (bs[j - 1] - b[j - 1]);
            res0 += b[j - 1] * b[j - 1];
        }
        res = sqrt(res) / sqrt(res0);
        printf("\nRelative residual = %e", res);
        // Check residual
        if (res > 1e-10) {
            printf("Error: residual is too high!\n");
            exit(10 + i);
        }
    }
    mkl_sparse_destroy(csrA);

    /* -------------------------------------------------------------------- */
    /* .. Termination and release of memory. */
    /* -------------------------------------------------------------------- */
    phase = -1; /* Release internal memory. */
    PARDISO(pt, &maxfct, &mnum, &mtype, &phase,
            &n, &ddum, ia, ja, &idum, &nrhs,
            iparm, &msglvl, &ddum, &ddum, &error);
    return 0;
}