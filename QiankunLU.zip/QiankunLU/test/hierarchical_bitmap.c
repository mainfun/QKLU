// 二级位图配置
#define SUPER_BLOCK_SIZE 64  // 每个超级块包含64个底层块

typedef struct {
    uint8_t *super_bitmap;   // 一级位图（标记超级块是否包含非零块）
    uint8_t *block_bitmap;   // 二级位图（标记每个块是否存在非零元素）
    size_t super_bitmap_size;
    size_t block_bitmap_size;
} HierarchicalBitmap;

void build_hierarchical_bitmap(
    const INDEX_TYPE *block_cols, INDEX_TYPE n, INDEX_TYPE num_col_block,
    HierarchicalBitmap *hbitmap
) {
    const INDEX_TYPE num_blocks = num_col_block * num_col_block;
    hbitmap->super_bitmap_size = (num_blocks / SUPER_BLOCK_SIZE + 7) / 8;
    hbitmap->block_bitmap_size = (num_blocks + 7) / 8;

    // 初始化全局位图
    hbitmap->super_bitmap = (uint8_t *) lu_calloc(hbitmap->super_bitmap_size, sizeof(uint8_t));
    hbitmap->block_bitmap = (uint8_t *) lu_calloc(hbitmap->block_bitmap_size, sizeof(uint8_t));

    #pragma omp parallel
    {
        // 线程本地位图
        uint8_t *local_super = (uint8_t *) lu_calloc(hbitmap->super_bitmap_size, sizeof(uint8_t));
        uint8_t *local_block = (uint8_t *) lu_calloc(hbitmap->block_bitmap_size, sizeof(uint8_t));

        #pragma omp for
        for (INDEX_TYPE i = 0; i < n; ++i) {
            const INDEX_TYPE block_row = i / block_side;
            const INDEX_TYPE row_offset = block_row * num_col_block;

            for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
                const INDEX_TYPE block_col = block_cols[j];
                const INDEX_TYPE pos = row_offset + block_col;

                // 标记二级位图
                const size_t block_byte = pos >> 3;
                local_block[block_byte] |= (1U << (pos & 0x07));

                // 标记一级位图（超级块）
                const INDEX_TYPE super_pos = pos / SUPER_BLOCK_SIZE;
                const size_t super_byte = super_pos >> 3;
                local_super[super_byte] |= (1U << (super_pos & 0x07));
            }
        }

        // 合并到全局位图
        #pragma omp critical
        {
            for (size_t k = 0; k < hbitmap->super_bitmap_size; ++k) {
                hbitmap->super_bitmap[k] |= local_super[k];
            }
            for (size_t k = 0; k < hbitmap->block_bitmap_size; ++k) {
                hbitmap->block_bitmap[k] |= local_block[k];
            }
        }

        lu_free(local_super);
        lu_free(local_block);
    }
}

INDEX_TYPE generate_csr_with_hierarchy(
    const HierarchicalBitmap *hbitmap,
    INDEX_TYPE num_col_block,
    INDEX_TYPE **Rp_ptr,
    INDEX_TYPE **Ri_ptr
) {
    // 统计非零块总数
    INDEX_TYPE r_nnz = 0;
    #pragma omp parallel for reduction(+:r_nnz)
    for (size_t k = 0; k < hbitmap->block_bitmap_size; ++k) {
        r_nnz += __builtin_popcount(hbitmap->block_bitmap[k]);
    }

    // 初始化CSR数组
    *Rp_ptr = (INDEX_TYPE *) lu_calloc(num_col_block + 1, sizeof(INDEX_TYPE));
    *Ri_ptr = (INDEX_TYPE *) lu_malloc(r_nnz * sizeof(INDEX_TYPE));

    INDEX_TYPE current_nnz = 0;
    for (INDEX_TYPE block_row = 0; block_row < num_col_block; ++block_row) {
        (*Rp_ptr)[block_row + 1] = (*Rp_ptr)[block_row];
        const INDEX_TYPE row_start = block_row * num_col_block;

        // 遍历该行所有超级块
        for (INDEX_TYPE super_idx = 0; super_idx < num_col_block; super_idx += SUPER_BLOCK_SIZE) {
            const INDEX_TYPE super_pos = (row_start + super_idx) / SUPER_BLOCK_SIZE;
            const size_t super_byte = super_pos >> 3;
            const uint8_t super_bit = hbitmap->super_bitmap[super_byte] & (1U << (super_pos & 0x07));

            if (!super_bit) {  // 超级块全零，跳过
                super_idx += SUPER_BLOCK_SIZE;
                continue;
            }

            // 扫描该超级块内的二级位图
            const INDEX_TYPE block_start = row_start + super_idx;
            const INDEX_TYPE block_end = block_start + SUPER_BLOCK_SIZE;
            for (INDEX_TYPE pos = block_start; pos < block_end; ) {
                const size_t block_byte = pos >> 3;
                const uint8_t byte = hbitmap->block_bitmap[block_byte];
                if (byte == 0) {  // 跳过全零字节
                    pos += 8 - (pos & 0x07);
                    continue;
                }

                // 提取有效位
                if (byte & (1U << (pos & 0x07))) {
                    const INDEX_TYPE block_col = pos % num_col_block;
                    (*Ri_ptr)[current_nnz++] = block_col;
                    (*Rp_ptr)[block_row + 1]++;
                }
                pos++;
            }
        }
    }

    return r_nnz;
}