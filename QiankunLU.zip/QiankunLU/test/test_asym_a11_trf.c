#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <preprocess/etree.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>
#include "SuiteSparse_config.h"
#include "btf.h"

Config config;

int main(int argc, char *argv[]) {
    parse_arguments(argc, argv, &config);
    CSRMatrix *original_matrix = load_matrix_csr(argv[1], false);
    // double maxwork = 0.0, work;
    // int64_t P[original_matrix->num_col], Q[original_matrix->num_col], R[original_matrix->num_col], nmatch;
    // int64_t Workspace[original_matrix->num_col * 5];
    // int64_t btf_x=btf_l_order(original_matrix->num_col, (int64_t*)original_matrix->row_pointers, (int64_t*)original_matrix->col_indices,
    //             maxwork,&work,P, Q, R,&nmatch,Workspace);
    // printf("\nbtf_l_order:%lld\n",btf_x);
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    CSRMatrix *A = reordering(original_matrix, info,true,true);
    CSRMatrix A11, A12, A21, A22;
    blocking_csr_4m(A->num_row, A->row_pointers, A->col_indices, A->csr_values,
                    info->cut_point1, &A11, &A12, &A21, &A22);
    //--------------------------
    double time = omp_get_wtime();
    INDEX_TYPE *b_ptr, *b_idx;
    INDEX_TYPE bnz = A->nnz * 2;
    a_plus_at(A->num_col, A->nnz, A->row_pointers, A->col_indices, &bnz, &b_ptr, &b_idx);
    INDEX_TYPE *etree = lu_malloc(A->num_col * sizeof(INDEX_TYPE));
    sp_symetree(b_ptr, b_ptr + 1, b_idx, A->num_col, etree);
    // INDEX_TYPE *etree = create_etree(A);
    INDEX_TYPE nnz = calc_l_nz(b_ptr, b_idx, etree, A->num_col, A->num_col);
    LOG_DEBUG("nnz:%ld", nnz);
    LOG_TIME("calc_l_nz total time:%f s", omp_get_wtime()-time);
    INDEX_TYPE *Lp = lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Li = lu_malloc((nnz) * sizeof(INDEX_TYPE));
    // INDEX_TYPE *A12p = lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    // INDEX_TYPE *A12i = lu_malloc((nnz - A->num_col) * sizeof(INDEX_TYPE));
    // get_l_col_patterns_block(b_ptr, b_idx, A->num_col, etree, Lp, Li, A12p, A12i, info->cut_point1, info->cut_point2);
    get_l_col_patterns_naive(b_ptr, b_idx, A->num_col, etree, Lp, Li, info->cut_point1, info->cut_point2);
    // CSRMatrix *l = init_csr_matrix(A->num_col, A->num_col, nnz);
    // l->row_pointers = Lp, l->col_indices = Li;
    // csr2image_gray(l,"onetone1_sym.jpeg",2000,2000);
    // plot_LU(A,"onetone1_unsym.jpeg",0);
    // INDEX_TYPE *Sp = lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    // INDEX_TYPE *Si = lu_malloc((nnz - A->num_col) * sizeof(INDEX_TYPE));
    // get_supernode_patterns(400, Lp, Li, Sp, Si);
    // print_matrix_csr(Sp, Si, 3);
    // lu_free(Sp);
    // lu_free(Si);
    lu_free(b_ptr);
    lu_free(b_idx);
    lu_free(Lp);
    lu_free(Li);
    lu_free(etree);
    //--------------------------

    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(A11.num_row * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) lu_malloc(A11.num_row * sizeof(ELE_TYPE));
    random_vector(b, A11.num_row);
    solve_sp_diagonal_v3(A11.row_pointers, A11.col_indices, A11.csr_values,
                         A11.num_row, A11.nnz, x, b);
    check_solving(&A11, x, b);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);
    lu_free(x);
    lu_free(b);
    free_csr_matrix_ptr(&A11);
    free_csr_matrix_ptr(&A12);
    free_csr_matrix_ptr(&A21);
    free_csr_matrix_ptr(&A22);
    free_csr_matrix(A);
    free_csr_matrix(original_matrix);
    free_preprocess_info(info);
    free_config(&config);
    return 0;
}
