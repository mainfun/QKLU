#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <numeric/sp_factor.h>
#include <preprocess/etree.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>
#include "SuiteSparse_config.h"
#include "base/sort.h"

Config config;

void analyze_csr_matrix(
    INDEX_TYPE n_rows,
    INDEX_TYPE n_cols,
    const INDEX_TYPE *row_ptr, // size: n_rows + 1
    const INDEX_TYPE *col_idx, // size: nnz
    INDEX_TYPE *min_col_per_row, // output, size: n_rows
    INDEX_TYPE *max_row_per_col // output, size: n_cols
) {
    // 初始化
    for (INDEX_TYPE i = 0; i < n_rows; ++i)
        min_col_per_row[i] = -1;

    for (INDEX_TYPE j = 0; j < n_cols; ++j)
        max_row_per_col[j] = -1;

    // 遍历所有行
    for (INDEX_TYPE i = 0; i < n_rows; ++i) {
        INDEX_TYPE row_start = row_ptr[i];
        INDEX_TYPE row_end = row_ptr[i + 1];

        INDEX_TYPE min_col = INT_MAX;

        for (INDEX_TYPE k = row_start; k < row_end; ++k) {
            INDEX_TYPE col = col_idx[k];

            // 更新当前行的最小列
            if (col < min_col)
                min_col = col;

            // 更新该列的最大行
            if (i > max_row_per_col[col])
                max_row_per_col[col] = i;
        }

        if (row_end > row_start)
            min_col_per_row[i] = min_col;
    }
}

int main(int argc, char *argv[]) {
    parse_arguments(argc, argv, &config);
    CSRMatrix *original_matrix = load_matrix_csr(argv[1], false);
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    CSRMatrix *A = reordering(original_matrix, info,true,true);
    CSRMatrix A11, A12, A21, A22;
    blocking_csr_4m(A->num_row, A->row_pointers, A->col_indices, A->csr_values,
                    info->cut_point1, &A11, &A12, &A21, &A22);
    //--------------------------
    double time = omp_get_wtime();
    INDEX_TYPE *aat_ptr, *aat_idx;
    INDEX_TYPE aat_nnz = A->nnz * 2;
    a_plus_at(A->num_col, A->nnz, A->row_pointers, A->col_indices, &aat_nnz, &aat_ptr, &aat_idx);
    INDEX_TYPE *etree = (INDEX_TYPE*)lu_malloc(A->num_col * sizeof(INDEX_TYPE));
    sp_symetree(aat_ptr, aat_ptr + 1, aat_idx, A->num_col, etree);
    // INDEX_TYPE *etree = create_etree(A);


    INDEX_TYPE nnz = calc_l_nz(aat_ptr, aat_idx, etree, A->num_col, A->num_col);
    LOG_DEBUG("nnz:%ld", nnz);
    LOG_TIME("calc_l_nz total time:%f s", omp_get_wtime()-time);
    INDEX_TYPE *Lp = (INDEX_TYPE*)lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Li = (INDEX_TYPE*)lu_malloc((nnz) * sizeof(INDEX_TYPE));
    get_l_col_patterns_naive(aat_ptr, aat_idx, A->num_col, etree, Lp, Li, info->cut_point1, info->cut_point2);
    // INDEX_TYPE *A12p = lu_malloc((A->num_col + 1) * sizeof(INDEX_TYPE));
    // INDEX_TYPE *A12i = lu_malloc((nnz - A->num_col) * sizeof(INDEX_TYPE));
    // get_l_col_patterns_block(aat_ptr, aat_idx, A->num_col, etree, Lp, Li, A12p, A12i, info->cut_point1, info->cut_point2);

    INDEX_TYPE split_points_num;
    INDEX_TYPE *split_points = dispatch_find_split_points_sym(A11.row_pointers, A11.col_indices,
                                                              A11.num_col, &split_points_num);

    get_l_col_patterns_parallel(aat_ptr, aat_idx,
                            A->num_col, etree, Lp, Li,
                            info->cut_point1, info->cut_point2,
                            split_points_num, split_points);

    INDEX_TYPE *min_col = (INDEX_TYPE *) malloc(A->num_col * sizeof(INDEX_TYPE));
    INDEX_TYPE *max_col = (INDEX_TYPE *) malloc(A->num_col * sizeof(INDEX_TYPE));
    double find_min_max_time = omp_get_wtime();
    analyze_csr_matrix(info->cut_point1, info->cut_point1, Lp, Li, min_col, max_col);
    LOG_TIME("find_min_max_time:%f ms", (omp_get_wtime()-find_min_max_time)*1000);
    lu_free(min_col);
    lu_free(max_col);


    lu_free(aat_ptr);
    lu_free(aat_idx);
    lu_free(etree);
    //--------------------------
    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = 0; i < A->num_col; ++i) {
        ELE_TYPE sum = 0;
        for (INDEX_TYPE j = A->row_pointers[i]; j < A->row_pointers[i + 1]; ++j) {
            sum += A->csr_values[j];
        }
        b[i] = sum;
    }
    // random_vector(b, A->num_row);

    ELE_TYPE *Lx = (ELE_TYPE *) lu_malloc(nnz * sizeof(ELE_TYPE));
    ELE_TYPE *Ux = (ELE_TYPE *) lu_malloc(nnz * sizeof(ELE_TYPE));
    ELE_TYPE *U_diag = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    // print_dense_matrix(csr2dense(A),A->num_row);
    sp_factor_v4(A->row_pointers, A->col_indices, A->csr_values,
                 Lp, Li, Lx, Lp,Li,Ux, U_diag, A->num_row);
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    lower_solver_csc(Lp, Li, Lx, A->num_row, y, b);
    upper_solver_csr_exclude_diag(Lp, Li, Ux, U_diag, A->num_row, x, y);
    for (int i = 0; i < A->num_row; ++i) {
        // printf("%.9lf\n",x[i]);
    }
    check_solving(A, x, b);

    // ELE_TYPE *x = (ELE_TYPE *) lu_malloc(A11.num_row * sizeof(ELE_TYPE));
    // ELE_TYPE *b = (ELE_TYPE *) lu_malloc(A11.num_row * sizeof(ELE_TYPE));
    // random_vector(b, A11.num_row);
    // solve_sp_diagonal_v3(A11.row_pointers, A11.col_indices, A11.csr_values,
    //                      A11.num_row, A11.nnz, x, b);
    // check_solving(&A11, x, b);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);
    lu_free(x);
    lu_free(b);
    lu_free(Lp);
    lu_free(Li);
    free_csr_matrix_ptr(&A11);
    free_csr_matrix_ptr(&A12);
    free_csr_matrix_ptr(&A21);
    free_csr_matrix_ptr(&A22);
    free_csr_matrix(A);
    free_csr_matrix(original_matrix);
    free_preprocess_info(info);
    free_config(&config);
    return 0;
}
