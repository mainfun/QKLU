#include <float.h>
#include <lapacke.h>
#include <omp.h>
#include <base/base_math.h>
#include <base/log.h>
#include <base/matrix.h>
#include <base/matrix_plot.h>
#include <base/matrix_util.h>
#include <numeric/SpTSTRF.h>
#include <numeric/SpGESSM.h>
#include <numeric/SpSSSSM.h>
#include <numeric/sp_factor.h>
#include <preprocess/etree.h>
#include <preprocess/preprocess.h>
#include <preprocess/reorder.h>
#include "base/file.h"
#include "base/parse_args.h"
#include "numeric/numeric.h"
#include "solve/solving.h"
#include "solve/check.h"
#include <preprocess/symbolic_analysis.h>

Config config;

int main(int argc, char *argv[]) {
    parse_arguments(argc, argv, &config);
    CSRMatrix *original_matrix = load_matrix_csr(argv[1], false);
    //load_csc(argv[1],original_matrix);
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    CSRMatrix *A = reordering(original_matrix, info,true,true);
    CSRMatrix A11, A12, A21, A22;
//     info->cut_point1 = original_matrix->num_row;//todo
    blocking_csr_4m(A->num_row, A->row_pointers, A->col_indices, A->csr_values,
                    info->cut_point1, &A11, &A12, &A21, &A22);
    //------------符号分析--------------
    INDEX_TYPE *etree = create_etree_force2sym(A);
    CSRMatrix U11, U12, L11, L21;
    symbolic_analysis_block(etree, A, info, &U11, &U12, &L11, &L21);
    lu_free(etree);
//    for(int i=0;i<5000;i++){
//      for(int j=L11.row_pointers[i];j<L11.row_pointers[i+1];j++){
//          printf("%lld,",L11.col_indices[j]);
//      }
//        printf("\n");
//    }
    //------------绘图--------------
//     csr2image_RGB(&L11,"01A_L.jpeg",6000,6000);
//     csr2image_RGB(&U11,"01A_U.jpeg",6000,6000);
//     exit(0);
    // LOG_DEBUG("绘制完成");
    //-------------数值分解-------------
    double numeric_time = omp_get_wtime();
    ELE_TYPE *Lx = (ELE_TYPE *) lu_malloc(L11.nnz * sizeof(ELE_TYPE));
    ELE_TYPE *Ux = (ELE_TYPE *) lu_malloc(U11.nnz * sizeof(ELE_TYPE));
    ELE_TYPE *U_diag = (ELE_TYPE *) lu_malloc(U11.num_row * sizeof(ELE_TYPE));
    sp_factor_v6(A11.row_pointers, A11.col_indices, A11.csr_values,
                 L11.row_pointers, L11.col_indices, Lx,
                 U11.row_pointers, U11.col_indices, Ux, U_diag, A11.num_row);
    U11.csr_values = Ux;
    L11.csr_values = Lx;
    L21.csr_values = (ELE_TYPE *) lu_malloc(L21.nnz * sizeof(ELE_TYPE));
    L21.csr_values -= L21.row_pointers[0]; //把原来的偏移补上;
    // for (INDEX_TYPE i = 0; i < A21.num_row; ++i) {
    //     for (INDEX_TYPE j = L21.row_pointers[i]; j < L21.row_pointers[i + 1]; ++j) {
    //         INDEX_TYPE col = L21.col_indices[j]; //上看依赖行
    //         printf("%lld, ",col);
    //     }
    // }
    SpTSTRF(&U11, &A21, &L21, U_diag);
    U12.csr_values = (ELE_TYPE *) lu_malloc(U12.nnz * sizeof(ELE_TYPE));
    SpGESSM(&L11, &A12, &U12);
    ELE_TYPE *R;

    SpSSSSM_DENSE(&L21, &U12, &A22, &R);
    LOG_TIME("sp numeric time:%f s", omp_get_wtime()-numeric_time);

    double lapacke_time = omp_get_wtime();
    LOG_DEBUG("dim:%lld", A22.num_row);
    int *ipiv = (int *) lu_malloc(A22.num_row * sizeof(int));
    int lapacke_info = LAPACKE_dgetrf(
        LAPACK_COL_MAJOR,
        A22.num_row, A22.num_row,
        R, // 直接传 row-major 数据
        A22.num_row, // 在 row-major 下 lda = “列数”
        ipiv
    );
    lu_free(ipiv);
    if (lapacke_info != 0) {
        fprintf(stderr, "LAPACKE_dgetrf failed: info=%d\n", lapacke_info);
        //return 1;
    }
    LOG_TIME("LAPACKE_dgetrf total time:%f s", omp_get_wtime()-lapacke_time);
    LOG_TIME("numeric total time:%f s", omp_get_wtime()-numeric_time);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);
    //-------------数值求解-------------
    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    ELE_TYPE *b = init_b(&A11);
    ELE_TYPE *perm_b = permute_b(b, A11.num_row, info->mc64_perm, info->reorder_iperm, info->Dr);

    // random_vector(b, A11.num_row);
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    lower_solver_csr(L11.row_pointers, L11.col_indices, Lx, A11.num_row, y, perm_b);
    upper_solver_csr_exclude_diag(U11.row_pointers, U11.col_indices, Ux, U_diag, A11.num_row, x, y);
    ELE_TYPE *perm_x = permute_x(x, A11.num_row, info->reorder_iperm, info->Dc);
    check_solving(original_matrix, perm_x, b);

    //todo free A11 L11
    lu_free(y);
    lu_free(Lx);
    lu_free(Ux);
    lu_free(U_diag);
    lu_free(x);
    lu_free(b);
    free_csr_matrix(A);
    free_csr_matrix(original_matrix);
    free_preprocess_info(info);
    free_config(&config);
    return 0;
}
