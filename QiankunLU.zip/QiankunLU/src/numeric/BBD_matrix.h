//
// Created by mainf on 2025/7/7.
//

#ifndef BBD_MATRIX_H
#define BBD_MATRIX_H

#include "base/matrix.h"

#define L2_TYPE double

typedef struct {
    INDEX_TYPE dim11;//B11 dim
    INDEX_TYPE dim22;//B22 dim
    INDEX_TYPE *split_points;//B11块边长大小前缀和
    INDEX_TYPE split_num;//B11块个数
    L2_TYPE **B11_block_ptr;//找B11的块对角矩阵
    L2_TYPE **B11_row_ptr;
    L2_TYPE *B11;//块对角矩阵
    L2_TYPE *B12;
    L2_TYPE *B21;
    L2_TYPE *B22;
} BBD_Dense;

///修改了split_points
///split_points[ii] -= split_points[0];
BBD_Dense *malloc_BBD_Dense(const INDEX_TYPE dim11, const INDEX_TYPE dim22,
                            INDEX_TYPE *split_points, INDEX_TYPE split_num);

void free_BBD_Dense(BBD_Dense *bbd);

void print_BBD_Dense(BBD_Dense *bbd, const INDEX_TYPE *split_points, const INDEX_TYPE split_num);

#endif //BBD_MATRIX_H
