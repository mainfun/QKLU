//
// Created by mainf on 2025/3/23.
//
#include "base/matrix.h"

void malloc_csr_matrix(CSRMatrix *A, INDEX_TYPE num_row,INDEX_TYPE num_col) {
    A->num_row = num_row;
    A->num_col = num_col;
    A->row_pointers = (INDEX_TYPE *) lu_calloc(num_row + 1, sizeof(INDEX_TYPE));
    A->col_indices = (INDEX_TYPE *) lu_malloc(A->nnz * sizeof(INDEX_TYPE));
    A->csr_values = (ELE_TYPE *) lu_malloc(A->nnz * sizeof(ELE_TYPE));
}

void blocking_csr(const INDEX_TYPE n,
                  const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE cut_point,
                  CSRMatrix *A11, CSRMatrix *A12, CSRMatrix *A21, CSRMatrix *A22) {
    //  ---------------------------统计nnz---------------------------
    for (INDEX_TYPE i = 0; i < cut_point; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            if (Ai[j] > cut_point) A12->nnz++;
            else A11->nnz++;
        }
    }
    for (INDEX_TYPE i = cut_point; i < n; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            if (Ai[j] > cut_point) A22->nnz++;
            else A21->nnz++;
        }
    }
    malloc_csr_matrix(A11, cut_point, cut_point);
    malloc_csr_matrix(A12, cut_point, n-cut_point);
    malloc_csr_matrix(A21, n-cut_point, cut_point);
    malloc_csr_matrix(A22, n-cut_point, n-cut_point);
    //  ---------------------------end 统计nnz---------------------------
    for (INDEX_TYPE i = 0; i < cut_point; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE c = Ai[j];
            ELE_TYPE v = Ax[j];
            if (c > cut_point) {
                //A12
                A12->col_indices[A12->row_pointers[i]++] = c;
                A12->csr_values[A12->row_pointers[i]++] = v;
            } else {
                //A11
                A11->col_indices[A11->row_pointers[i]++] = c;
                A11->csr_values[A11->row_pointers[i]++] = v;
            }
        }
    }
    for (INDEX_TYPE i = cut_point; i < n; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE c = Ai[j];
            ELE_TYPE v = Ax[j];
            if (c > cut_point) {
                //A22
                A22->col_indices[A22->row_pointers[i]++] = c;
                A22->csr_values[A22->row_pointers[i]++] = v;
            } else {
                //A21
                A21->col_indices[A21->row_pointers[i]++] = c;
                A21->csr_values[A21->row_pointers[i]++] = v;
            }
        }
    }
    for (INDEX_TYPE i = 0; i < n; ++i) {
        A11->row_pointers[i + 1] += A11->row_pointers[i];
        A12->row_pointers[i + 1] += A12->row_pointers[i];
        A21->row_pointers[i + 1] += A21->row_pointers[i];
        A22->row_pointers[i + 1] += A22->row_pointers[i];
    }
}

void A11_LU_decomposition(INDEX_TYPE *Ap,INDEX_TYPE *Ai,ELE_TYPE *Ax,
                          INDEX_TYPE n, INDEX_TYPE nnz,
                          INDEX_TYPE split_points) {

    INDEX_TYPE *final_col = (INDEX_TYPE *) malloc(n * sizeof(INDEX_TYPE)); //每行最后的列号
    //csr2dense_v2();
    lu_free(final_col);
}