//
// Created by mainf on 2025/3/29.
//

#include "SpTSTRF.h"

#include <omp.h>
#include <base/base_math.h>
#include <base/matrix.h>
#include <preprocess/preprocess.h>

void SpTSTRF(const CSRMatrix *U11, const CSRMatrix *A21,
             const CSRMatrix *L21, const ELE_TYPE *U_diag) {
    const INDEX_TYPE *Lp = L21->row_pointers;
    const INDEX_TYPE *Li = L21->col_indices;
    ELE_TYPE *Lx = L21->csr_values;
    const INDEX_TYPE *Up = U11->row_pointers;
    const INDEX_TYPE *Ui = U11->col_indices;
    const ELE_TYPE *Ux = U11->csr_values;
    const INDEX_TYPE *Ap = A21->row_pointers;
    const INDEX_TYPE *Ai = A21->col_indices;
    const ELE_TYPE *Ax = A21->csr_values;

    long long elimination_count = 0;
    ELE_TYPE *dense_vec = (ELE_TYPE *) lu_calloc(U11->num_row, sizeof(ELE_TYPE)); //dense vector
    double factor_time = omp_get_wtime();
    //遍历A21的全部行
    #pragma omp parallel for schedule(static,1)
    for (INDEX_TYPE i = 0; i < A21->num_row; ++i) {
        // Scatter A(i,:) into dense_vec
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            dense_vec[Ai[j]] = Ax[j];
        }
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            INDEX_TYPE col = Li[j]; //上看依赖行
            ELE_TYPE l = Lx[j] = dense_vec[col] / U_diag[col]; //l(i,col)
            dense_vec[col] = 0.0;
            if (l == 0.0) continue;
            // 当前行向量 += l * 依赖行向量: dense_vec[c] -= l(i,col) * U(col,c)
            for (INDEX_TYPE k = Up[col]; k < Up[col + 1]; ++k) {
                ELE_TYPE v = l * Ux[k];
                INDEX_TYPE idx = Ui[k];
                dense_vec[idx] -= v;
                //dense_vec[Ui[k]] -= l * Ux[k];
                elimination_count++;
            }
        }
    }
    lu_free(dense_vec);
    LOG_DEBUG("SpTsTRF 消元次数为   ::::%lld", elimination_count);
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
}
