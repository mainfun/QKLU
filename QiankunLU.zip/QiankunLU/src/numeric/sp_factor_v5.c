//
// Created by mainf on 2025/3/26.
// 对称矩阵分解实现
//
#include <math.h>
#include <omp.h>
#include <base/base_math.h>
#include <preprocess/preprocess.h>

#include "base/matrix.h"

#if defined(A)
#undef A
#endif
#define A(i,j)  D[ offset[(i)] + (j) ]

INDEX_TYPE *get_offset_v5(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                          const INDEX_TYPE *Lp, const INDEX_TYPE *Li,
                          INDEX_TYPE n, INDEX_TYPE *d_size) {
    double factor_time = omp_get_wtime();
    INDEX_TYPE *offset = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    INDEX_TYPE *min_rows;
    INDEX_TYPE *max_rows;
    min_rows = A_min_row_idx(Ap, Ai, n);
    max_rows = L_max_row_idx(Lp, Li, n);
    for (INDEX_TYPE k = 0; k < n; ++k) {
        offset[k] = *d_size;
        INDEX_TYPE at_min_idx = min_rows[k];
        INDEX_TYPE a_min_idx = Ai[Ap[k]];
        min_rows[k] = MIN(at_min_idx, a_min_idx);
        *d_size += max_rows[k] - min_rows[k] + 1;
    }
    // LOG_DEBUG("offset:");
    // for (int i = 0; i < 11; ++i) {
    //     printf("%lld,", offset[i]);
    // }
    // LOG_DEBUG("\noffset");
    for (INDEX_TYPE r = 0; r < n; ++r) {
        offset[r] -= min_rows[r];
        // if (offset[r] < 0) {
        //     printf("debug");
        // }
    }
    // LOG_DEBUG("offset:");
    // for (int i = 0; i < 11; ++i) {
    //     printf("%lld,", offset[i]);
    // }
    // LOG_DEBUG("\noffset");
    LOG_TIME("get_offset time: %f ms", (omp_get_wtime()-factor_time)*1000);
    return offset;
}

ELE_TYPE *malloc_dense_v5(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                          const INDEX_TYPE n, const INDEX_TYPE d_size, const INDEX_TYPE *offset) {
    ELE_TYPE *D;
    // = (ELE_TYPE *) aligned_alloc(64, d_size * sizeof(ELE_TYPE));
    // posix_memalign((void**)&D, 64, d_size * sizeof(ELE_TYPE));
    D = (ELE_TYPE *) lu_calloc(d_size, sizeof(ELE_TYPE));
    double factor_time = omp_get_wtime();
    #pragma omp parallel for
    for (INDEX_TYPE r = 0; r < n; ++r) {
        // ELE_TYPE *ptr=D+offset[r];
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            A(r, Ai[j]) = Ax[j];
        }
    }
    LOG_TIME("malloc time: %f ms", (omp_get_wtime()-factor_time)*1000);
    return D;
}

void write_back_v5(const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                   ELE_TYPE *Ux,ELE_TYPE *U_diag,
                   ELE_TYPE *D,INDEX_TYPE n,
                   const INDEX_TYPE *offset) {
    double factor_time = omp_get_wtime();
    const INDEX_TYPE *Up = Lp;
    const INDEX_TYPE *Ui = Li;
    #pragma omp parallel for
    for (INDEX_TYPE i = 0; i < n; i++) {
        //U csr
        U_diag[i] = A(i, i);
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            INDEX_TYPE index = Ui[j];
            Ux[j] = A(i, index);
        }
        //L csc
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            INDEX_TYPE index = Li[j];
            Lx[j] = A(index, i);
        }
    }
    LOG_TIME("写回 time: %f ms", (omp_get_wtime()-factor_time)*1000);
}

/**
 * 稀疏LU分解的并行实现，只用于分解A11
 */
void sp_factor_v5(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  ELE_TYPE *Ux,ELE_TYPE *U_diag,INDEX_TYPE n,
                  const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points) {
    int small_pivot = 0;
    const INDEX_TYPE *Up = Lp;
    const INDEX_TYPE *Ui = Li;
    long long elimination_count = 0;
    INDEX_TYPE d_size = 0;
    // printf("Li:");
    // for (int i = 0; i < 11; ++i) {
    //     for (int j = Lp[i]; j < Lp[i + 1]; ++j) {
    //         printf("%lld,", Li[j]);
    //     }
    //     printf("\n");
    // }
    // printf("Ai:");
    // for (int i = 0; i < 11; ++i) {
    //     for (int j = Ap[i]; j < Ap[i + 1]; ++j) {
    //         printf("%lld,", Ai[j]);
    //     }
    //     printf("\n");
    // }
    INDEX_TYPE *offset = get_offset_v5(Ap, Ai, Lp, Li, n, &d_size);
    LOG_DEBUG("d_size占用内存：%lu MB",d_size/1024/1024*8);
    ELE_TYPE *D = malloc_dense_v5(Ap, Ai, Ax, n, d_size, offset);
    // print_dense_matrix(D,n);
    //向下高斯消元
    double factor_time = omp_get_wtime();
    #pragma omp parallel for reduction(+:elimination_count) proc_bind(spread) schedule(dynamic)
    for (INDEX_TYPE ii = 0; ii < split_points_num; ++ii) {
        // int tid = omp_get_thread_num();    // 获取线程 ID
        // int nt  = omp_get_num_threads();   // 获取线程总数
        // #pragma omp critical
        // printf("  线程 %d / %d 正在运行\n", tid, nt);
        INDEX_TYPE start_row = split_points[ii];
        INDEX_TYPE end_row = split_points[ii + 1];
        for (INDEX_TYPE i = start_row; i < end_row; ++i) {
            //枚举列
            ELE_TYPE pivot = A(i, i); // diag value
            //————————————————————————————————————————————————————————————————————
            //主元行交换
            // if (fabs(pivot) < 1e-13) {
            //     INDEX_TYPE last = i;
            //     ELE_TYPE max = 0;
            //     INDEX_TYPE max_idx = i;
            //     //向下面找最大
            //     for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; p++) {
            //         INDEX_TYPE j = Li[p]; //行号
            //         if (j - last != 1) break; //不连续不是supernode
            //         ELE_TYPE candidate = A(j, i);
            //         //如果结构相同
            //         if (Lp[last + 1] - Lp[last] - 1 == Lp[j + 1] - Lp[j]) {
            //             //求最大candidate为主元
            //             if (fabs(candidate) > max) {
            //                 max = fabs(candidate);
            //                 max_idx = j;
            //             }
            //         } else {
            //             break;
            //         }
            //         last = j;
            //         break;
            //     }
            //     // 如果找到，行交换
            //     if (max_idx != i) {
            //         printf("发生行交换\n");
            //         for (INDEX_TYPE p = Up[i]; p < Up[i + 1]; p++) {
            //             INDEX_TYPE j = Ui[p];
            //             ELE_TYPE temp = A(i, j);
            //             A(i, j) = A(max_idx, j);
            //             A(max_idx, j) = temp;
            //         }
            //         ELE_TYPE temp = A(i, i);
            //         pivot = A(i, i) = A(max_idx, i);
            //         A(max_idx, i) = temp;
            //     }
            // }
            //————————————————————————————————————————————————————————————————————
            if (fabs(pivot) < 1e-8) {
                pivot = pivot >= 0 ? 1e-8 : -1e-8;
                A(i, i) = pivot;
                small_pivot++;
            }
            // for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; p++) {
            //     INDEX_TYPE j = Li[p]; //行号
            //     if (A(j, i) == 0) continue;
            //     ELE_TYPE scale = A(j, i) / pivot;
            //     //L的列
            //     A(j, i) = scale;
            //     ELE_TYPE *pivot_row_ptr = &A(i, 0);
            //     ELE_TYPE *eli_row_ptr = &A(j, 0);
            //     for (INDEX_TYPE k = Up[i]; k < Up[i + 1]; k++) {
            //         INDEX_TYPE c = Ui[k];
            //         eli_row_ptr[c] -= scale * pivot_row_ptr[c];
            //         elimination_count++;
            //     }
            // }
            // continue;
            INDEX_TYPE p_start = Lp[i];
            INDEX_TYPE p_end = Lp[i + 1];
            INDEX_TYPE p = p_start;
            for (; p + 3 < p_end; p += 4) {
                INDEX_TYPE j0 = Li[p + 0];
                INDEX_TYPE j1 = Li[p + 1];
                INDEX_TYPE j2 = Li[p + 2];
                INDEX_TYPE j3 = Li[p + 3];
                ELE_TYPE l0 = A(j0, i) / pivot;
                ELE_TYPE l1 = A(j1, i) / pivot;
                ELE_TYPE l2 = A(j2, i) / pivot;
                ELE_TYPE l3 = A(j3, i) / pivot;
                A(j0, i) = l0;
                A(j1, i) = l1;
                A(j2, i) = l2;
                A(j3, i) = l3;
                ELE_TYPE *pivot_row_ptr = &A(i, 0);
                ELE_TYPE *e0 = &A(j0, 0);
                ELE_TYPE *e1 = &A(j1, 0);
                ELE_TYPE *e2 = &A(j2, 0);
                ELE_TYPE *e3 = &A(j3, 0);
                for (INDEX_TYPE k = Up[i]; k < Up[i + 1]; k++) {
                    INDEX_TYPE c = Ui[k];
                    ELE_TYPE pv = pivot_row_ptr[c];
                    e0[c] -= l0 * pv;
                    e1[c] -= l1 * pv;
                    e2[c] -= l2 * pv;
                    e3[c] -= l3 * pv;
                    elimination_count += 4;
                }
            }
            // 处理剩余
            for (; p < p_end; p++) {
                INDEX_TYPE j = Li[p];
                if (A(j, i) == 0) continue;
                ELE_TYPE scale = A(j, i) / pivot;
                A(j, i) = scale;
                ELE_TYPE *pivot_row_ptr = &A(i, 0);
                ELE_TYPE *eli_row_ptr = &A(j, 0);
                for (INDEX_TYPE k = Up[i]; k < Up[i + 1]; k++) {
                    INDEX_TYPE c = Ui[k];
                    eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                    elimination_count++;
                }
            }
        }
    }
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    LOG_DEBUG("小主元个数   ::::%d\n", small_pivot);
    // print_dense_matrix(D, n);
    write_back_v5(Lp, Li, Lx, Ux, U_diag, D, n, offset);
    lu_free(D);
    lu_free(offset);
}
