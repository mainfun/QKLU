//
// Created by mainf on 2025/3/29.
//

#ifndef SP_FACTOR_H
#define SP_FACTOR_H
#include <base/matrix.h>
#ifdef __cplusplus
extern "C" {
#endif

void sp_factor_v0(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  INDEX_TYPE n);

void sp_factor_v1(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  INDEX_TYPE n, const INDEX_TYPE *Rp, const INDEX_TYPE *Ri);

void sp_factor_v2(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  const INDEX_TYPE n, const INDEX_TYPE *Rp, const INDEX_TYPE *Ri,
                  const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points);

void sp_factor_v3(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  const INDEX_TYPE n, const INDEX_TYPE *Rp, const INDEX_TYPE *Ri,
                  const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points);

void sp_factor_v4(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  ELE_TYPE *U_diag,INDEX_TYPE n);

void sp_factor_v5(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  ELE_TYPE *Ux,ELE_TYPE *U_diag,INDEX_TYPE n,
                  INDEX_TYPE split_points_num, const INDEX_TYPE *split_points);

void sp_factor_v6(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li, ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui, ELE_TYPE *Ux,
                  ELE_TYPE *U_diag,INDEX_TYPE n);

void sp_factor_v7(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li, ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui, ELE_TYPE *Ux,
                  ELE_TYPE *U_diag,INDEX_TYPE n);

void sp_factor_v7_parallel(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                           const INDEX_TYPE *Lp, const INDEX_TYPE *Li, ELE_TYPE *Lx,
                           const INDEX_TYPE *Up, const INDEX_TYPE *Ui, ELE_TYPE *Ux,
                           ELE_TYPE *U_diag,INDEX_TYPE n,
                           const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points);
#ifdef __cplusplus
}
#endif
#endif //SP_FACTOR_H
