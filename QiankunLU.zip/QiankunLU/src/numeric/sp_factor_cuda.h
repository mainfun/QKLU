//
// Created by mainf on 2025/5/21.
//

#ifndef SP_FACTOR_CUDA_H
#define SP_FACTOR_CUDA_H

#include <base/matrix.h>

void sp_factor_v0_cuda(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                       const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                       const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                       const INDEX_TYPE n, const INDEX_TYPE *Rp, const INDEX_TYPE *Ri,
                       const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points);

#endif //SP_FACTOR_CUDA_H
