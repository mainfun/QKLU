//
// Created by mainf on 2025/5/27.
//

#ifndef DGESSM_H
#define DGESSM_H
#include <base/matrix.h>

void SpGESSM(const CSRMatrix *L11, const CSRMatrix *A12, const CSRMatrix *U12);

void SpGESSM_v2(const CSC *L11, const CSC *A12, const CSC *U12);

#endif //DGESSM_H
