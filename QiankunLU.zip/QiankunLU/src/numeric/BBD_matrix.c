//
// Created by mainf on 2025/7/8.
//
#include "numeric/BBD_matrix.h"

BBD_Dense *malloc_BBD_Dense(const INDEX_TYPE dim11, const INDEX_TYPE dim22,
                            INDEX_TYPE *split_points, INDEX_TYPE split_num) {
    BBD_Dense *bbd = (BBD_Dense *) malloc(sizeof(BBD_Dense));
    bbd->B11_block_ptr = (L2_TYPE **) lu_malloc((split_num + 1) * sizeof(L2_TYPE *));
    bbd->B11_row_ptr = (L2_TYPE **) lu_malloc(dim11 * sizeof(L2_TYPE *));
    INDEX_TYPE sp0 = split_points[0];
    for (INDEX_TYPE ii = 0; ii <= split_num; ++ii) {
        split_points[ii] -= sp0;
    }
    bbd->split_points = split_points;
    bbd->split_num = split_num;
    size_t size = 0;
    //B11
    for (INDEX_TYPE ii = 0; ii < split_num; ++ii) {
        const INDEX_TYPE start = split_points[ii];
        const INDEX_TYPE end = split_points[ii + 1];
        const INDEX_TYPE side = end - start;
        size += side * side;
    }
    bbd->B11 = lu_calloc(size, sizeof(L2_TYPE));
    bbd->B12 = lu_calloc((dim11 * dim22), sizeof(L2_TYPE));
    bbd->B21 = lu_calloc((dim11 * dim22), sizeof(L2_TYPE));
    bbd->B22 = lu_calloc((dim22 * dim22), sizeof(L2_TYPE));
    bbd->dim11 = dim11;
    bbd->dim22 = dim22;
    size = 0;
    bbd->B11_block_ptr[0] = bbd->B11;
    for (INDEX_TYPE ii = 0; ii < split_num; ++ii) {
        const INDEX_TYPE start = split_points[ii];
        const INDEX_TYPE end = split_points[ii + 1];
        const INDEX_TYPE side = end - start;
        size += side * side;
        bbd->B11_block_ptr[ii + 1] = bbd->B11 + size;
        for (INDEX_TYPE i = start; i < end; ++i) {
            bbd->B11_row_ptr[i] = bbd->B11_block_ptr[ii] + (i - start) * side;
            // printf("bbd->B11_row_ptr[%lld]=%d\n", i, bbd->B11_row_ptr[i]);
        }
    }
    return bbd;
}

void free_BBD_Dense(BBD_Dense *bbd) {
    lu_free(bbd->B11);
    lu_free(bbd->B12);
    lu_free(bbd->B21);
    lu_free(bbd->B22);
    lu_free(bbd->B11_block_ptr);
    lu_free(bbd->B11_row_ptr);
}

void print_BBD_Dense(BBD_Dense *bbd, const INDEX_TYPE *split_points, const INDEX_TYPE split_num) {
    for (INDEX_TYPE ii = 0; ii < split_num; ++ii) {
        INDEX_TYPE start = split_points[ii];
        INDEX_TYPE end = split_points[ii + 1];
        INDEX_TYPE side = end - start;
        printf("B11(%lld)\n", ii);
        print_dense_matrix(bbd->B11_block_ptr[ii], side);
    }
    printf("B12:\n");
    print_dense_matrix2(bbd->B12, bbd->dim11, bbd->dim22);
    printf("B21:\n");
    print_dense_matrix2(bbd->B21, bbd->dim22, bbd->dim11);
    printf("B22:\n");
    print_dense_matrix(bbd->B22, bbd->dim22);
}
