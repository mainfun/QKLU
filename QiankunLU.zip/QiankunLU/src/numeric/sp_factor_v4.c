//
// Created by mainf on 2025/3/26.
// 对称矩阵分解实现
//
#include <math.h>
#include <omp.h>
#include <time.h>
#include "base/matrix.h"

#if defined(A)
#undef A
#endif
#define A(i,j)  D[ (i) * n + (j) ]

ELE_TYPE *malloc_dense_v4(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,INDEX_TYPE n) {
    ELE_TYPE *D = (ELE_TYPE *) lu_calloc(n * n, sizeof(ELE_TYPE));
    double factor_time = omp_get_wtime();
    struct timespec t_start, t_end;
    // 记录开始时间
    if (clock_gettime(CLOCK_MONOTONIC, &t_start) != 0) {
        perror("clock_gettime start");
        exit(1);
    }
    int count = 0;
    for (INDEX_TYPE r = 0; r < n; ++r) {
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            INDEX_TYPE idx = Ai[j];
            ELE_TYPE v = Ax[j];
            A(r, idx) = v;
            count++;
        }
    }
    LOG_DEBUG("count=%d", count);
    if (clock_gettime(CLOCK_MONOTONIC, &t_end) != 0) {
        perror("clock_gettime end");
        // return 1;
    }

    // 直接在这里计算时间差（纳秒）
    int64_t elapsed_ns =
            (int64_t) (t_end.tv_sec - t_start.tv_sec) * 1000000000LL
            + (int64_t) (t_end.tv_nsec - t_start.tv_nsec);

    printf("Elapsed: %lld ns (%.3f ms)\n",
           (long long) elapsed_ns,
           elapsed_ns / 1e6);
    LOG_TIME("malloc dense time: %f ms", (omp_get_wtime()-factor_time)*1000);
    //exit(1);
    return D;
}

void write_back_v4(const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                   const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                   ELE_TYPE *U_diag,ELE_TYPE *D,INDEX_TYPE n) {
    INDEX_TYPE l_count_csc = 0;
    INDEX_TYPE u_count_csr = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        //U csr
        U_diag[i] = A(i, i);
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            INDEX_TYPE index = Ui[j];
            Ux[u_count_csr++] = A(i, index);
        }
        //L csc
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            INDEX_TYPE index = Li[j];
            Lx[l_count_csc++] = A(index, i);
        }
    }
}

/**
 * 稀疏LU分解的朴素实现
 */
void sp_factor_v4(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  ELE_TYPE *U_diag,INDEX_TYPE n) {
    int small_pivot = 0;
    long long elimination_count = 0;
    double factor_time = omp_get_wtime();
    ELE_TYPE *D = malloc_dense_v4(Ap, Ai, Ax, n);
    LOG_TIME("malloc dense time: %f ms", (omp_get_wtime()-factor_time)*1000);
    // print_dense_matrix(D,n);
    //向下高斯消元
    for (INDEX_TYPE i = 0; i < n; ++i) {
        //枚举列
        ELE_TYPE pivot = A(i, i); // diag value
        if (fabs(pivot) < 1e-8) {
            pivot = pivot >= 0 ? 1e-8 : -1e-8;
            A(i, i) = pivot;
            small_pivot++;
            // continue;
        }
        // if (fabs(pivot) < 1e-12) continue;
        for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; p++) {
            INDEX_TYPE j = Li[p]; //行号
            if (A(j, i) == 0) continue;
            ELE_TYPE scale = A(j, i) / pivot;
            //L的列
            A(j, i) = scale;
            ELE_TYPE *pivot_row_ptr = &A(i, 0);
            ELE_TYPE *eli_row_ptr = &A(j, 0);
            for (INDEX_TYPE k = Up[i]; k < Up[i + 1]; k++) {
                INDEX_TYPE c = Ui[k];
                eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                // printf("%lf|",pivot);
                // LOG_DEBUG("i=%lld,j=%lld,k=%lld,  (%lld,%lld)%lf=%lf*%lf", i, j, k, j,c,eli_row_ptr[c], scale, pivot_row_ptr[c]);
                elimination_count++;
            }
            // printf("第%lld行消第%lld行 (elimination_count=%lld)\n", i + 1, j + 1,elimination_count);
        }
    }
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    LOG_DEBUG("小主元个数   ::::%d\n", small_pivot);
    // print_dense_matrix(D, n);
    write_back_v4(Lp, Li, Lx, Up, Ui, Ux, U_diag, D, n);
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
    lu_free(D);
}
