//
// Created by mainf on 2025/3/26.
//
#include <math.h>
#include <omp.h>
#include <time.h>

#include "numeric.h"
#include "base/matrix.h"
#include "numeric/sp_factor.h"

/**
 * L CSC, U CSC。使用左看法
 */
void sp_factor_v7(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li, ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui, ELE_TYPE *Ux,
                  ELE_TYPE *U_diag,INDEX_TYPE n) {
    double factor_time = omp_get_wtime();

    int small_pivot = 0;
    long long elimination_count = 0;
    ELE_TYPE *dense_vec = (ELE_TYPE *) lu_calloc(n, sizeof(ELE_TYPE));
    //dense vector
    for (INDEX_TYPE i = 0; i < n; ++i) {
        // Scatter A(:,i) into dense_vec
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            dense_vec[Ai[j]] = Ax[j];
        }
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
            INDEX_TYPE row = Ui[j]; //左看依赖列
            ELE_TYPE u = Ux[j] = dense_vec[row]; //u(row,i)
            dense_vec[row] = 0.0;
            if (u == 0.0) continue;
            // 当前列向量 -= u * 依赖列向量: dense_vec[c] -= l(i,col) * U(col,c)
            for (INDEX_TYPE k = Lp[row]; k < Lp[row + 1]; ++k) {
                dense_vec[Li[k]] -= u * Lx[k];
                elimination_count++;
            }
        }
        // Store U_diag
        ELE_TYPE pivot = U_diag[i] = dense_vec[i]; // diag value
        dense_vec[i] = 0.0;
        if (fabs(pivot) < 1e-8) {
            pivot = pivot >= 0 ? 1e-8 : -1e-8;
            U_diag[i] = pivot;
            small_pivot++;
        }
        // Store L-part
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            INDEX_TYPE r = Li[j];
            Lx[j] = dense_vec[r] / pivot;
            dense_vec[r] = 0.0;
        }
    }
    lu_free(dense_vec);
    LOG_DEBUG("消元次数为   ::::%lld", elimination_count);
    LOG_DEBUG("小主元个数   ::::%d", small_pivot);
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
}


void sp_factor_v7_parallel(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                           const INDEX_TYPE *Lp, const INDEX_TYPE *Li, ELE_TYPE *Lx,
                           const INDEX_TYPE *Up, const INDEX_TYPE *Ui, ELE_TYPE *Ux,
                           ELE_TYPE *U_diag,INDEX_TYPE n,
                           const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points) {
    double factor_time = omp_get_wtime();

    int small_pivot = 0;
    long long fma_count = 0;
    ELE_TYPE *dense_vec = (ELE_TYPE *) lu_calloc(n, sizeof(ELE_TYPE));
    #pragma omp parallel for schedule(static,1) proc_bind(spread) //reduction(+:fma_count)
    // #pragma omp parallel for schedule(dynamic) proc_bind(spread) reduction(+:fma_count)
    for (INDEX_TYPE ii = 0; ii < split_points_num; ++ii) {
        INDEX_TYPE start_row = split_points[ii];
        INDEX_TYPE end_row = split_points[ii + 1];
        for (INDEX_TYPE i = start_row; i < end_row; ++i) {
            for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
                dense_vec[Ai[j]] = Ax[j];
            }
            for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
                INDEX_TYPE row = Ui[j]; //左看依赖列
                ELE_TYPE u = Ux[j] = dense_vec[row]; //u(row,i)
                dense_vec[row] = 0.0;
                if (u == 0.0) continue;
                // 当前列向量 -= u * 依赖列向量: dense_vec[c] -= l(i,col) * U(col,c)
                for (INDEX_TYPE k = Lp[row]; k < Lp[row + 1]; ++k) {
                    dense_vec[Li[k]] -= u * Lx[k];
                    fma_count++;
                }
            }
            // Store U_diag
            ELE_TYPE pivot = U_diag[i] = dense_vec[i]; // diag value
            dense_vec[i] = 0.0;
            if (fabs(pivot) < 1e-8) {
                pivot = pivot >= 0 ? 1e-8 : -1e-8;
                U_diag[i] = pivot;
                small_pivot++;
            }
            // Store L-part
            for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
                INDEX_TYPE r = Li[j];
                Lx[j] = dense_vec[r] / pivot;
                dense_vec[r] = 0.0;
            }
        }
    }
    lu_free(dense_vec);
    LOG_DEBUG("消元次数为   ::::%lld", fma_count);
    LOG_DEBUG("小主元个数   ::::%d", small_pivot);
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
}
