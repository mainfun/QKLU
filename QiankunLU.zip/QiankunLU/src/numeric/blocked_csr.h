//
// Created by mainf on 2025/7/13.
//

#ifndef BLOCKED_CSR_H
#define BLOCKED_CSR_H

#include <base/matrix.h>

/**
 * A是N*M的
 * N: num_row
 * M: num_col
 */
void csr_block(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
               const int BLOCK_SIDE, const INDEX_TYPE N, const INDEX_TYPE M,
               const long long A_nnz,
               int **out_Sp, int **out_Si, INDEX_TYPE **out_Sx,
               int **out_Bp, int **out_Bi, ELE_TYPE **out_Bx);

void print_blocked_csr_dense(INDEX_TYPE N, INDEX_TYPE M, int BLOCK_SIDE,
                             const int *Sp, const int *Si, const INDEX_TYPE *Sx,
                             const int *Bp, const int *Bi, const ELE_TYPE *Bx);

#endif //BLOCKED_CSR_H
