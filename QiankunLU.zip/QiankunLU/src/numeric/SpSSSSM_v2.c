//
// Created by mainf on 2025/5/27.
//
#include <omp.h>
#include <base/matrix.h>
#include <base/matrix_util.h>
#include <math.h>
#include <numeric/BBD_matrix.h>

#include "SpSSSSM.h"

void SpSSSSM_DENSE_v2(const CSC *L21, const CSC *U12, const CSC *A22, L2_TYPE **R) {
    const INDEX_TYPE *Lp = L21->col_ptr;
    const INDEX_TYPE *Li = L21->row_idx;
    const ELE_TYPE *Lx = L21->values;
    const INDEX_TYPE *Up = U12->col_ptr;
    const INDEX_TYPE *Ui = U12->row_idx;
    const ELE_TYPE *Ux = U12->values;
    const INDEX_TYPE *Ap = A22->col_ptr;
    const INDEX_TYPE *Ai = A22->row_idx;
    const ELE_TYPE *Ax = A22->values;
    INDEX_TYPE dim = A22->num_col;

    double factor_time = omp_get_wtime();
    long long fma_count = 0;
    L2_TYPE *matrix = (L2_TYPE *) lu_calloc(dim * dim, sizeof(L2_TYPE));
    LOG_DEBUG("SpSSSSM_DENSE_v2 start......");
    #pragma omp parallel for schedule(static,1) proc_bind(spread) //reduction(+:fma_count)
    for (INDEX_TYPE i = 0; i < A22->num_col; ++i) {
        L2_TYPE *dense_vec = matrix + i * dim;
        // Scatter A(:,i) into dense_vec
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            dense_vec[Ai[j]] = Ax[j];
        }
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
            INDEX_TYPE row = Ui[j]; //左看依赖列
            ELE_TYPE u = Ux[j]; //u(row,i)
            // printf("u[%ld]=%lf,", j, u);
            if (u == 0.0) continue;
            // 当前列向量 -= u * 依赖列向量: dense_vec[c] -= l(i,col) * U(col,c)
            for (INDEX_TYPE k = Lp[row]; k < Lp[row + 1]; ++k) {
                dense_vec[Li[k]] -= u * Lx[k];
                fma_count++;
            }
        }
    }
    *R = matrix;
    LOG_DEBUG("消元次数为   ::::%lld", fma_count);
    LOG_TIME("SpSSSSM time: %f ms", (omp_get_wtime()-factor_time)*1000);
}

void SpSSSSM_BBD_DENSE(const CSC *L21, const CSC *U12, const CSC *A22, BBD_Dense *B) {
    const INDEX_TYPE *Lp = L21->col_ptr;
    const INDEX_TYPE *Li = L21->row_idx;
    const ELE_TYPE *Lx = L21->values;
    const INDEX_TYPE *Up = U12->col_ptr;
    const INDEX_TYPE *Ui = U12->row_idx;
    const ELE_TYPE *Ux = U12->values;
    const INDEX_TYPE *Ap = A22->col_ptr;
    const INDEX_TYPE *Ai = A22->row_idx;
    const ELE_TYPE *Ax = A22->values;
    const size_t total_dim = A22->num_row;

    double factor_time = omp_get_wtime();
    long long fma_count = 0;
    L2_TYPE *dense_vec = (L2_TYPE *) lu_calloc(total_dim, sizeof(L2_TYPE));
    // #pragma omp parallel for schedule(static,1) proc_bind(spread) reduction(+:fma_count)
    for (INDEX_TYPE ii = 0; ii < B->split_num; ++ii) {
        const INDEX_TYPE start = B->split_points[ii];
        const INDEX_TYPE end = B->split_points[ii + 1];
        for (INDEX_TYPE i = start; i < end; ++i) {
            for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
                const INDEX_TYPE idx = Ai[j];
                dense_vec[idx] = Ax[j];
            }
            for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
                INDEX_TYPE row = Ui[j]; //左看依赖列
                ELE_TYPE u = Ux[j]; //u(row,i)
                if (u == 0.0) continue;
                // 当前列向量 -= u * 依赖列向量: dense_vec[c] -= l(i,col) * U(col,c)
                for (INDEX_TYPE k = Lp[row]; k < Lp[row + 1]; ++k) {
                    dense_vec[Li[k]] -= u * Lx[k];
                    fma_count++;
                }
            }
            //store
            for (INDEX_TYPE j = start; j < end; ++j) {
                B->B11_row_ptr[i][j - start] = dense_vec[j];
                dense_vec[j] = 0.0;
            }
            for (INDEX_TYPE j = 0; j < B->dim22; ++j) {
                B->B12[i * B->dim22 + j] = dense_vec[j + B->dim11];
                dense_vec[j + B->dim11] = 0.0;
            }
        }
    }
    //B21 B22
    for (INDEX_TYPE i = B->dim11; i < total_dim; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            const INDEX_TYPE idx = Ai[j];
            dense_vec[idx] = Ax[j];
        }
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
            INDEX_TYPE row = Ui[j]; //左看依赖列
            ELE_TYPE u = Ux[j]; //u(row,i)
            if (u == 0.0) continue;
            // 当前列向量 -= u * 依赖列向量: dense_vec[c] -= l(i,col) * U(col,c)
            for (INDEX_TYPE k = Lp[row]; k < Lp[row + 1]; ++k) {
                dense_vec[Li[k]] -= u * Lx[k];
                fma_count++;
            }
        }
        //store
        INDEX_TYPE ii = i - B->dim11;
        for (INDEX_TYPE j = 0; j < B->dim11; ++j) {
            B->B21[ii * B->dim11 + j] = dense_vec[j];
            dense_vec[j] = 0.0;
        }
        for (INDEX_TYPE j = 0; j < B->dim22; ++j) {
            B->B22[ii * B->dim22 + j] = dense_vec[j + B->dim11];
            dense_vec[j + B->dim11] = 0.0;
        }
    }
    lu_free(dense_vec);
    LOG_DEBUG("消元次数为   ::::%lld", fma_count);
    LOG_TIME("SpSSSSM BBD DENSE time: %f ms", (omp_get_wtime()-factor_time)*1000);
}
