//
// Created by mainf on 2025/3/26.
// 朴素实现
//
#include <math.h>
#include <omp.h>
#include "base/matrix.h"

#if defined(A)
#undef A
#endif
#define A(i,j)  D[ (i) * n + (j) ]

ELE_TYPE *malloc_dense_v0(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,INDEX_TYPE n) {
    ELE_TYPE *D = (ELE_TYPE *) lu_calloc(n * n, sizeof(ELE_TYPE));
    for (INDEX_TYPE r = 0; r < n; ++r) {
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            A(r, Ai[j]) = Ax[j];
        }
    }
    return D;
}

void write_back_v0(const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                ELE_TYPE *D,INDEX_TYPE n) {
    INDEX_TYPE l_count_csc = 0;
    INDEX_TYPE u_count_csr = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        //U csr
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            INDEX_TYPE index = Ui[j];
            Ux[u_count_csr++] = A(i, index);
        }
        //L csc
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            INDEX_TYPE index = Li[j];
            Lx[l_count_csc++] = A(index, i);
        }
    }
}

/**
 * 稀疏LU分解的朴素实现
 */
void sp_factor_v0(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  INDEX_TYPE n) {
    double factor_time = omp_get_wtime();
    INDEX_TYPE elimination_count = 0;
    ELE_TYPE *D = malloc_dense_v0(Ap, Ai, Ax, n);
    //向下高斯消元
    for (INDEX_TYPE i = 0; i < n; ++i) {
        //枚举列
        ELE_TYPE pivot = A(i, i); // diag value
        if (fabs(pivot) < 1e-8) pivot = pivot >= 0 ? 1e-8 : -1e-8;
        A(i, i) = pivot;
        for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; p++) {
            INDEX_TYPE j = Li[p]; //行号
            //printf("第%lld行消第%lld行\n", i + 1, j + 1);
            ELE_TYPE scale = A(j, i) / pivot;
            //L的列
            A(j, i) = scale;
            ELE_TYPE *pivot_row_ptr = &A(i, 0);
            ELE_TYPE *eli_row_ptr = &A(j, 0);
            for (INDEX_TYPE k = Up[i] + 1; k < Up[i + 1]; k++) {
                INDEX_TYPE c = Ui[k];
                eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                elimination_count++;
            }
        }
    }
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    write_back_v0(Lp, Li, Lx, Up, Ui, Ux, D, n);
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
    lu_free(D);
}
