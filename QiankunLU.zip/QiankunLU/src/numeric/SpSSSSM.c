//
// Created by mainf on 2025/5/27.
//
#include <omp.h>
#include <base/matrix.h>
#include <base/matrix_util.h>

void SpSSSSM_CSR(const CSRMatrix *L21, const CSRMatrix *U12, const CSRMatrix *A22, const CSRMatrix *R) {
    const INDEX_TYPE *Lp = L21->row_pointers;
    const INDEX_TYPE *Li = L21->col_indices;
    const ELE_TYPE *Lx = L21->csr_values;
    const INDEX_TYPE *Up = U12->row_pointers;
    const INDEX_TYPE *Ui = U12->col_indices;
    ELE_TYPE *Ux = U12->csr_values;
    const INDEX_TYPE *Ap = A22->row_pointers;
    const INDEX_TYPE *Ai = A22->col_indices;
    const ELE_TYPE *Ax = A22->csr_values;

    long long elimination_count = 0;
    ELE_TYPE *dense_vec = (ELE_TYPE *) lu_calloc(A22->num_col, sizeof(ELE_TYPE)); //dense vector
    double factor_time = omp_get_wtime();
    // #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE i = 0; i < A22->num_row; ++i) {
        // Scatter A(i,:) into dense_vec
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            dense_vec[Ai[j]] = Ax[j];
        }
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            INDEX_TYPE col = Li[j]; //上看依赖行
            ELE_TYPE l = Lx[j]; //l(i,col)
            if (l == 0.0) continue;
            // 当前行向量 += l * 依赖行向量: dense_vec[c] -= l(i,col) * U(col,c)
            for (INDEX_TYPE k = Up[col]; k < Up[col + 1]; ++k) {
                ELE_TYPE v = l * Ux[k];
                INDEX_TYPE idx = Ui[k]; //太慢
                dense_vec[idx] -= v; //太慢
                //dense_vec[Ui[k]] -= l * Ux[k];
                elimination_count++;
            }
        }
        // Store R
        for (INDEX_TYPE j = R->row_pointers[i]; j < R->row_pointers[i + 1]; ++j) {
            INDEX_TYPE c = R->col_indices[j];
            Ux[j] = dense_vec[c];
            dense_vec[c] = 0.0;
        }
    }
    lu_free(dense_vec);
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
}

void SpSSSSM_DENSE(const CSRMatrix *L21, CSRMatrix *U12, const CSRMatrix *A22, ELE_TYPE **R) {
    const INDEX_TYPE *Lp = L21->row_pointers;
    const INDEX_TYPE *Li = L21->col_indices;
    const ELE_TYPE *Lx = L21->csr_values;
    const INDEX_TYPE *Up = U12->row_pointers;
    const INDEX_TYPE *Ui = U12->col_indices;
    ELE_TYPE *Ux = U12->csr_values;
    const INDEX_TYPE *Ap = A22->row_pointers;
    const INDEX_TYPE *Ai = A22->col_indices;
    const ELE_TYPE *Ax = A22->csr_values;
    INDEX_TYPE dim = A22->num_col;

    long long elimination_count = 0;
    double factor_time = omp_get_wtime();
    ELE_TYPE *matrix = (ELE_TYPE *) lu_calloc(A22->num_col * A22->num_row, sizeof(ELE_TYPE)); //dense vector
    #pragma omp parallel for schedule(static,1)//schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE i = 0; i < A22->num_row; ++i) {
        ELE_TYPE *vector = matrix + i * dim;
        // Scatter A(i,:) into vector
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            vector[Ai[j]] = Ax[j];
        }
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            INDEX_TYPE col = Li[j]; //上看依赖行
            ELE_TYPE l = Lx[j]; //l(i,col)
            if (l == 0.0) continue;
            // 当前行向量 += l * 依赖行向量: dense_vec[c] -= l(i,col) * U(col,c)
            for (INDEX_TYPE k = Up[col]; k < Up[col + 1]; ++k) {
                ELE_TYPE v = l * Ux[k];
                INDEX_TYPE idx = Ui[k]; //太慢
                vector[idx] -= v; //太慢
                //dense_vec[Ui[k]] -= l * Ux[k];
                elimination_count++;
            }
        }
    }
    *R = matrix;
    LOG_DEBUG("SSSSM DENSE 消元次数为   ::::%lld", elimination_count);
    LOG_TIME("SSSSM DENSE time: %f ms", (omp_get_wtime()-factor_time)*1000);
}
