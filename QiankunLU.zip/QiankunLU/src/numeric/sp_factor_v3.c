//
// Created by mainf on 2025/3/26.
// 这一版本增加了并行计算
//
#include <math.h>
#include <omp.h>
#include <stdint.h>
#include <base/base_math.h>

#include "base/matrix.h"

#if defined(A)
#undef A
#endif
#define A(i,j)  D[ offset[(i)] + (j) ]

extern INDEX_TYPE *get_offset(const INDEX_TYPE *row_pointers, const INDEX_TYPE *col_indices,
                              INDEX_TYPE n, INDEX_TYPE *d_size);

extern ELE_TYPE *malloc_dense_v2(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                                 const INDEX_TYPE n, const INDEX_TYPE d_size, const INDEX_TYPE *offset);

extern void write_back_v2(const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                          const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                          const ELE_TYPE *D,INDEX_TYPE n, const INDEX_TYPE *offset);

void sp_factor_v3(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  const INDEX_TYPE n, const INDEX_TYPE *Rp, const INDEX_TYPE *Ri,
                  const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points) {
    INDEX_TYPE elimination_count = 0;
    //稀疏转稠密
    INDEX_TYPE d_size = 0;
    INDEX_TYPE *offset = get_offset(Rp, Ri, n, &d_size);
    ELE_TYPE *D = malloc_dense_v2(Ap, Ai, Ax, n, d_size, offset);
    //向下高斯消元
    double factor_time = omp_get_wtime();
    // omp_set_num_threads(20);
    // printf("OpenMP 要求的最大线程数 = %d\n", omp_get_max_threads());
    #pragma omp parallel for reduction(+:elimination_count) proc_bind(spread) schedule(dynamic)
    for (INDEX_TYPE ii = 0; ii < split_points_num; ++ii) {
        // int tid = omp_get_thread_num();    // 获取线程 ID
        // int nt  = omp_get_num_threads();   // 获取线程总数
        // #pragma omp critical
        // printf("  线程 %d / %d 正在运行\n", tid, nt);
        INDEX_TYPE start_row = split_points[ii];
        INDEX_TYPE end_row = split_points[ii + 1];
        for (INDEX_TYPE i = start_row; i < end_row; ++i) {
            //枚举列
            ELE_TYPE pivot = A(i, i); // diag value
            if (fabs(pivot) < 1e-13) pivot = pivot >= 0 ? 1e-13 : -1e-13;
            A(i, i) = pivot;
            INDEX_TYPE p_start = Lp[i];
            INDEX_TYPE p_end = Lp[i + 1];
            INDEX_TYPE p = p_start;
            for (; p + 3 < p_end; p += 4) {
                INDEX_TYPE j0 = Li[p + 0];
                INDEX_TYPE j1 = Li[p + 1];
                INDEX_TYPE j2 = Li[p + 2];
                INDEX_TYPE j3 = Li[p + 3];
                ELE_TYPE l0 = A(j0, i) / pivot;
                ELE_TYPE l1 = A(j1, i) / pivot;
                ELE_TYPE l2 = A(j2, i) / pivot;
                ELE_TYPE l3 = A(j3, i) / pivot;
                A(j0, i) = l0;
                A(j1, i) = l1;
                A(j2, i) = l2;
                A(j3, i) = l3;
                ELE_TYPE *pivot_row_ptr = &A(i, 0);
                ELE_TYPE *e0 = &A(j0, 0);
                ELE_TYPE *e1 = &A(j1, 0);
                ELE_TYPE *e2 = &A(j2, 0);
                ELE_TYPE *e3 = &A(j3, 0);
                for (INDEX_TYPE k = Up[i] + 1; k < Up[i + 1]; k++) {
                    INDEX_TYPE c = Ui[k];
                    e0[c] -= l0 * pivot_row_ptr[c];
                    e1[c] -= l1 * pivot_row_ptr[c];
                    e2[c] -= l2 * pivot_row_ptr[c];
                    e3[c] -= l3 * pivot_row_ptr[c];
                    elimination_count+=4;
                }
            }
            // 处理剩余
            for (; p < p_end; p++) {
                INDEX_TYPE j = Li[p];
                ELE_TYPE scale = A(j, i) / pivot;
                A(j, i) = scale;
                ELE_TYPE *pivot_row_ptr = &A(i, 0);
                ELE_TYPE *eli_row_ptr = &A(j, 0);
                for (INDEX_TYPE k = Up[i] + 1; k < Up[i + 1]; k++) {
                    INDEX_TYPE c = Ui[k];
                    eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                    elimination_count++;
                }
            }
        }
    }
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    write_back_v2(Lp, Li, Lx, Up, Ui, Ux, D, n, offset);
    lu_free(offset);
    lu_free(D);
}
