//
// Created by mainf on 2025/3/26.
//
#include <math.h>
#include <omp.h>
#include "base/matrix.h"

/**
 * 稀疏LU分解的朴素实现
 */
void sp_factor_v0(const CSRMatrix *A, ELE_TYPE *Lx, ELE_TYPE *Ux,
               const INDEX_TYPE *Lp_start, const INDEX_TYPE *Lp_end, const INDEX_TYPE *Li,
               const INDEX_TYPE *Up_start, const INDEX_TYPE *Up_end, const INDEX_TYPE *Ui) {
    INDEX_TYPE n = A->num_row;
    INDEX_TYPE elimination_count = 0;
    //稀疏转稠密
    ELE_TYPE *D = csr2dense(A);
    double factor_time = omp_get_wtime();
    //向下高斯消元
    for (INDEX_TYPE i = 0; i < n; ++i) {
        //枚举列
        ELE_TYPE pivot = D[i * n + i]; // diag value
        if (fabs(pivot) < 1e-8) pivot = pivot >= 0 ? 1e-8 : -1e-8;
        D[i * n + i] = pivot;
        for (INDEX_TYPE p = Lp_start[i]; p < Lp_end[i]; p++) {
            INDEX_TYPE j = Li[p]; //行号
            //printf("第%lld行消第%lld行\n", i + 1, j + 1);
            ELE_TYPE scale = D[j * n + i] / pivot;
            //L的列
            D[j * n + i] = scale;
            ELE_TYPE *pivot_row_ptr = D + i * n;
            ELE_TYPE *eli_row_ptr = D + j * n;
            for (INDEX_TYPE k = Up_start[i] + 1; k < Up_end[i]; k++) {
                INDEX_TYPE c = Ui[k];
                eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                elimination_count++;
            }
        }
    }
    // if (A->nnz < 100) { LOG_INFO("D:"), print_dense_matrix(D, n); }
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    //写回
    INDEX_TYPE l_count_csc = 0;
    INDEX_TYPE u_count_csr = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        //U csr
        for (INDEX_TYPE j = Up_start[i]; j < Up_end[i]; j++) {
            INDEX_TYPE index = Ui[j];
            Ux[u_count_csr++] = D[i * n + index];
            //printf("D[%lld][%lld]=%lf ", i, index,D[i * n + index]);
        }
        //L csc
        for (INDEX_TYPE j = Lp_start[i]; j < Lp_end[i]; j++) {
            INDEX_TYPE index = Li[j];
            Lx[l_count_csc++] = D[index * n + i];
        }
    }
    LOG_TIME("time: %f ms", (omp_get_wtime()-factor_time)*1000);
    lu_free(D);
}
