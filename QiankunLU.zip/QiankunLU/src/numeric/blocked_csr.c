//
// Created by mainf on 2025/7/11.
//
#include "base/malloc.h"
#include <base/base_math.h>
#include <base/matrix.h>
#include <base/sort.h>

#include "base/log.h"
#include "omp.h"
#include "numeric/blocked_csr.h"

// const float DENSE_THRESHOLD = 0.3f;

/**
 * A是N*M的
 * N: num_row
 * M: num_col
 */
void csr_block(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
               const int BLOCK_SIDE, const INDEX_TYPE N, const INDEX_TYPE M,
               const long long A_nnz,
               int **out_Sp, int **out_Si, INDEX_TYPE **out_Sx,
               int **out_Bp, int **out_Bi, ELE_TYPE **out_Bx) {
    double block_time = omp_get_wtime();
    const int num_row_blk = BLOCK_SIDE;
    const int num_col_blk = BLOCK_SIDE;
    int nr_super = CEIL_DIV(N, num_row_blk); //num row super block
    int nc_super = CEIL_DIV(M, num_col_blk); //num col super block
    LOG_DEBUG("num_row_block: %d, num_col_block: %d", nr_super, nc_super);
    //---------------------计算super非零索引---------------------
    //统计block_nnz，计算Sp，Si,Sx
    int Si_capacity = nr_super * 10;
    int *Sp = (int *) lu_malloc((nr_super + 1) * sizeof(int)); //super block ptr
    int *Si = (int *) lu_malloc(Si_capacity * sizeof(int)); //super block idx
    Sp[0] = 0;
    int *block_nnz_arr = (int *) lu_calloc(nr_super * nc_super, sizeof(int));
    int block_count = 0;
    for (INDEX_TYPE i = 0; i < N; ++i) {
        if (block_count * 2 > Si_capacity) {
            Si_capacity = Si_capacity + Si_capacity / 2;
            Si = lu_realloc(Si, Si_capacity * sizeof(int));
        }
        //i / block_height 是块的行号，Ai[j] / block_width是块的列号
        int super_r = (int) (i / num_row_blk);
        const INDEX_TYPE base = super_r * nc_super;
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE super_c = Ai[j] / num_col_blk;
            INDEX_TYPE idx = base + super_c;
            // new block in this super-row;
            if (block_nnz_arr[idx] == 0) {
                // block_count++;
                Si[block_count++] = (int) super_c;
            }
            block_nnz_arr[idx]++;
        }
        Sp[super_r + 1] = block_count;
    }
    Si = lu_realloc(Si, block_count * sizeof(int));
    LOG_DEBUG("block_count: %d", block_count);
    sort_matrix_idx(Sp, Si, nr_super);
    //Sx是Bi的偏移
    INDEX_TYPE *Sx = (INDEX_TYPE *) lu_calloc(block_count + 1, sizeof(INDEX_TYPE));
    for (int i = 0; i < nr_super; ++i) {
        for (int j = Sp[i]; j < Sp[i + 1]; ++j) {
            int idx = Si[j];
            Sx[j + 1] = block_nnz_arr[i * nc_super + idx];
        }
    }
    //把 Sx 变成prefix-sum
    for (int k = 1; k <= block_count; ++k) {
        Sx[k] += Sx[k - 1];
    }
    lu_free(block_nnz_arr);
    /**--------------构建查询表，方便查询每个非空块的编号（查询是第几个块）---------------**/
    int *block_map = (int *) lu_calloc(nr_super * nc_super, sizeof(int));
    // s_nnz_idx -> block_map 快速查询super block的编号（是第几个非空块）
    for (int r = 0; r < nr_super; ++r) {
        for (int k = Sp[r]; k < Sp[r + 1]; ++k) {
            int c = Si[k];
            block_map[r * nc_super + c] = k;
        }
    }
    LOG_TIME("blocking elapsed time: %lf ms", (omp_get_wtime() - block_time) * 1000.0);
    /**--------------计算blk非零索引---------------**/
    int *Bp = (int *) lu_calloc((num_row_blk + 1) * block_count, sizeof(int)); //block ptr
    int *Bi = (int *) lu_malloc(A_nnz * sizeof(int)); //block idx
    ELE_TYPE *Bx = (ELE_TYPE *) lu_malloc(A_nnz * sizeof(ELE_TYPE)); //block idx
    int *blk_nnz_count = (int *) lu_calloc(block_count, sizeof(int)); //block ptr
    // #pragma omp parallel for schedule(static,1)
    for (INDEX_TYPE i = 0; i < N; i++) {
        const int super_r = (int) (i / num_row_blk);
        const int local_r = (int) (i % num_row_blk);
        for (INDEX_TYPE row_nz_idx = Ap[i]; row_nz_idx < Ap[i + 1]; row_nz_idx++) {
            const INDEX_TYPE col_idx = Ai[row_nz_idx];
            const int super_c = (int) (col_idx / num_col_blk);
            const int local_c = (int) (col_idx % num_col_blk);
            const int block_idx = block_map[super_r * nc_super + super_c];
            // Bi Bp 偏移到块起始
            int *Bi_local = Bi + Sx[block_idx];
            int *Bp_local = Bp + block_idx * (num_row_blk + 1);
            Bp_local[local_r + 1]++;
            Bi_local[blk_nnz_count[block_idx]++] = local_c;
        }
    }
    lu_free(blk_nnz_count);
    lu_free(block_map);
    //-------------------- Bp Prefix-sum --------------------
    for (int b = 0; b < block_count; ++b) {
        int *Bp_local = Bp + b * (num_row_blk + 1);
        //块内行遍历
        for (int r = 1; r <= num_row_blk; ++r) {
            Bp_local[r] += Bp_local[r - 1];
        }
    }
    *out_Sp = Sp;
    *out_Si = Si;
    *out_Sx = Sx;
    *out_Bp = Bp;
    *out_Bi = Bi;
    *out_Bx = Bx;
    LOG_TIME("blocking elapsed time: %lf ms", (omp_get_wtime() - block_time) * 1000.0);
}

/*
 * 打印 CSR 数据结构：Sp, Si, Sx, Bp, Bi
 * 参数说明：
 *   BLOCK_SIDE: 每个小块的边长
 *   nr_super: 超级块行数
 *   block_count: 非空块总数
 *   Sp: 长度 nr_super+1，超级块指针数组
 *   Si: 长度 block_count，存储每个非空超级块的列索引
 *   Sx: 长度 block_count+1，存储每个块在 Bi 中的偏移前缀和
 *   Bp: 长度 block_count*(BLOCK_SIDE+1)，每块内部行前缀和
 *   Bi: 长度 Sx[block_count]，存储所有块的本地列索引
 */
void print_blocked_csr(
    int n,
    int BLOCK_SIDE,
    int nr_super,
    int block_count,
    const int *Sp,
    const int *Si,
    const INDEX_TYPE *Sx,
    const int *Bp,
    const int *Bi) {
    // 打印 Sp
    printf("Sp (length %d):\n", nr_super + 1);
    for (int i = 0; i <= nr_super; ++i) {
        printf("  Sp[%d] = %d\n", i, Sp[i]);
    }
    printf("\n");

    // 打印 Si
    printf("Si (length %d):\n", block_count);
    for (int i = 0; i < block_count; ++i) {
        printf("  Si[%d] = %d\n", i, Si[i]);
    }
    printf("\n");

    // 打印 Sx
    printf("Sx (length %d):\n", block_count + 1);
    for (int i = 0; i <= block_count; ++i) {
        printf("  Sx[%d] = %lld\n", i, (long long) Sx[i]);
    }
    printf("\n");

    // 打印每个块的 Bp 和 Bi
    for (int i0 = 0; i0 < nr_super; ++i0) {
        for (int j0 = Sp[i0]; j0 < Sp[i0 + 1]; ++j0) {
            const int *Bp_local = Bp + j0 * (BLOCK_SIDE + 1);
            const int *Bi_local = Bi + Sx[j0];
            int num_row_blk = MIN(BLOCK_SIDE, n-i0*BLOCK_SIDE);

            // 打印 Bp_local
            printf("  Block[%d][%d]: ", i0, Si[j0]);
            for (int r = 0; r <= num_row_blk; ++r) {
                printf("%d", Bp_local[r]);
                if (r < num_row_blk) printf(", ");
            }
            printf("\n");

            // 打印 Bi_local
            for (int r = 0; r < num_row_blk; ++r) {
                for (int nnz_idx = Bp_local[r]; nnz_idx < Bp_local[r + 1]; ++nnz_idx) {
                    printf("%d,", Bi_local[nnz_idx]);
                }
                printf("\n");
            }
        }
    }
}


void print_blocked_csr_dense(INDEX_TYPE N, INDEX_TYPE M, int BLOCK_SIDE,
                             const int *Sp, const int *Si, const INDEX_TYPE *Sx,
                             const int *Bp, const int *Bi, const ELE_TYPE *Bx) {
    int nr_super = CEIL_DIV(N, BLOCK_SIDE);
    int nc_super = CEIL_DIV(M, BLOCK_SIDE);
    // 分配并初始化稠密矩阵标记 (0/1)
    ELE_TYPE **A = (ELE_TYPE **) malloc(N * sizeof(ELE_TYPE *));
    for (int i = 0; i < N; ++i) {
        A[i] = (ELE_TYPE *) calloc(M, sizeof(ELE_TYPE));
    }

    // 根据分块结构在稠密矩阵中标记非零位置
    for (int i0 = 0; i0 < nr_super; ++i0) {
        for (int j0 = Sp[i0]; j0 < Sp[i0 + 1]; ++j0) {
            const int *Bp_local = Bp + j0 * (BLOCK_SIDE + 1);
            const int *Bi_local = Bi + Sx[j0];
            int num_row_blk = MIN(BLOCK_SIDE, N - i0 * BLOCK_SIDE);

            for (int i = 0; i < num_row_blk; ++i) {
                for (int j = Bp_local[i]; j < Bp_local[i + 1]; ++j) {
                    int i_global = i0 * BLOCK_SIDE + i;
                    int j_global = Si[j0] * BLOCK_SIDE + Bi_local[j]; //Si[j0] * BLOCK_SIDE +
                    printf("(%d,%d),", i_global, j_global);
                    A[i_global][j_global] = Bx == NULL ? 1 : Bx[Sx[j0] + j];
                }
            }
            printf(" | ");
        }
        printf("\n");
    }


    // 打印稠密矩阵形式
    printf("矩阵表示:\n");
    for (int i = 0; i < N; ++i) {
        for (INDEX_TYPE ii = 0; ii < M; ++ii) {
            printf("---------------");
        }
        printf("\n|");
        for (int j = 0; j < M; ++j) {
            if (A[i][j] == 0.0)printf("              |");
            else printf("%13f |", A[i][j]);
        }
        printf("\n|");
    }
    for (INDEX_TYPE ii = 0; ii < M; ++ii) {
        printf("---------------");
    }
    // 释放内存
    for (int i = 0; i < N; ++i) {
        free(A[i]);
    }
    free(A);
}
//
// int main() {
//     int n = 7;
//     int m = 6;
//     long long A_nnz = 15;
//     INDEX_TYPE Ap[] = {0, 2, 4, 6, 9, 10, 12, 15};
//     INDEX_TYPE Ai[] = {0, 3, 2, 5, 1, 4, 0, 3, 5, 2, 1, 5, 3, 4, 5};
//     ELE_TYPE Ax[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6};
//
//     int BLOCK_SIDE = 2;
//     int *Sp, *Si, *Bp;
//     INDEX_TYPE *Sx;
//     int *Bi;
//     ELE_TYPE *Bx;
//
//     // 构造阻塞 CSR
//     csr_block(Ap, Ai, BLOCK_SIDE, n, m, A_nnz, &Sp, &Si, &Sx, &Bp, &Bi, &Bx);
//     // int nr_super = CEIL_DIV(n, BLOCK_SIDE);
//     // int nc_super = nr_super; // 方阵示例
//     // int block_count = Sp[nr_super];
//
//     // 打印稠密矩阵
//     // print_blocked_csr(n, BLOCK_SIDE, nr_super, block_count, Sp, Si, Sx, Bp, Bi);
//     print_blocked_csr_dense(n, m, BLOCK_SIDE, Sp, Si, Sx, Bp, Bi, Ax);
//
//     // 释放内存
//     free(Sp);
//     free(Si);
//     free(Sx);
//     free(Bp);
//     free(Bi);
//     return 0;
// }
