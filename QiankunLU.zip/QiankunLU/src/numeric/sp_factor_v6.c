//
// Created by mainf on 2025/3/26.
// L CSR, U CSR。上看法
//
#include <math.h>
#include <omp.h>
#include <time.h>
#include "base/matrix.h"

/**
 * L CSR, U CSR。使用上看法
 */
void sp_factor_v6(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li, ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui, ELE_TYPE *Ux,
                  ELE_TYPE *U_diag,INDEX_TYPE n) {
    int small_pivot = 0;
    long long elimination_count = 0;
    ELE_TYPE *dense_vec = (ELE_TYPE *) lu_calloc(n, sizeof(ELE_TYPE)); //dense vector
    double factor_time = omp_get_wtime();
    // #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE i = 0; i < n; ++i) {
        // Scatter A(i,:) into dense_vec
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            dense_vec[Ai[j]] = Ax[j];
        }
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            INDEX_TYPE col = Li[j]; //上看依赖行
            ELE_TYPE l = Lx[j] = dense_vec[col] / U_diag[col]; //l(i,col)
            dense_vec[col] = 0.0;
            if (l == 0.0) continue;
            // 当前行向量 += l * 依赖行向量: dense_vec[c] -= l(i,col) * U(col,c)
            for (INDEX_TYPE k = Up[col]; k < Up[col + 1]; ++k) {
                ELE_TYPE v = l * Ux[k];
                INDEX_TYPE idx = Ui[k];//太慢
                dense_vec[idx] -= v;//太慢
                //dense_vec[Ui[k]] -= l * Ux[k];
                elimination_count++;
            }
        }
        // Store U-part
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
            INDEX_TYPE c = Ui[j];
            Ux[j] = dense_vec[c];
            dense_vec[c] = 0.0;
        }
        ELE_TYPE pivot = U_diag[i] = dense_vec[i]; // diag value
        dense_vec[i] = 0.0;
        if (fabs(pivot) < 1e-8) {
            pivot = pivot >= 0 ? 1e-8 : -1e-8;
            U_diag[i] = pivot;
            small_pivot++;
        }
    }
    lu_free(dense_vec);
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    LOG_DEBUG("小主元个数   ::::%d\n", small_pivot);
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
}
