//
// Created by mainf on 2025/3/26.
//
#include <math.h>
#include <omp.h>
#include "base/matrix.h"

INDEX_TYPE *get_offset(const INDEX_TYPE *row_pointers, const INDEX_TYPE *col_indices,
                       INDEX_TYPE n, INDEX_TYPE *d_size) {
    INDEX_TYPE *offset = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    for (INDEX_TYPE k = 0; k < n; ++k) {
        INDEX_TYPE start = row_pointers[k];
        INDEX_TYPE end = row_pointers[k + 1];
        offset[k] = *d_size;
        //如果本行非空
        if (end != start) {
            *d_size += col_indices[end - 1] - col_indices[start] + 1;
        }
    }
    for (INDEX_TYPE r = 0; r < n; ++r) {
        //todo 空行的offset是冗余的
        offset[r] -= col_indices[row_pointers[r]];
    }
    return offset;
}

ELE_TYPE *malloc_dense_v1(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,INDEX_TYPE n) {
    ELE_TYPE *D = (ELE_TYPE *) lu_calloc(n * n, sizeof(ELE_TYPE));
    for (INDEX_TYPE r = 0; r < n; ++r) {
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            D[r * n + Ai[j]] = Ax[j];
        }
    }
    return D;
}



/**
 * 稀疏LU分解的朴素实现
 */
#define A(i,j)  D[ (i) * n + (j) ]

void sp_factor_v0(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  INDEX_TYPE n) {
    double factor_time = omp_get_wtime();
    INDEX_TYPE elimination_count = 0;
    //稀疏转稠密
    ELE_TYPE *D = malloc_dense_v1(Ap, Ai, Ax, n);
    //向下高斯消元
    for (INDEX_TYPE i = 0; i < n; ++i) {
        //枚举列
        ELE_TYPE pivot = A(i, i); // diag value
        if (fabs(pivot) < 1e-8) pivot = pivot >= 0 ? 1e-8 : -1e-8;
        A(i, i) = pivot;
        for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; p++) {
            INDEX_TYPE j = Li[p]; //行号
            //printf("第%lld行消第%lld行\n", i + 1, j + 1);
            ELE_TYPE scale = A(j, i) / pivot;
            //L的列
            A(j, i) = scale;
            ELE_TYPE *pivot_row_ptr = &A(i, 0);
            ELE_TYPE *eli_row_ptr = &A(j, 0);
            for (INDEX_TYPE k = Up[i] + 1; k < Up[i + 1]; k++) {
                INDEX_TYPE c = Ui[k];
                eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                elimination_count++;
            }
        }
    }
    // if (A->nnz < 100) { LOG_INFO("D:"), print_dense_matrix(D, n); }
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    //写回
    INDEX_TYPE l_count_csc = 0;
    INDEX_TYPE u_count_csr = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        //U csr
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            INDEX_TYPE index = Ui[j];
            Ux[u_count_csr++] = A(i, index);
            //printf("D[%lld][%lld]=%lf ", i, index,D[i * n + index]);
        }
        //L csc
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            INDEX_TYPE index = Li[j];
            Lx[l_count_csc++] = A(index, i);
        }
    }
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
    lu_free(D);
}

#if defined(A)
#undef A
#endif

#define A(i,j)  D[ offset[(i)] + (j) ]

void sp_factor_v1(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  INDEX_TYPE start_row,INDEX_TYPE end_row) {
    INDEX_TYPE n = end_row - start_row;
    INDEX_TYPE elimination_count = 0;
    //稀疏转稠密
    INDEX_TYPE d_size = 0;
    INDEX_TYPE *offset = get_offset(Ap, Ai, n, &d_size);
    ELE_TYPE *D = lu_calloc(d_size, sizeof(ELE_TYPE));
    for (INDEX_TYPE r = start_row; r < end_row; ++r) {
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            A(r, Ai[j]) = Ax[j];
        }
    }
    double factor_time = omp_get_wtime();
    //向下高斯消元
    for (INDEX_TYPE i = start_row; i < end_row; ++i) {
        //枚举列
        ELE_TYPE pivot = A(i, i); // diag value
        if (fabs(pivot) < 1e-8) pivot = pivot >= 0 ? 1e-8 : -1e-8;
        A(i, i) = pivot;
        for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; p++) {
            INDEX_TYPE j = Li[p]; //行号
            //printf("第%lld行消第%lld行\n", i + 1, j + 1);
            ELE_TYPE scale = A(j, i) / pivot;
            //L的列
            A(j, i) = scale;
            ELE_TYPE *pivot_row_ptr = &A(i, 0);
            ELE_TYPE *eli_row_ptr = &A(j, 0);
            for (INDEX_TYPE k = Up[i] + 1; k < Up[i + 1]; k++) {
                INDEX_TYPE c = Ui[k];
                eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                elimination_count++;
            }
        }
    }
    // if (A->nnz < 100) { LOG_INFO("D:"), print_dense_matrix(D, n); }
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    //写回
    INDEX_TYPE l_count_csc = 0;
    INDEX_TYPE u_count_csr = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        //U csr
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            INDEX_TYPE index = Ui[j];
            Ux[u_count_csr++] = A(i, index);;
            //printf("D[%lld][%lld]=%lf ", i, index,D[i * n + index]);
        }
        //L csc
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            INDEX_TYPE index = Li[j];
            Lx[l_count_csc++] = A(index, i);
        }
    }
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
    lu_free(offset);
    lu_free(D);
}


void sp_factor_parallel_v0(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax, const INDEX_TYPE n,
                           const INDEX_TYPE *Lp, const INDEX_TYPE *Li, ELE_TYPE *Lx,
                           const INDEX_TYPE *Up, const INDEX_TYPE *Ui, ELE_TYPE *Ux,
                           const INDEX_TYPE split_points_num, INDEX_TYPE *split_points) {
    INDEX_TYPE elimination_count = 0;
    //稀疏转稠密
    ELE_TYPE *D = csr2dense_v2(Ap, Ap + 1, Ai, Ax, n); //offset格式
    double factor_time = omp_get_wtime();
    //向下高斯消元
    for (INDEX_TYPE i = 0; i < n; ++i) {
        //枚举列
        ELE_TYPE pivot = D[i * n + i]; // diag value
        if (fabs(pivot) < 1e-8) pivot = pivot >= 0 ? 1e-8 : -1e-8;
        D[i * n + i] = pivot;
        for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; p++) {
            INDEX_TYPE j = Li[p]; //行号
            //printf("第%lld行消第%lld行\n", i + 1, j + 1);
            ELE_TYPE scale = D[j * n + i] / pivot;
            //L的列
            D[j * n + i] = scale;
            ELE_TYPE *pivot_row_ptr = D + i * n;
            ELE_TYPE *eli_row_ptr = D + j * n;
            for (INDEX_TYPE k = Up[i] + 1; k < Up[i + 1]; k++) {
                INDEX_TYPE c = Ui[k];
                eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                elimination_count++;
            }
        }
    }
    // if (A->nnz < 100) { LOG_INFO("D:"), print_dense_matrix(D, n); }
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    //写回
    INDEX_TYPE l_count_csc = 0;
    INDEX_TYPE u_count_csr = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        //U csr
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            INDEX_TYPE index = Ui[j];
            Ux[u_count_csr++] = D[i * n + index];
            //printf("D[%lld][%lld]=%lf ", i, index,D[i * n + index]);
        }
        //L csc
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            INDEX_TYPE index = Li[j];
            Lx[l_count_csc++] = D[index * n + i];
        }
    }
    LOG_TIME("time: %f ms", (omp_get_wtime()-factor_time)*1000);
    lu_free(D);
}
