//
// Created by mainf on 2025/3/23.
//
#include <math.h>
#include <omp.h>
#include <base/base_math.h>
#include <base/matrix_util.h>
#include <preprocess/symbolic_analysis.h>
#include <numeric/numeric.h>

#include "base/matrix.h"

#define SPLIT_THRESHOLD ((INDEX_TYPE) 32)

void malloc_csr_matrix(CSRMatrix *A, INDEX_TYPE num_row,INDEX_TYPE num_col) {
    A->num_row = num_row;
    A->num_col = num_col;
    A->row_pointers = (INDEX_TYPE *) lu_calloc(num_row + 1, sizeof(INDEX_TYPE));
    A->col_indices = (INDEX_TYPE *) lu_malloc(A->nnz * sizeof(INDEX_TYPE));
    A->csr_values = (ELE_TYPE *) lu_malloc(A->nnz * sizeof(ELE_TYPE));
}

void blocking_csr_4m(const INDEX_TYPE n,
                     const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                     const INDEX_TYPE cut_point,
                     CSRMatrix *A11, CSRMatrix *A12, CSRMatrix *A21, CSRMatrix *A22) {
    double start_time = omp_get_wtime();
    //  ---------------------------统计nnz---------------------------
    A11->nnz = A12->nnz = A21->nnz = A22->nnz = 0;
    for (INDEX_TYPE i = 0; i < cut_point; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            if (Ai[j] >= cut_point) A12->nnz++;
            else A11->nnz++;
        }
    }
    for (INDEX_TYPE i = cut_point; i < n; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            if (Ai[j] >= cut_point) A22->nnz++;
            else A21->nnz++;
        }
    }
    malloc_csr_matrix(A11, cut_point, cut_point);
    malloc_csr_matrix(A12, cut_point, n - cut_point);
    malloc_csr_matrix(A21, n - cut_point, cut_point);
    malloc_csr_matrix(A22, n - cut_point, n - cut_point);
    //  ---------------------------end 统计nnz---------------------------
    INDEX_TYPE A11_idx = 0;
    INDEX_TYPE A12_idx = 0;
    for (INDEX_TYPE i = 0; i < cut_point; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE c = Ai[j];
            ELE_TYPE v = Ax[j];
            if (c >= cut_point) {
                //A12
                A12->col_indices[A12_idx] = c - cut_point;
                A12->csr_values[A12_idx++] = v;
            } else {
                //A11
                A11->col_indices[A11_idx] = c;
                A11->csr_values[A11_idx++] = v;
            }
        }
        A11->row_pointers[i + 1] = A11_idx;
        A12->row_pointers[i + 1] = A12_idx;
    }
    INDEX_TYPE A21_idx = 0;
    INDEX_TYPE A22_idx = 0;
    for (INDEX_TYPE i = cut_point; i < n; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE c = Ai[j];
            ELE_TYPE v = Ax[j];
            if (c >= cut_point) {
                //A22
                A22->col_indices[A22_idx] = c - cut_point;
                A22->csr_values[A22_idx++] = v;
            } else {
                //A21
                A21->col_indices[A21_idx] = c;
                A21->csr_values[A21_idx++] = v;
            }
        }
        A21->row_pointers[i - cut_point + 1] = A21_idx;
        A22->row_pointers[i - cut_point + 1] = A22_idx;
    }
    LOG_TIME("get A11 A12 A21 A22 time: %f ms", (omp_get_wtime()-start_time)*1000);
}

/**
 * @param start 割线开始的行（列）号
 * @param end 割线结束的行（列）号
 */
ELE_TYPE *blocking_A11(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                       INDEX_TYPE start,INDEX_TYPE end) {
    INDEX_TYPE n = end - start;
    ELE_TYPE *D = (ELE_TYPE *) lu_calloc(n * n, sizeof(ELE_TYPE));
    for (INDEX_TYPE r = 0; r < n; ++r) {
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            D[r * n + Ai[j] - start] = Ax[j];
        }
    }
    return D;
}

/**
 * @param start 割线开始的行（列）号
 * @param end 割线结束的行（列）号
 */
void blocking_sp_A11(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                     INDEX_TYPE *rp, INDEX_TYPE *ri, ELE_TYPE *rx,
                     INDEX_TYPE start, INDEX_TYPE end) {
    INDEX_TYPE n = end - start;
    INDEX_TYPE nnz = 0;
    rp[0] = 0;
    for (INDEX_TYPE r = 0; r < n; ++r) {
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            INDEX_TYPE c = Ai[j] - start;
            ri[nnz] = c;
            rx[nnz++] = Ax[j];
        }
        rp[r] = nnz;
    }
}


void reverse_array(INDEX_TYPE *arr, INDEX_TYPE size) {
    INDEX_TYPE start = 0;
    INDEX_TYPE end = size - 1;

    // 交换开头和结尾的元素，直到中间
    while (start < end) {
        // 交换元素
        INDEX_TYPE temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;

        start++;
        end--;
    }
}

void find_split_points(const INDEX_TYPE a[], INDEX_TYPE n, INDEX_TYPE *split_points, INDEX_TYPE *top_ptr) {
    if (split_points == NULL)
        LOG_ERROR("cut_point==NULL");
    INDEX_TYPE top = 0;
    split_points[top] = n;
    INDEX_TYPE remaining_steps = 0;
    for (INDEX_TYPE i = n - 1; i >= 0; --i) {
        remaining_steps = MAX(remaining_steps, a[i]);
        if (remaining_steps == 0) {
            if (split_points[top] - i > SPLIT_THRESHOLD) {
                split_points[++top] = i;
            }
        }
        remaining_steps--;
    }
    *top_ptr = top;
    reverse_array(split_points, top);

    // for (INDEX_TYPE i = 0; i < top; ++i) {
    //     printf("(%lld)", split_points[i]);
    // }
    // printf("\n");
}

//废弃
INDEX_TYPE *dispatch_find_split_points(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                                       INDEX_TYPE n, INDEX_TYPE nnz, INDEX_TYPE *top) {
    double start_time = omp_get_wtime();
    //-----------------------------------------------------------------------
    INDEX_TYPE *Bp;
    INDEX_TYPE *Bi;
    INDEX_TYPE bnz;
    a_plus_at(n, nnz, Ap, Ai, &bnz, &Bp, &Bi); //有BUG，其实需要排序

    INDEX_TYPE values[n];
    for (INDEX_TYPE i = 0; i < n; ++i) {
        if (Bp[i] == Bp[i + 1]) {
            values[i] = 0;
            continue;
        }
        INDEX_TYPE idx = Bi[Bp[i]];
        values[i] = MAX(i - idx, 0);
    }
    lu_free(Bp);
    lu_free(Bi);
    //-----------------------------------------------------------------------
    INDEX_TYPE *split_points = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    //split_points数组前面加个0元素
    split_points[0] = 0;
    find_split_points(values, n, split_points + 1, top);
    LOG_TIME("dispatch_find_split_points time: %f ms", (omp_get_wtime()-start_time)*1000);
    return split_points;
}

INDEX_TYPE *dispatch_find_split_points_sym(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                                           INDEX_TYPE n, INDEX_TYPE *top) {
    double start_time = omp_get_wtime();
    INDEX_TYPE *values = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    INDEX_TYPE *min_row = A_min_row_idx(Ap, Ai, n);
    for (INDEX_TYPE i = 0; i < n; ++i) {
        if (Ap[i] == Ap[i + 1]) {
            values[i] = 0;
            continue;
        }
        INDEX_TYPE idx = Ai[Ap[i]];
        idx = MIN(idx, min_row[i]);//A+AT
        values[i] = MAX(i - idx, 0);
    }
    //-----------------------------------------------------------------------
    INDEX_TYPE *split_points = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    //split_points数组前面加个0元素
    split_points[0] = 0;
    find_split_points(values, n, split_points + 1, top);
    LOG_TIME("dispatch_find_split_points time: %f ms", (omp_get_wtime()-start_time)*1000);
    lu_free(values);
    return split_points;
}

#define pivot_threshold 1e-8
#define DA(i,j) a[n*(i)+(j)]

void LUD(ELE_TYPE *a, int n) {
    for (int i = 0; i < n; ++i) {
        ELE_TYPE pivot = DA(i, i);
        if (fabs(pivot) < pivot_threshold)pivot = pivot > 0 ? pivot_threshold : -pivot_threshold;
        DA(i, i) = pivot;
        for (int j = i + 1; j < n; ++j) {
            ELE_TYPE l = DA(j, i) /= pivot;
            if (l == 0) continue;
            for (int k = i + 1; k < n; ++k) {
                DA(j, k) -= l * DA(i, k);
            }
        }
    }
}

void L1_LU_decomposition_A11(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,
                             INDEX_TYPE n, INDEX_TYPE nnz) {
    INDEX_TYPE split_points_num;
    INDEX_TYPE *split_points = dispatch_find_split_points(Ap, Ai, n, nnz, &split_points_num);
    double omp_time = omp_get_wtime();
    #pragma omp parallel for
    for (INDEX_TYPE i = 0; i < split_points_num; ++i) {
        INDEX_TYPE start_row = split_points[i];
        INDEX_TYPE end_row = split_points[i + 1];
        ELE_TYPE *A11_dense = blocking_A11(Ap + start_row, Ai, Ax, start_row, end_row);
        LUD(A11_dense, (int) (end_row - start_row));
        CSRMatrix A11_struct;
        dense2csr_struct_fp(end_row - start_row, end_row - start_row,
                            A11_dense, &A11_struct.row_pointers,
                            &A11_struct.col_indices);
        lu_free(A11_struct.row_pointers);
        lu_free(A11_struct.col_indices);
        lu_free(A11_dense);
    }
    LOG_TIME("A11 total time:%f", (omp_get_wtime()-omp_time)*1000);
    lu_free(split_points);
}

void L1_LU_decomposition_sp_A11(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,
                                INDEX_TYPE n, INDEX_TYPE nnz) {
    INDEX_TYPE split_points_num;
    INDEX_TYPE *split_points = dispatch_find_split_points(Ap, Ai, n, nnz, &split_points_num);
    double omp_time = omp_get_wtime();
    #pragma omp parallel for
    for (INDEX_TYPE i = 0; i < split_points_num; ++i) {
        INDEX_TYPE start_row = split_points[i];
        INDEX_TYPE end_row = split_points[i + 1];
        INDEX_TYPE r_nnz = Ap[end_row] - Ap[start_row];
        //块CSR。block_p block_i block_x
        INDEX_TYPE *block_p = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
        INDEX_TYPE *block_i = (INDEX_TYPE *) lu_malloc(r_nnz * sizeof(INDEX_TYPE));
        ELE_TYPE *block_x = (ELE_TYPE *) lu_malloc(r_nnz * sizeof(ELE_TYPE));

        blocking_sp_A11(Ap, Ai, Ax, block_p, block_i, block_x, start_row, end_row);

        lu_free(block_x);
        lu_free(block_p);
        lu_free(block_i);
    }
    LOG_TIME("A11 total time:%f", (omp_get_wtime()-omp_time)*1000);
    lu_free(split_points);
}

void L1_solving_A12() {
}

void L1_solving_A21() {
}
