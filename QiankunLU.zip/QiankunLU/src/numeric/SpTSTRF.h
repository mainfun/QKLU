//
// Created by mainf on 2025/3/29.
//
//Triangular-Square triangular factorization
#ifndef TSTRF_H
#define TSTRF_H
#ifdef __cplusplus
extern "C" {
#endif
#include <base/matrix.h>

void SpTSTRF(const CSRMatrix *U11, const CSRMatrix *A21,
             const CSRMatrix *L21, const ELE_TYPE *U_diag);

void SpTSTRF_v2(const CSC *U11, const CSC *A21, const CSC *L21, const ELE_TYPE *U_diag);

void SpTSTRF_v2_parallel(const CSC *U11, const CSC *A21, const CSC *L21, const ELE_TYPE *U_diag,
                         const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points);

#ifdef __cplusplus
}
#endif
#endif //TSTRF_H
