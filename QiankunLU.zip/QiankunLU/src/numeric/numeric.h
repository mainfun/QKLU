//
// Created by mainf on 2025/3/25.
//

#ifndef NUMERIC_H
#define NUMERIC_H
#include <base/matrix.h>
#ifdef __cplusplus
extern "C" {
#endif

INDEX_TYPE *dispatch_find_split_points(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                                       INDEX_TYPE n,INDEX_TYPE nnz, INDEX_TYPE *top);


INDEX_TYPE *dispatch_find_split_points_sym(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                                           INDEX_TYPE n, INDEX_TYPE *top);

/**
 * 把一个CSR矩阵分位4块
 */
void blocking_csr_4m(INDEX_TYPE n, const INDEX_TYPE *Ap,
                     const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                     INDEX_TYPE cut_point,
                     CSRMatrix *A11, CSRMatrix *A12,
                     CSRMatrix *A21, CSRMatrix *A22);

#ifdef __cplusplus
}
#endif
#endif //NUMERIC_H
