//
// Created by mainf on 2025/5/27.
//

#ifndef DSSSSM_H
#define DSSSSM_H

#include <base/matrix.h>

#include "BBD_matrix.h"

#define L2_TYPE double
#define LAPACK_LU LAPACKE_dgetrf
#define LAPACK_SOLVE LAPACKE_dgetrs

// #define L2_TYPE float
// #define LAPACK_LU LAPACKE_sgetrf
// #define LAPACK_SOLVE LAPACKE_sgetrs

void SpSSSSM_DENSE(const CSRMatrix *L21, CSRMatrix *U12, const CSRMatrix *A22, ELE_TYPE **R);

void SpSSSSM_DENSE_v2(const CSC *L21, const CSC *U12, const CSC *A22, L2_TYPE **R);

void SpSSSSM_BBD_DENSE(const CSC *L21, const CSC *U12, const CSC *A22, BBD_Dense *B);


#endif //DSSSSM_H
