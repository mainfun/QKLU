//
// Created by mainf on 2025/3/29.
//

#include "SpTSTRF.h"

#include <omp.h>
#include <math.h>
#include <base/base_math.h>
#include <base/matrix.h>
#include <preprocess/preprocess.h>

//解L21
void SpTSTRF_v2(const CSC *U11, const CSC *A21, const CSC *L21, const ELE_TYPE *U_diag) {
    const INDEX_TYPE *Lp = L21->col_ptr;
    const INDEX_TYPE *Li = L21->row_idx;
    ELE_TYPE *Lx = L21->values;
    const INDEX_TYPE *Up = U11->col_ptr;
    const INDEX_TYPE *Ui = U11->row_idx;
    const ELE_TYPE *Ux = U11->values;
    const INDEX_TYPE *Ap = A21->col_ptr;
    const INDEX_TYPE *Ai = A21->row_idx;
    const ELE_TYPE *Ax = A21->values;
    double factor_time = omp_get_wtime();
    long long fma_count = 0;
    ELE_TYPE *dense_vec = (ELE_TYPE *) lu_calloc(A21->num_row, sizeof(ELE_TYPE));
    // #pragma omp parallel for schedule(dynamic) proc_bind(spread) reduction(+:fma_count)
    for (INDEX_TYPE i = 0; i < A21->num_col; ++i) {
        // Scatter A(:,i) into dense_vec
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            dense_vec[Ai[j]] = Ax[j];
        }
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
            INDEX_TYPE row = Ui[j]; //左看依赖列
            ELE_TYPE u = Ux[j]; //u(row,i)
            if (u == 0.0) continue;
            // 当前列向量 -= u * 依赖列向量: dense_vec[c] -= l(i,col) * U(col,c)
            for (INDEX_TYPE k = Lp[row]; k < Lp[row + 1]; ++k) {
                dense_vec[Li[k]] -= u * Lx[k];
                fma_count++;
            }
        }
        ELE_TYPE pivot = U_diag[i]; // diag value
        // Store L-part
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            INDEX_TYPE r = Li[j];
            Lx[j] = dense_vec[r] / pivot;
            dense_vec[r] = 0.0;
        }
    }
    lu_free(dense_vec);
    LOG_DEBUG("消元次数为   ::::%lld", fma_count);
    LOG_TIME("SpTSTRF time: %f ms", (omp_get_wtime()-factor_time)*1000);
}


void SpTSTRF_v2_parallel(const CSC *U11, const CSC *A21, const CSC *L21, const ELE_TYPE *U_diag,
    const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points) {
    const INDEX_TYPE *Lp = L21->col_ptr;
    const INDEX_TYPE *Li = L21->row_idx;
    ELE_TYPE *Lx = L21->values;
    const INDEX_TYPE *Up = U11->col_ptr;
    const INDEX_TYPE *Ui = U11->row_idx;
    const ELE_TYPE *Ux = U11->values;
    const INDEX_TYPE *Ap = A21->col_ptr;
    const INDEX_TYPE *Ai = A21->row_idx;
    const ELE_TYPE *Ax = A21->values;
    double factor_time = omp_get_wtime();
    long long fma_count = 0;

    #pragma omp parallel proc_bind(spread) //reduction(+:fma_count)
    {
        ELE_TYPE *dense_vec = (ELE_TYPE *) lu_calloc(A21->num_row, sizeof(ELE_TYPE));
        #pragma omp for schedule(static,1) //schedule(dynamic)
        for (INDEX_TYPE ii = 0; ii < split_points_num; ++ii) {
            INDEX_TYPE start_row = split_points[ii];
            INDEX_TYPE end_row = split_points[ii + 1];
            for (INDEX_TYPE i = start_row; i < end_row; ++i) {
                // Scatter A(:,i) into dense_vec
                for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
                    dense_vec[Ai[j]] = Ax[j];
                }
                for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
                    INDEX_TYPE row = Ui[j]; //左看依赖列
                    ELE_TYPE u = Ux[j]; //u(row,i)
                    if (u == 0.0) continue;
                    // 当前列向量 -= u * 依赖列向量: dense_vec[c] -= l(i,col) * U(col,c)
                    for (INDEX_TYPE k = Lp[row]; k < Lp[row + 1]; ++k) {
                        dense_vec[Li[k]] -= u * Lx[k];
                        fma_count++;
                    }
                }
                ELE_TYPE pivot = U_diag[i]; // diag value
                // Store L-part
                for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
                    INDEX_TYPE r = Li[j];
                    Lx[j] = dense_vec[r] / pivot;
                    dense_vec[r] = 0.0;
                }
            }
        }
        lu_free(dense_vec);
    }
    LOG_DEBUG("消元次数为   ::::%lld", fma_count);
    LOG_TIME("SpTSTRF time: %f ms", (omp_get_wtime()-factor_time)*1000);
}