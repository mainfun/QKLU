//
// Created by mainf on 2025/3/26.
// 这一版本增加了并行计算
//
#include <math.h>
#include <omp.h>
#include <stdint.h>
#include <base/base_math.h>

#include "base/matrix.h"

#if defined(A)
#undef A
#endif
#define A(i,j)  D[ offset[(i)] + (j) ]

extern INDEX_TYPE *get_offset(const INDEX_TYPE *row_pointers, const INDEX_TYPE *col_indices,
                              INDEX_TYPE n, INDEX_TYPE *d_size);

ELE_TYPE *malloc_dense_v2(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                          const INDEX_TYPE n, const INDEX_TYPE d_size, const INDEX_TYPE *offset) {
    double time = omp_get_wtime();
    ELE_TYPE *D; // = (ELE_TYPE *) aligned_alloc(64, d_size * sizeof(ELE_TYPE));
    // posix_memalign((void**)&D, 64, d_size * sizeof(ELE_TYPE));
    D = (ELE_TYPE *) lu_calloc(d_size, sizeof(ELE_TYPE));
    #pragma omp parallel for
    for (INDEX_TYPE r = 0; r < n; ++r) {
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            A(r, Ai[j]) = Ax[j];
        }
    }
    LOG_TIME("malloc time: %f ms", (omp_get_wtime()-time)*1000);
    return D;
}

void write_back_v2(const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                   const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                   const ELE_TYPE *D,INDEX_TYPE n, const INDEX_TYPE *offset) {
    double write_back_time = omp_get_wtime();
    #pragma omp parallel for //proc_bind(spread) schedule(static)
    for (INDEX_TYPE i = 0; i < n; i++) {
        //U csr
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            INDEX_TYPE index = Ui[j];
            Ux[j] = A(i, index);
        }
        //L csc
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            INDEX_TYPE index = Li[j];
            Lx[j] = A(index, i);
        }
    }
    LOG_TIME("write back time: %f ms", (omp_get_wtime()-write_back_time)*1000);
}

void sp_factor_v2(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                  const INDEX_TYPE *Lp, const INDEX_TYPE *Li,ELE_TYPE *Lx,
                  const INDEX_TYPE *Up, const INDEX_TYPE *Ui,ELE_TYPE *Ux,
                  const INDEX_TYPE n, const INDEX_TYPE *Rp, const INDEX_TYPE *Ri,
                  const INDEX_TYPE split_points_num, const INDEX_TYPE *split_points) {
    INDEX_TYPE elimination_count = 0;
    //稀疏转稠密
    INDEX_TYPE d_size = 0;
    INDEX_TYPE *offset = get_offset(Rp, Ri, n, &d_size);
    ELE_TYPE *D = malloc_dense_v2(Ap, Ai, Ax, n, d_size, offset);
    //向下高斯消元
    double factor_time = omp_get_wtime();
    #pragma omp parallel for //schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE ii = 0; ii < split_points_num; ++ii) {
        INDEX_TYPE start_row = split_points[ii];
        INDEX_TYPE end_row = split_points[ii + 1];
        for (INDEX_TYPE i = start_row; i < end_row; ++i) {
            //枚举列
            ELE_TYPE pivot = A(i, i); // diag value
            if (fabs(pivot) < 1e-8) pivot = pivot >= 0 ? 1e-8 : -1e-8;
            A(i, i) = pivot;
            for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; p++) {
                INDEX_TYPE j = Li[p]; //行号
                //printf("第%lld行消第%lld行\n", i + 1, j + 1);
                ELE_TYPE scale = A(j, i) / pivot;
                //L的列
                A(j, i) = scale;
                ELE_TYPE *pivot_row_ptr = &A(i, 0);
                ELE_TYPE *eli_row_ptr = &A(j, 0);
                for (INDEX_TYPE k = Up[i] + 1; k < Up[i + 1]; k++) {
                    INDEX_TYPE c = Ui[k];
                    eli_row_ptr[c] -= scale * pivot_row_ptr[c];
                    elimination_count++;
                }
            }
        }
    }
    LOG_TIME("分解 time: %f ms", (omp_get_wtime()-factor_time)*1000);
    LOG_DEBUG("消元次数为   ::::%lld\n", elimination_count);
    write_back_v2(Lp, Li, Lx, Up, Ui, Ux, D, n, offset);
    lu_free(offset);
    lu_free(D);
}
