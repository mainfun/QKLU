//
// Created by mainf on 2025/5/27.
//
#include <omp.h>
#include <base/matrix.h>
#include <math.h>
#include <numeric/SpGESSM.h>

//计算U12
void SpGESSM_v2(const CSC *L11, const CSC *A12, const CSC *U12) {
    const INDEX_TYPE *Lp = L11->col_ptr;
    const INDEX_TYPE *Li = L11->row_idx;
    const ELE_TYPE *Lx = L11->values;
    const INDEX_TYPE *Up = U12->col_ptr;
    const INDEX_TYPE *Ui = U12->row_idx;
    ELE_TYPE *Ux = U12->values;
    const INDEX_TYPE *Ap = A12->col_ptr;
    const INDEX_TYPE *Ai = A12->row_idx;
    const ELE_TYPE *Ax = A12->values;

    double factor_time = omp_get_wtime();
    long long fma_count = 0;

    #pragma omp parallel proc_bind(spread) //reduction(+:fma_count)
    {
        ELE_TYPE *dense_vec = (ELE_TYPE *) lu_calloc(A12->num_row, sizeof(ELE_TYPE));
        #pragma omp for schedule(static,1) //schedule(dynamic)
        for (INDEX_TYPE i = 0; i < A12->num_col; ++i) {
            // Scatter A(:,i) into dense_vec
            for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
                dense_vec[Ai[j]] = Ax[j];
            }
            for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; ++j) {
                INDEX_TYPE row = Ui[j]; //左看依赖列
                // printf("row=%ld, ",row);
                ELE_TYPE u = Ux[j] = dense_vec[row]; //u(row,i)
                // printf("j=%ld, ",j);
                dense_vec[row] = 0.0;
                if (u == 0.0) continue;
                // 当前列向量 -= u * 依赖列向量: dense_vec[c] -= l(i,col) * U(col,c)
                for (INDEX_TYPE k = Lp[row]; k < Lp[row + 1]; ++k) {
                    dense_vec[Li[k]] -= u * Lx[k];
                    fma_count++;
                }
            }
        }
        lu_free(dense_vec);
    }
    LOG_DEBUG("消元次数为   ::::%lld", fma_count);
    LOG_TIME("SpGESSM time: %f ms", (omp_get_wtime()-factor_time)*1000);
}
