//
// Created by mainf on 2025/3/23.
//

#ifndef MATRIX_UTIL_H
#define MATRIX_UTIL_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdlib.h>
#include "base/malloc.h"
#include "base/matrix.h"

/**
* 得到分块矩阵的CSR格式, 结果矩阵在函数内分配内存
* @param block_side 分块大小
* @param Ap 原矩阵 row_ptr
* @param Ai 原矩阵 col_idx
* @param n dim
* @param nnz 非零元数目
* @param Rp_ptr 分块结果矩阵的row_ptr地址
* @param Ri_ptr 分块结果矩阵的col_idx地址
* @return 分块结果矩阵的nnz
*/
INDEX_TYPE blocking(int block_side,
                    const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n, INDEX_TYPE nnz,
                    INDEX_TYPE **Rp_ptr, INDEX_TYPE **Ri_ptr);

/**
 *@param row_ptr_p 函数内分配内存
 *@param col_ind_p 函数内分配内存
 */
INDEX_TYPE dense2csr_struct(INDEX_TYPE num_row, INDEX_TYPE num_col, const int *dense,
                            INDEX_TYPE **row_ptr_p, INDEX_TYPE **col_ind_p);

/**
*@param row_ptr_p 函数内分配内存
*@param col_ind_p 函数内分配内存
*/
INDEX_TYPE dense2csr_struct_fp(INDEX_TYPE num_row, INDEX_TYPE num_col, const ELE_TYPE *dense,
                               INDEX_TYPE **row_ptr_p, INDEX_TYPE **col_ind_p);

INDEX_TYPE *get_diag_index_v2(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n);

int *get_diag_index_i(const int *Ap, const int *Ai, int n);

/**
 * @param col_pointers 初始化全0
 */
void csr2csc_pattern(const INDEX_TYPE *row_pointers, const INDEX_TYPE *col_indices,
                     INDEX_TYPE *col_pointers, INDEX_TYPE *row_indices,
                     INDEX_TYPE nnz, INDEX_TYPE n);

/**
 * @param col_pointers 初始化全0
 */
void csr2csc_pattern_int(const int *row_pointers, const int *col_indices,
                         int *col_pointers, int *row_indices,
                         long nnz, int n);

void csr2csc_pattern_v2(const int *row_pointers, const int *col_indices,
                        int *col_pointers, int *row_indices,
                        int nnz, int n);

void csr2csc(CSRMatrix *m, INDEX_TYPE **outAp,INDEX_TYPE **outAi, ELE_TYPE **outAx);

/* 计算两个一维置换 p, q 的乘积 r */
void multiply_perm(const INDEX_TYPE *p, const INDEX_TYPE *q, INDEX_TYPE *r, INDEX_TYPE n);

#ifdef __cplusplus
}
#endif
#endif //MATRIX_UTIL_H
