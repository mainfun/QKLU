//
// Created by mainf on 2025/3/23.
//

#include "matrix_util.h"

#include <assert.h>
#include <omp.h>
#include <stdint.h>

#include "base_math.h"
#include "matrix.h"


INDEX_TYPE dense2csr_struct(INDEX_TYPE num_row, INDEX_TYPE num_col, const int *dense,
                            INDEX_TYPE **row_ptr_p, INDEX_TYPE **col_ind_p) {
    if (dense == NULL || row_ptr_p == NULL || col_ind_p == NULL) {
        LOG_ERROR("dense == NULL || row_ptr == NULL || col_ind == NULL");
    }
    // 计算row_ptr数组
    *row_ptr_p = (INDEX_TYPE *) lu_malloc((num_row + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *row_ptr = *row_ptr_p;
    row_ptr[0] = 0;
    for (INDEX_TYPE i = 0; i < num_row; i++) {
        INDEX_TYPE count = 0;
        for (INDEX_TYPE j = 0; j < num_col; j++) {
            if (dense[i * num_col + j] != 0) {
                count++;
            }
        }
        row_ptr[i + 1] = row_ptr[i] + count;
    }

    INDEX_TYPE nnz = row_ptr[num_row];
    INDEX_TYPE current = 0;
    *col_ind_p = (INDEX_TYPE *) malloc(nnz * sizeof(INDEX_TYPE));
    INDEX_TYPE *col_ind = *col_ind_p;
    // 填充col_ind数组
    for (INDEX_TYPE i = 0; i < num_row; i++) {
        for (INDEX_TYPE j = 0; j < num_col; j++) {
            if (dense[i * num_col + j] != 0) {
                col_ind[current++] = j;
            }
        }
    }

    return nnz;
}

INDEX_TYPE dense2csr_struct_fp(INDEX_TYPE num_row, INDEX_TYPE num_col, const ELE_TYPE *dense,
                               INDEX_TYPE **row_ptr_p, INDEX_TYPE **col_ind_p) {
    if (dense == NULL || row_ptr_p == NULL || col_ind_p == NULL) {
        LOG_ERROR("dense == NULL || row_ptr == NULL || col_ind == NULL");
    }
    // 计算row_ptr数组
    *row_ptr_p = (INDEX_TYPE *) lu_malloc((num_row + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *row_ptr = *row_ptr_p;
    row_ptr[0] = 0;
    for (INDEX_TYPE i = 0; i < num_row; i++) {
        INDEX_TYPE count = 0;
        for (INDEX_TYPE j = 0; j < num_col; j++) {
            if (dense[i * num_col + j] != 0) {
                count++;
            }
        }
        row_ptr[i + 1] = row_ptr[i] + count;
    }

    INDEX_TYPE nnz = row_ptr[num_row];
    INDEX_TYPE current = 0;
    *col_ind_p = (INDEX_TYPE *) malloc(nnz * sizeof(INDEX_TYPE));
    INDEX_TYPE *col_ind = *col_ind_p;
    // 填充col_ind数组
    for (INDEX_TYPE i = 0; i < num_row; i++) {
        for (INDEX_TYPE j = 0; j < num_col; j++) {
            if (dense[i * num_col + j] != 0) {
                col_ind[current++] = j;
            }
        }
    }

    return nnz;
}

INDEX_TYPE blocking(int block_side,
                    const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n, INDEX_TYPE nnz,
                    INDEX_TYPE **Rp_ptr, INDEX_TYPE **Ri_ptr) {
    INDEX_TYPE num_col_block = CEIL_DIV(n, block_side);
    INDEX_TYPE num_row_block = CEIL_DIV(n, block_side);
    INDEX_TYPE block_height = block_side;
    INDEX_TYPE block_width = block_side;
    //生成稠密矩阵
    int *block_nnz_arr = (int *) lu_calloc(num_col_block * num_row_block, sizeof(int));
    for (INDEX_TYPE i = 0; i < n; ++i) {
        //i / block_height 是块的行号，Ai[j] / block_width是块的列号
        INDEX_TYPE block_row_ptr = (i / block_height) * num_col_block;
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            block_nnz_arr[block_row_ptr + Ai[j] / block_width]++;
        }
    }
    //稠密转CSR
    //todo 块小了block_nnz_arr会变大，dense2csr_struct性能会降低。
    INDEX_TYPE r_nnz = dense2csr_struct(num_col_block, num_col_block, block_nnz_arr, Rp_ptr, Ri_ptr);
    lu_free(block_nnz_arr);
    return r_nnz;
}

INDEX_TYPE blocking_v2(int block_side,
                       const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n, INDEX_TYPE nnz,
                       INDEX_TYPE **Rp_ptr, INDEX_TYPE **Ri_ptr) {
    // 计算分块参数
    const INDEX_TYPE num_col_block = CEIL_DIV(n, block_side);
    const INDEX_TYPE block_height = block_side;
    const INDEX_TYPE num_blocks = num_col_block * num_col_block; // 正方形分块

    // 使用位数组 (bitmap) 标记块存在性
    const size_t bitmap_size = (num_blocks + 7) / 8; // 按字节对齐
    uint8_t *block_bitmap = (uint8_t *) lu_calloc(bitmap_size, sizeof(uint8_t));

    // 预处理所有列的块号 (避免重复计算)
    int *block_col_cache = (int *) lu_malloc(nnz * sizeof(int));
    #pragma omp parallel for
    for (INDEX_TYPE j = 0; j < nnz; ++j) {
        block_col_cache[j] = Ai[j] / block_side;
    }

    // 并行标记块存在性
    #pragma omp parallel
    {
        // 每个线程维护本地bitmap以减少竞争
        uint8_t *local_bitmap = (uint8_t *) lu_calloc(bitmap_size, sizeof(uint8_t));

        #pragma omp for
        for (INDEX_TYPE i = 0; i < n; ++i) {
            const INDEX_TYPE block_row = i / block_height;
            const INDEX_TYPE row_offset = block_row * num_col_block;

            for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
                const INDEX_TYPE block_col = block_col_cache[j];
                const INDEX_TYPE pos = row_offset + block_col;

                // 设置本地bitmap的对应位
                local_bitmap[pos >> 3] |= (1U << (pos & 0x07));
            }
        }

        // 合并本地bitmap到全局
        #pragma omp critical
        {
            for (size_t k = 0; k < bitmap_size; ++k) {
                block_bitmap[k] |= local_bitmap[k];
            }
        }
        lu_free(local_bitmap);
    }

    // 生成CSR格式
    int *block_nnz_arr = (int *) lu_calloc(num_blocks, sizeof(int));
    for (INDEX_TYPE pos = 0; pos < num_blocks; ++pos) {
        if (block_bitmap[pos >> 3] & (1U << (pos & 0x07))) {
            block_nnz_arr[pos] = 1;
        }
    }
    INDEX_TYPE r_nnz = dense2csr_struct(num_col_block, num_col_block, block_nnz_arr, Rp_ptr, Ri_ptr);

    // 清理内存
    lu_free(block_col_cache);
    lu_free(block_bitmap);
    lu_free(block_nnz_arr);
    return r_nnz;
}

INDEX_TYPE blocking_v3(int block_side,
                       const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n, INDEX_TYPE nnz,
                       INDEX_TYPE **Rp_ptr, INDEX_TYPE **Ri_ptr) {
    // 计算分块参数
    const INDEX_TYPE num_col_block = CEIL_DIV(n, block_side);
    const INDEX_TYPE block_height = block_side;
    const INDEX_TYPE num_blocks = num_col_block * num_col_block; // 正方形分块

    // 使用位数组 (bitmap) 标记块存在性
    const size_t bitmap_size = (num_blocks + 7) / 8; // 按字节对齐
    uint8_t *block_bitmap = (uint8_t *) lu_calloc(bitmap_size, sizeof(uint8_t));

    // 预处理所有列的块号 (避免重复计算)
    INDEX_TYPE *block_col_cache = (INDEX_TYPE *) lu_malloc(nnz * sizeof(INDEX_TYPE));
    #pragma omp parallel for
    for (INDEX_TYPE j = 0; j < nnz; ++j) {
        block_col_cache[j] = Ai[j] / block_side;
    }

    // 并行标记块存在性
    #pragma omp parallel
    {
        // 每个线程维护本地bitmap以减少竞争
        uint8_t *local_bitmap = (uint8_t *) lu_calloc(bitmap_size, sizeof(uint8_t));

        #pragma omp for
        for (INDEX_TYPE i = 0; i < n; ++i) {
            const INDEX_TYPE block_row = i / block_height;
            const INDEX_TYPE row_offset = block_row * num_col_block;

            for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
                const INDEX_TYPE block_col = block_col_cache[j];
                const INDEX_TYPE pos = row_offset + block_col;

                // 设置本地bitmap的对应位
                local_bitmap[pos >> 3] |= (1U << (pos & 0x07));
            }
        }

        // 合并本地bitmap到全局
        #pragma omp critical
        {
            for (size_t k = 0; k < bitmap_size; ++k) {
                block_bitmap[k] |= local_bitmap[k];
            }
        }
        lu_free(local_bitmap);
    }

    // 高效生成CSR格式（跳过全零块遍历）
    // Step 1: 预计算非零块总数
    INDEX_TYPE r_nnz = 0;
    #pragma omp parallel for reduction(+:r_nnz)
    for (size_t byte_idx = 0; byte_idx < bitmap_size; ++byte_idx) {
        uint8_t byte = block_bitmap[byte_idx];
        r_nnz += __builtin_popcount(byte); // GCC内置函数统计1的位数
    }

    // Step 2: 直接生成CSR结构
    *Rp_ptr = (INDEX_TYPE *) lu_calloc(num_col_block + 1, sizeof(INDEX_TYPE));
    *Ri_ptr = (INDEX_TYPE *) lu_malloc(r_nnz * sizeof(INDEX_TYPE));

    INDEX_TYPE current_nnz = 0;
    for (INDEX_TYPE block_row = 0; block_row < num_col_block; ++block_row) {
        (*Rp_ptr)[block_row + 1] = (*Rp_ptr)[block_row];
        const INDEX_TYPE byte_start = (block_row * num_col_block) >> 3;
        const INDEX_TYPE bit_start = (block_row * num_col_block) & 0x07;

        // 按行扫描位图
        for (INDEX_TYPE rel_col = 0; rel_col < num_col_block;) {
            const size_t byte_idx = byte_start + ((bit_start + rel_col) >> 3);
            const uint8_t byte = block_bitmap[byte_idx];
            if (byte == 0) { // 快速跳过全零字节
                rel_col += 8 - ((bit_start + rel_col) & 0x07);
                continue;
            }

            // 提取有效位
            const uint8_t mask = 0xFFU >> ((bit_start + rel_col) & 0x07);
            const uint8_t valid_bits = byte & mask;
            if (valid_bits == 0) {
                rel_col += 8 - ((bit_start + rel_col) & 0x07);
                continue;
            }

            // 处理单个位
            const INDEX_TYPE base_col = rel_col + block_row * num_col_block;
            if (valid_bits & (1U << (rel_col & 0x07))) {
                (*Ri_ptr)[current_nnz++] = base_col / num_col_block; // 列号
                (*Rp_ptr)[block_row + 1]++;
                rel_col++;
            } else {
                rel_col++;
            }
        }
    }

    // 清理内存
    lu_free(block_col_cache);
    lu_free(block_bitmap);
    return r_nnz;
}

INDEX_TYPE binary_search_l(const INDEX_TYPE *array, INDEX_TYPE start, INDEX_TYPE end, INDEX_TYPE target) {
    INDEX_TYPE mid;
    while (start <= end) {
        mid = start + (end - start) / 2;
        if (array[mid] == target)
            return mid;
        else if (array[mid] < target)
            start = mid + 1;
        else
            end = mid - 1;
    }
    LOG_ERROR("without diag element!");
    return -1; // 表示未找到
}

int binary_search_i(const int *array, int start, int end, int target) {
    int mid;
    while (start <= end) {
        mid = start + (end - start) / 2;
        if (array[mid] == target)
            return mid;
        else if (array[mid] < target)
            start = mid + 1;
        else
            end = mid - 1;
    }
    LOG_ERROR("without diag element!");
}

///求对角元素索引
INDEX_TYPE *get_diag_index_v2(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n) {
    INDEX_TYPE *diag_index = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    //#pragma omp parallel for
    for (INDEX_TYPE i = 0; i < n; i++) {
        diag_index[i] = binary_search_l(Ai, Ap[i], Ap[i + 1] - 1, i);
    }
    return diag_index;
}

///求对角元素索引
int *get_diag_index_i(const int *Ap, const int *Ai, int n) {
    int *diag_index = (int *) lu_malloc(n * sizeof(int));
    //#pragma omp parallel for
    for (int i = 0; i < n; i++) {
        diag_index[i] = binary_search_i(Ai, Ap[i], Ap[i + 1] - 1, i);
    }
    return diag_index;
}

void csr2csc(CSRMatrix *m, INDEX_TYPE **outAp,INDEX_TYPE **outAi, ELE_TYPE **outAx) {
    double time = omp_get_wtime();
    // 初始化
    INDEX_TYPE *Ap = (INDEX_TYPE *) lu_calloc(m->num_row + 1, sizeof(INDEX_TYPE));
    INDEX_TYPE *Ai = (INDEX_TYPE *) lu_malloc(m->nnz * sizeof(INDEX_TYPE));
    ELE_TYPE *Ax = (ELE_TYPE *) lu_malloc(m->nnz * sizeof(ELE_TYPE));
    // 计算每列的非零元素个数
    for (INDEX_TYPE i = 0; i < m->nnz; i++) {
        Ap[m->col_indices[i] + 1]++;
    }
    // 转换为列指针的累加形式
    for (INDEX_TYPE i = 0; i < m->num_col; i++) {
        Ap[i + 1] += Ap[i];
    }
    for (INDEX_TYPE i = 0; i < m->num_row; i++) {
        for (INDEX_TYPE j = m->row_pointers[i]; j < m->row_pointers[i + 1]; j++) {
            INDEX_TYPE col = m->col_indices[j];
            INDEX_TYPE dst = Ap[col];
            ELE_TYPE v = m->csr_values[j];
            Ai[dst] = i;
            Ax[dst] = v;
            Ap[col]++;
        }
    }
    // 修正列指针
    for (INDEX_TYPE i = m->num_col; i > 0; i--) {
        Ap[i] = Ap[i - 1];
    }
    Ap[0] = 0;
    *outAp = Ap;
    *outAi = Ai;
    *outAx = Ax;
    LOG_TIME("csr2csc time:%lf ms", 1000*(omp_get_wtime()-time));
}


void csr2csc_pattern(const INDEX_TYPE *row_pointers, const INDEX_TYPE *col_indices,
                     INDEX_TYPE *col_pointers, INDEX_TYPE *row_indices,
                     INDEX_TYPE nnz, INDEX_TYPE n) {
    // 计算每列的非零元素个数
    for (INDEX_TYPE i = 0; i < nnz; i++) {
        INDEX_TYPE idx = col_indices[i];
        col_pointers[idx + 1]++;
    }
    // 转换为列指针的累加形式
    for (INDEX_TYPE i = 0; i < n; i++) {
        col_pointers[i + 1] += col_pointers[i];
    }
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = row_pointers[i]; j < row_pointers[i + 1]; j++) {
            INDEX_TYPE col = col_indices[j];
            INDEX_TYPE dst = col_pointers[col];
            if(dst >= nnz) {
                LOG_ERROR("dst >= nnz");
            }
            // printf("(col,dst)=(%lld,%lld),", col, dst);
            row_indices[dst] = i;
            col_pointers[col]++;
        }
    }
    // 修正列指针
    for (INDEX_TYPE i = n; i > 0; i--) {
        col_pointers[i] = col_pointers[i - 1];
    }
    col_pointers[0] = 0;
}

void csr2csc_pattern_int(const int *row_pointers, const int *col_indices,
                         int *col_pointers, int *row_indices,
                         long nnz, int n) {
    // 计算每列的非零元素个数
    for (int i = 0; i < nnz; i++) {
        col_pointers[col_indices[i] + 1]++;
    }
    // 转换为列指针的累加形式
    for (int i = 0; i < n; i++) {
        col_pointers[i + 1] += col_pointers[i];
    }
    for (int i = 0; i < n; i++) {
        for (int j = row_pointers[i]; j < row_pointers[i + 1]; j++) {
            int col = col_indices[j];
            int dst = col_pointers[col];
            row_indices[dst] = i;
            col_pointers[col]++;
        }
    }
    // 修正列指针
    for (int i = n; i > 0; i--) {
        col_pointers[i] = col_pointers[i - 1];
    }
    col_pointers[0] = 0;
}

void csc2csr_pattern_v2(int *row_pointers, int *col_indices,
                        const int *col_pointers, const int *row_indices,
                        int nnz, int n) {
    // 计算每列的非零元素个数
    for (int i = 0; i < nnz; i++) {
        row_pointers[row_indices[i] + 1]++;
    }
    // 转换为累加形式
    for (int i = 0; i < n; i++) {
        row_pointers[i + 1] += row_pointers[i];
    }
    for (int i = 0; i < n; i++) {
        for (int j = col_pointers[i]; j < col_pointers[i + 1]; j++) {
            int col = row_indices[j];
            int dst = row_pointers[col];
            col_indices[dst] = i;
            row_pointers[col]++;
        }
    }
    // 修正列指针
    for (int i = n; i > 0; i--) {
        row_pointers[i] = row_pointers[i - 1];
    }
    row_pointers[0] = 0;
}

/* 计算两个一维置换 p, q 的乘积 r */
void multiply_perm(const INDEX_TYPE *p, const INDEX_TYPE *q, INDEX_TYPE *r, INDEX_TYPE n) {
    for (INDEX_TYPE i = 0; i < n; i++)
        r[i] = q[p[i]];
}
