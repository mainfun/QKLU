//
// Created by mainf on 2024/9/15.
//
#ifndef QiankunLU_MATRIX_H
#define QiankunLU_MATRIX_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdbool.h>
#include <stdlib.h>
#include "malloc.h"
#include "log.h"

#define ELE_TYPE double
#define INDEX_TYPE long long
#define USE_INDEX_LONGLONG

// #define USE_INDEX_INT
// #define INDEX_TYPE int

#if defined(USE_INDEX_LONGLONG)
#define INDEX_FMT "%lld"
#elif defined(USE_INDEX_INT)
    #define INDEX_FMT "%d"
#else
#error "You must define either USE_INDEX_LONGLONG or USE_INDEX_INT"
#endif
// #define INDEX_TYPE unsigned long int

typedef struct CSR_MATRIX {
    INDEX_TYPE num_row; // 矩阵的行数量
    INDEX_TYPE num_col; // 矩阵的列数量
    INDEX_TYPE nnz; // 非零元素的总数
    /**CSR**/
    INDEX_TYPE *row_pointers; // 每行的起始索引
    INDEX_TYPE *col_indices; // 非零元素对应的列索引
    ELE_TYPE *csr_values; // 矩阵非零元素的值
} CSRMatrix;

typedef struct CSC_MATRIX {
    INDEX_TYPE num_row; // 矩阵的行数量
    INDEX_TYPE num_col; // 矩阵的列数量
    INDEX_TYPE nnz;
    /**CSR**/
    INDEX_TYPE *col_ptr;
    INDEX_TYPE *row_idx;
    ELE_TYPE *values;
} CSC;

void free_csc3(CSC *matrix);

void malloc_csc(CSC *matrix, INDEX_TYPE num_row, INDEX_TYPE num_col, INDEX_TYPE nnz);

/**
 * 初始化
 * @param num_row 行个数=列大小=矩阵高
 * @param num_col 列个数=行大小=矩阵宽
 * @param nnz 非零元个数
 * @return CSRMatrix
 */
CSRMatrix *init_csr_matrix(INDEX_TYPE num_row, INDEX_TYPE num_col, INDEX_TYPE nnz);

void free_csr_matrix(CSRMatrix *matrix);

///只是free里面的指针
void free_csr_matrix_ptr(CSRMatrix *matrix);

void print_matrix_csr(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n);

void print_matrix_csc(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n);

ELE_TYPE *csc2dense_v2(const INDEX_TYPE *Ap_start, const INDEX_TYPE *Ap_end,
                       const INDEX_TYPE *Ai, const ELE_TYPE *Ax, INDEX_TYPE n);

ELE_TYPE *csr2dense_v2(const INDEX_TYPE *Ap_start, const INDEX_TYPE *Ap_end,
                       const INDEX_TYPE *Ai, const ELE_TYPE *Ax, INDEX_TYPE n);

void print_dense_matrix(ELE_TYPE *A, INDEX_TYPE n);

void print_dense_matrix2(ELE_TYPE *A, INDEX_TYPE num_row,INDEX_TYPE num_col);

ELE_TYPE *csc2dense(const CSC *A);

void print_csc(CSC *A);

void print_csc3(INDEX_TYPE M,INDEX_TYPE N,INDEX_TYPE *Ap,INDEX_TYPE *Ai,ELE_TYPE *Ax);

ELE_TYPE *csr2dense(const CSRMatrix *A);

/**
 * A是CSR格式，Ax=y
 * @param A SparseMatrix
 * @param x ELE_TYPE
 * @param y ELE_TYPE
 */
void SpMV_csr(const CSRMatrix *A, const ELE_TYPE *x, ELE_TYPE *y);

void SpMV_csc(const CSC *A, const ELE_TYPE *x, ELE_TYPE *y);

/**
* @brief calc A'+A-E. 注意：结果是无序的
* @param[in]  n A n
* @param[in]  nz A nnz
* @param[in]  col_ptr A column pointer
* @param[in]  row_idx A row indices
* @param[out] bnz A'+A nnz
* @param[out] b_col_ptr A'+A column pointer
* @param[out] b_row_ind A'+A row indices
**/
void a_plus_at(INDEX_TYPE n, INDEX_TYPE nz,
               const INDEX_TYPE *col_ptr, const INDEX_TYPE *row_idx,
               INDEX_TYPE *bnz, INDEX_TYPE **b_col_ptr, INDEX_TYPE **b_row_ind);
#ifdef __cplusplus
}
#endif
#endif //QiankunLU_MATRIX_H
