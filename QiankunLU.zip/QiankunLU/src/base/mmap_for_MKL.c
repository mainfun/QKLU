#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <omp.h>
#include "log.h"
#include "malloc.h"
#include "base/mmap_for_MKL.h"

static const char *start, *ptr, *end_ptr;

// Skip only whitespace (not comments)
static inline void skip_ws(const char **pp) {
    const char *p = *pp;
    while (p < end_ptr && isspace((unsigned char)*p)) ++p;
    *pp = p;
}

// Skip whitespace and comment lines (single '%')
static inline void skip_comments(const char **pp) {
    const char *p = *pp;
    while (p < end_ptr) {
        while (p < end_ptr && isspace((unsigned char)*p)) p++;
        if (p < end_ptr && *p == '%') {
            while (p < end_ptr && *p != '\n') ++p;
            if (p < end_ptr && *p == '\n') ++p;
        } else {
            break;
        }
    }
    *pp = p;
}

// Debug function: prINDEX_TYPE current line poINDEX_TYPEed to by ptr
// static inline void debug_prINDEX_TYPE_line(const char *p) {
//     const char *line_end = p;
//     while (line_end < end_ptr && *line_end != '\n') ++line_end;
//     fwrite(p, 1, line_end - p, stdout);
//     fputc('\n', stdout);
// }

// C = A + A^T，其中A是三角矩阵
void add_transpose_for_sym_csc(INDEX_TYPE **outAp, INDEX_TYPE **outAi, ELE_TYPE **outAx, INDEX_TYPE n,
                               INDEX_TYPE *nnz_ptr) {
    INDEX_TYPE *Ap = *outAp;
    INDEX_TYPE *Ai = *outAi;
    ELE_TYPE *Ax = *outAx;
    INDEX_TYPE nnz = *nnz_ptr;

    INDEX_TYPE *u_col_nnz = (INDEX_TYPE *) lu_calloc(n + 1, sizeof(INDEX_TYPE)); // 每行的非零元素计数
    //计算上三角（非对角）列个数
    for (INDEX_TYPE i = 0; i < n; ++i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; j++) {
            const INDEX_TYPE idx = Ai[j];
            if (idx != i) u_col_nnz[idx + 1]++;
        }
    }

    INDEX_TYPE *new_Ap = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    // 计算new_Ap
    for (INDEX_TYPE i = 1; i <= n; i++) {
        u_col_nnz[i] += u_col_nnz[i - 1];
        new_Ap[i] = Ap[i] + u_col_nnz[i];
    }
    new_Ap[0] = 0;

    INDEX_TYPE new_nnz = nnz + u_col_nnz[n];
    INDEX_TYPE *new_Ai = (INDEX_TYPE *) lu_malloc(new_nnz * sizeof(INDEX_TYPE));
    ELE_TYPE *new_Ax = (ELE_TYPE *) lu_malloc(new_nnz * sizeof(ELE_TYPE));

    //---------------------------------------------------------------
    //添加另一半
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; j++) {
            INDEX_TYPE idx = Ai[j];
            ELE_TYPE val = Ax[j];
            // 添加A(col, i)
            new_Ai[new_Ap[idx]] = i;
            new_Ax[new_Ap[idx]] = val;
            new_Ap[idx]++;
        }
    }
    // 遍历A的每一列
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; j++) {
            INDEX_TYPE idx = Ai[j];
            ELE_TYPE val = Ax[j];
            // 添加A(i, col)
            if (i != idx) {
                new_Ai[new_Ap[i]] = idx;
                new_Ax[new_Ap[i]] = val;
                new_Ap[i]++;
            }
        }
    }
    // 更新C的row_ptr
    for (INDEX_TYPE i = n; i > 0; i--) {
        new_Ap[i] = new_Ap[i - 1];
    }
    new_Ap[0] = 0;
    lu_free(Ap);
    lu_free(Ai);
    lu_free(Ax);
    lu_free(u_col_nnz);
    *outAp = new_Ap;
    *outAi = new_Ai;
    *outAx = new_Ax;
    *nnz_ptr = new_nnz;
}


void read_mtx_csc(const char *filename,
                  INDEX_TYPE *M, INDEX_TYPE *N, INDEX_TYPE *nnz,
                  INDEX_TYPE **col_ptr_out, INDEX_TYPE **row_idx_out, ELE_TYPE **val_out) {
    ELE_TYPE time = omp_get_wtime();
    int fd = open(filename, O_RDONLY);
    if (fd < 0)
        LOG_ERROR("文件打开失败，可能是因为文件不存在");
    struct stat st;
    if (fstat(fd, &st) < 0) {
        close(fd);
        LOG_ERROR("fstat错误，可能是文件权限不足");
    }
    size_t size = st.st_size;
    start = mmap(NULL, size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (start == MAP_FAILED)
        LOG_ERROR("mmap错误");;
    ptr = start;
    end_ptr = start + size;

    // 1) Parse header line via sscanf and %n
    MtxInfo info;
    INDEX_TYPE hdr_n = 0;
    if (sscanf(ptr, "%%%%MatrixMarket %s %s %s %s%n",
               info.object, info.format, info.field, info.symmetry, &hdr_n) != 4) {
        munmap((void *) start, size);
        LOG_ERROR("mtx file header does not contain enough information");
    }
    LOG_DEBUG("%%%% %s %s %s %s", info.object, info.format, info.field, info.symmetry);
    if (strcmp(info.format, "coordinate") != 0) {
        LOG_ERROR("matrix in mtx file not is sparse");
    }
    if (strcmp(info.field, "complex") == 0) {
        LOG_ERROR("not support complex");
    }

    ptr += hdr_n;
    // After banner, skip comments
    skip_comments(&ptr);

    // Read M, N, nnz using strtol
    char *next;
    INDEX_TYPE tmp;
    tmp = strtol(ptr, &next, 10);
    ptr = next;
    skip_ws(&ptr);
    *M = (INDEX_TYPE) tmp;
    tmp = strtol(ptr, &next, 10);
    ptr = next;
    skip_ws(&ptr);
    *N = (INDEX_TYPE) tmp;
    tmp = strtol(ptr, &next, 10);
    ptr = next;
    skip_ws(&ptr);
    *nnz = (INDEX_TYPE) tmp;
    INDEX_TYPE nz = *nnz;
    LOG_DEBUG("%lld x %lld, nnz=%lld", *M, *N, nz);

    INDEX_TYPE *I = lu_malloc(nz * sizeof(INDEX_TYPE));
    INDEX_TYPE *J = lu_malloc(nz * sizeof(INDEX_TYPE));
    ELE_TYPE *V = lu_malloc(nz * sizeof(ELE_TYPE));

    // Read entries
    for (INDEX_TYPE k = 0; k < nz; ++k) {
        skip_ws(&ptr);
        tmp = strtol(ptr, &next, 10);
        I[k] = (INDEX_TYPE) tmp - 1; //to 0-based
        ptr = next;

        skip_ws(&ptr);
        tmp = strtol(ptr, &next, 10);
        J[k] = (INDEX_TYPE) tmp - 1;
        ptr = next;

        skip_ws(&ptr);
        ELE_TYPE dv = strtod(ptr, &next);
        V[k] = dv;
        ptr = next;
    }
    LOG_TIME("mmap coo time:%f s", omp_get_wtime()-time);
    // Build CSC
    INDEX_TYPE *col_ptr = lu_calloc((*N + 1), sizeof(INDEX_TYPE));
    INDEX_TYPE *row_idx = lu_malloc(nz * sizeof(INDEX_TYPE));
    ELE_TYPE *val = lu_malloc(nz * sizeof(ELE_TYPE));

    for (INDEX_TYPE k = 0; k < nz; ++k)
        col_ptr[J[k] + 1]++;
    for (INDEX_TYPE j = 0; j < *N; ++j)
        col_ptr[j + 1] += col_ptr[j];

    INDEX_TYPE *col_next = lu_malloc((*N) * sizeof(INDEX_TYPE));
    memcpy(col_next, col_ptr, (*N) * sizeof(INDEX_TYPE));

    for (INDEX_TYPE k = 0; k < nz; ++k) {
        INDEX_TYPE c = J[k];
        INDEX_TYPE idx = col_next[c]++;
        row_idx[idx] = I[k];
        val[idx] = V[k];
    }

    free(I);
    free(J);
    free(V);
    free(col_next);
    munmap((void *) start, size);

    if (strcmp(info.symmetry, "symmetric") == 0) {
        LOG_DEBUG("A+AT excluding diagonal");
        add_transpose_for_sym_csc(&col_ptr, &row_idx, &val, *M, nnz);
    }

    *col_ptr_out = col_ptr;
    *row_idx_out = row_idx;
    *val_out = val;
    LOG_TIME("mmap read the file in a total of %f s", omp_get_wtime()-time);
}