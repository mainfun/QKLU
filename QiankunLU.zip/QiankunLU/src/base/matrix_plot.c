//
// Created by mainf on 2025/3/24.
//

#include <stdio.h>
#include <jpeglib.h>
#include <math.h>
#include <stdlib.h>

#include "matrix_plot.h"

#include <preprocess/symbolic_analysis.h>

#include "base_math.h"
#include "log.h"
#include "matrix.h"
#include "matrix_util.h"

void plot_LU(CSRMatrix *csr, const char *filename, double time) {
    INDEX_TYPE *Ap = csr->row_pointers;
    INDEX_TYPE *Ai = csr->col_indices;
    INDEX_TYPE n = csr->num_col;
    INDEX_TYPE nnz = csr->nnz;
    INDEX_TYPE big_num = (INDEX_TYPE) 1e6;
    //前面的计算时间长，则符号计算的时间可能会很长
    if (time > 30) {
        LOG_DEBUG("plot_LU 近似计算");
        int block_side = 20;
        INDEX_TYPE r_n = CEIL_DIV(n, block_side);
        INDEX_TYPE *block_ap;
        INDEX_TYPE *block_ai;
        INDEX_TYPE r_nnz = blocking(block_side, Ap, Ai, n, nnz, &block_ap, &block_ai);
        PreprocessInfo *info = init_preprocess_info();
        symbolic_analysis(block_ap, block_ai, r_n, r_nnz, info);
        csr2image_gray(info->pattern, filename, 3000, 3000);
        free_preprocess_info(info);
        lu_free(block_ap);
        lu_free(block_ai);
    } else {
        PreprocessInfo *info = init_preprocess_info();
        symbolic_analysis(Ap, Ai, n, nnz, info);
        csr2image_RGB(info->pattern, filename, 3000, 3000);
        free_preprocess_info(info);
    }
}

void csr2image_gray(const CSRMatrix *matrix, const char *filename, int img_width, int img_height) {
    if (matrix == NULL)
        LOG_ERROR("matrix is NULL");

    // 确保图像尺寸有效
    img_width = (img_width <= 0) ? 1 : img_width;
    img_height = (img_height <= 0) ? 1 : img_height;

    // 调整图像尺寸不超过矩阵尺寸
    img_width = (img_width > matrix->num_col) ? matrix->num_col : img_width;
    img_height = (img_height > matrix->num_row) ? matrix->num_row : img_height;

    // 计算行/列到图像块的映射
    INDEX_TYPE *row_mapping = malloc(matrix->num_row * sizeof(INDEX_TYPE));
    INDEX_TYPE *col_mapping = malloc(matrix->num_col * sizeof(INDEX_TYPE));

    // 生成行映射（均匀分布余数）
    for (INDEX_TYPE r = 0; r < matrix->num_row; r++) {
        row_mapping[r] = (r * img_height) / matrix->num_row;
    }

    // 生成列映射（均匀分布余数）
    for (INDEX_TYPE c = 0; c < matrix->num_col; c++) {
        col_mapping[c] = (c * img_width) / matrix->num_col;
    }

    // 初始化图像缓冲区
    unsigned char *image_buffer = calloc(img_width * img_height, sizeof(unsigned char));
    if (!image_buffer) {
        LOG_ERROR("Memory allocation failed");
    }

    // 统计每个块的非零元素计数
    int *counts = calloc(img_width * img_height, sizeof(int));

    // 遍历所有非零元素
    for (INDEX_TYPE row = 0; row < matrix->num_row; ++row) {
        const INDEX_TYPE y_block = row_mapping[row];

        for (INDEX_TYPE idx = matrix->row_pointers[row];
             idx < matrix->row_pointers[row + 1]; ++idx) {
            const INDEX_TYPE col = matrix->col_indices[idx];
            const INDEX_TYPE x_block = col_mapping[col];

            if (y_block < img_height && x_block < img_width) {
                counts[y_block * img_width + x_block]++;
            }
        }
    }

    // 计算最终像素值
    for (int b = 0; b < img_height * img_width; ++b) {
        // 计算当前块的面积
        const int y_block = b / img_width;
        const int x_block = b % img_width;

        const INDEX_TYPE rows = ((y_block + 1) * matrix->num_row) / img_height -
                                (y_block * matrix->num_row) / img_height;
        const INDEX_TYPE cols = ((x_block + 1) * matrix->num_col) / img_width -
                                (x_block * matrix->num_col) / img_width;
        const INDEX_TYPE area = rows * cols;

        // 计算密度并设置像素值
        image_buffer[b] = (counts[b] > 0) ? 0 : 255;
    }

    // JPEG压缩部分（保持原样）
    struct jpeg_compress_struct cinfo;
    struct jpeg_error_mgr jerr;

    FILE *outfile = fopen(filename, "wb");
    if (!outfile) {
        LOG_ERROR("Can't open %s for writing\n", filename);
    }

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_compress(&cinfo);
    jpeg_stdio_dest(&cinfo, outfile);

    cinfo.image_width = img_width;
    cinfo.image_height = img_height;
    cinfo.input_components = 1;
    cinfo.in_color_space = JCS_GRAYSCALE;

    jpeg_set_defaults(&cinfo);
    jpeg_set_quality(&cinfo, 100, TRUE);
    jpeg_start_compress(&cinfo, TRUE);

    JSAMPROW row_pointer[1];
    while (cinfo.next_scanline < cinfo.image_height) {
        row_pointer[0] = &image_buffer[cinfo.next_scanline * img_width];
        jpeg_write_scanlines(&cinfo, row_pointer, 1);
    }

    // 清理资源
    free(row_mapping);
    free(col_mapping);
    free(counts);
    free(image_buffer);

    jpeg_finish_compress(&cinfo);
    fclose(outfile);
    jpeg_destroy_compress(&cinfo);
}

void csr2image_RGB(const CSRMatrix *matrix, const char *filename, int img_width, int img_height) {
    if (matrix == NULL)
        LOG_ERROR("matrix is NULL");

    // 确保图像尺寸有效
    img_width = (img_width <= 0) ? 1 : img_width;
    img_height = (img_height <= 0) ? 1 : img_height;

    // 调整图像尺寸不超过矩阵尺寸
    img_width = (img_width > matrix->num_col) ? (int) matrix->num_col : img_width;
    img_height = (img_height > matrix->num_row) ? (int) matrix->num_row : img_height;

    // 计算行/列到图像块的映射
    INDEX_TYPE *row_mapping = malloc(matrix->num_row * sizeof(INDEX_TYPE));
    INDEX_TYPE *col_mapping = malloc(matrix->num_col * sizeof(INDEX_TYPE));

    // 生成行映射（均匀分布余数）
    for (INDEX_TYPE r = 0; r < matrix->num_row; r++) {
        row_mapping[r] = (r * img_height) / matrix->num_row;
    }

    // 生成列映射（均匀分布余数）
    for (INDEX_TYPE c = 0; c < matrix->num_col; c++) {
        col_mapping[c] = (c * img_width) / matrix->num_col;
    }

    // 初始化RGB图像缓冲区（每个像素3字节）
    unsigned char *image_buffer = calloc(3 * img_width * img_height, sizeof(unsigned char));
    if (!image_buffer) {
        LOG_ERROR("Memory allocation failed");
    }

    // 统计每个块的非零元素计数
    int *counts = calloc(img_width * img_height, sizeof(int));

    // 遍历所有非零元素
    for (INDEX_TYPE row = 0; row < matrix->num_row; ++row) {
        const INDEX_TYPE y_block = row_mapping[row];

        for (INDEX_TYPE idx = matrix->row_pointers[row];
             idx < matrix->row_pointers[row + 1]; ++idx) {
            const INDEX_TYPE col = matrix->col_indices[idx];
            const INDEX_TYPE x_block = col_mapping[col];

            if (y_block < img_height && x_block < img_width) {
                counts[y_block * img_width + x_block]++;
            }
        }
    }

    // 计算最终像素颜色
    for (int b = 0; b < img_height * img_width; ++b) {
        const int y_block = b / img_width;
        const int x_block = b % img_width;

        // 计算当前块的面积
        const INDEX_TYPE rows = ((y_block + 1) * matrix->num_row) / img_height -
                                (y_block * matrix->num_row) / img_height;
        const INDEX_TYPE cols = ((x_block + 1) * matrix->num_col) / img_width -
                                (x_block * matrix->num_col) / img_width;
        const INDEX_TYPE area = rows * cols;

        // 计算密度
        double density = area > 0 ? (double) counts[b] / (double) area : 0.0;

        // 设置RGB颜色
        unsigned char *pixel = &image_buffer[3 * b];
        if (density == 0) {
            //白色
            pixel[0] = 255;
            pixel[1] = 255;
            pixel[2] = 255;
        } else if (density < 0.05) {
            // 冷
            pixel[0] = 30;
            pixel[1] = 70;
            pixel[2] = 110;
        } else if (density < 0.3) {
            //冷
            pixel[0] = 055;
            pixel[1] = 103;
            pixel[2] = 149;
        } else if (density < 0.6) {
            // 暖
            pixel[0] = 255;
            pixel[1] = 208;
            pixel[2] = 111;
        }else {
            // 暖
            pixel[0] = 231;
            pixel[1] = 98;
            pixel[2] = 84;
        }
    }

    // JPEG压缩部分
    struct jpeg_compress_struct cinfo;
    struct jpeg_error_mgr jerr;

    FILE *outfile = fopen(filename, "wb");
    if (!outfile) {
        LOG_ERROR("Can't open %s for writing\n", filename);
    }

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_compress(&cinfo);
    jpeg_stdio_dest(&cinfo, outfile);

    // 设置RGB颜色空间
    cinfo.image_width = img_width;
    cinfo.image_height = img_height;
    cinfo.input_components = 3;
    cinfo.in_color_space = JCS_RGB;

    jpeg_set_defaults(&cinfo);
    jpeg_set_quality(&cinfo, 100, TRUE);
    jpeg_start_compress(&cinfo, TRUE);

    JSAMPROW row_pointer[1];
    const int row_stride = img_width * 3; // 每行字节数 = 宽度 * 3个分量
    while (cinfo.next_scanline < cinfo.image_height) {
        row_pointer[0] = &image_buffer[cinfo.next_scanline * row_stride];
        jpeg_write_scanlines(&cinfo, row_pointer, 1);
    }

    // 清理资源
    free(row_mapping);
    free(col_mapping);
    free(counts);
    free(image_buffer);

    jpeg_finish_compress(&cinfo);
    fclose(outfile);
    jpeg_destroy_compress(&cinfo);
}


void csr2image_block_cut(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                         const char *filename,
                         INDEX_TYPE row_start, INDEX_TYPE row_end,
                         INDEX_TYPE col_start, INDEX_TYPE col_end,
                         const INDEX_TYPE *cut_points, INDEX_TYPE cut_points_count) {
    struct jpeg_compress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE *outfile = fopen(filename, "wb");
    if (!outfile) {
        fprintf(stderr, "Can't open %s for writing\n", filename);
        return;
    }

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_compress(&cinfo);
    jpeg_stdio_dest(&cinfo, outfile);

    INDEX_TYPE img_width = row_end - row_start;
    INDEX_TYPE img_height = col_end - col_start;
    cinfo.image_width = img_width;
    cinfo.image_height = img_height;
    cinfo.input_components = 3; // RGB
    cinfo.in_color_space = JCS_RGB;

    // Set the compression mode to "lossless"
    cinfo.raw_data_in = TRUE; // Enable raw data for lossless compression
    cinfo.optimize_coding = TRUE; // Optimize coding for lossless compression

    jpeg_set_defaults(&cinfo);
    jpeg_set_quality(&cinfo, 100, TRUE);
    jpeg_start_compress(&cinfo, TRUE);

    // Allocate memory for the RGB image
    unsigned char *image_buffer = calloc(img_width * img_height * 3, sizeof(unsigned char));
    if (!image_buffer) {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }

    // Initialize the image with white pixels
    for (int i = 0; i < img_width * img_height; i++) {
        image_buffer[i * 3 + 0] = 255; // Red channel
        image_buffer[i * 3 + 1] = 255; // Green channel
        image_buffer[i * 3 + 2] = 255; // Blue channel
    }

    // Calculate pixel values and add red lines for cut_points
    INDEX_TYPE pixel_index = 0;
    int found;
    for (INDEX_TYPE i = row_start; i < row_end; i++) {
        for (INDEX_TYPE j = col_start; j < col_end; j++) {
            found = 0;
            for (INDEX_TYPE p = Ap[i]; p < Ap[i + 1]; p++) {
                INDEX_TYPE col_index = Ai[p];
                if (col_index == j) {
                    found = 1;
                    image_buffer[pixel_index * 3 + 0] = 0; // Set red to 0
                    image_buffer[pixel_index * 3 + 1] = 0; // Set green to 0
                    image_buffer[pixel_index * 3 + 2] = 0; // Set blue to 0
                    break;
                }
            }
            if (!found) {
                image_buffer[pixel_index * 3 + 0] = 255; // Red channel
                image_buffer[pixel_index * 3 + 1] = 255; // Green channel
                image_buffer[pixel_index * 3 + 2] = 255; // Blue channel
            }
            pixel_index++;
        }
    }

    // Draw red lines at cut_points
    for (int i = 0; i < cut_points_count; i++) {
        INDEX_TYPE cut_point = cut_points[i];

        // Draw red line horizontally (at cut_point-th row)
        if (cut_point >= row_start && cut_point < row_end) {
            for (INDEX_TYPE j = col_start; j < col_end; j++) {
                INDEX_TYPE pixel_idx = (cut_point - row_start) * img_width + (j - col_start);
                image_buffer[pixel_idx * 3 + 0] = 255; // Red
                image_buffer[pixel_idx * 3 + 1] = 0; // Green
                image_buffer[pixel_idx * 3 + 2] = 0; // Blue
            }
        }

        // Draw red line vertically (at cut_point-th column)
        if (cut_point >= col_start && cut_point < col_end) {
            for (INDEX_TYPE i = row_start; i < row_end; i++) {
                INDEX_TYPE pixel_idx = (i - row_start) * img_width + (cut_point - col_start);
                image_buffer[pixel_idx * 3 + 0] = 255; // Red
                image_buffer[pixel_idx * 3 + 1] = 0; // Green
                image_buffer[pixel_idx * 3 + 2] = 0; // Blue
            }
        }
    }

    // Write image to the file
    JSAMPROW row_pointer[1];
    while (cinfo.next_scanline < cinfo.image_height) {
        row_pointer[0] = &image_buffer[cinfo.next_scanline * img_width * 3];
        jpeg_write_scanlines(&cinfo, row_pointer, 1);
    }

    // Clean up
    free(image_buffer);
    jpeg_finish_compress(&cinfo);
    fclose(outfile);
    jpeg_destroy_compress(&cinfo);
}