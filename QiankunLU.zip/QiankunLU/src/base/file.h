//
// Created by mainf on 2024/4/16.
//

#ifndef QiankunLU_FILE_H
#define QiankunLU_FILE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "matrix.h"
#include "file.h"

/**
头行的格式为：
%MatrixMarket object format field symmetry
头行必须是文件的第一行，并且必须以 %MatrixMarket 或 %%MatrixMarket 开始。其余4个字段的取值为：

object：通常是 matrix，另一个合法值是 vector，可以认为是矩阵的特殊形式；
format：coordinate 或者 array，前者用于稀疏矩阵，后者用于稠密矩阵或者向量；
field：合法值是 real, double, complex, integer or pattern，一般用 double 或者 complex，单精度使用 real，整数矩阵使用 integer；如果是 pattern，必须使用coordinate格式，并且只列出非零元所在的行列；
symmetry：是否对称，合法值包括 general（一般矩阵）、symmetric（对阵矩阵）、skew-symmetric（转置取负）和hermitian（复数对称）。出了general，其余三种格式要求只列出下三角数据。
*/
typedef struct {
    INDEX_TYPE rows;
    INDEX_TYPE cols;
    INDEX_TYPE not_zeros;
    char object[20];
    char format[20];
    char field[20];
    char symmetry[20];
} MtxInfo;

FILE *file_open(const char *file_name);

CSRMatrix *load_matrix_csr(const char *file_name, bool base_0);

void csr2mtx(const char *file_name, const CSRMatrix *A);

void int_vector2mtx(const char *file_name, const INDEX_TYPE *vector, INDEX_TYPE n);

void fp_vector2mtx(const char *file_name, const ELE_TYPE *vector, INDEX_TYPE n);

/**
 * di：double int 类型
 * 使用了零拷贝优化性能
 * @param filename mtx文件
 * @param M 矩阵维度 M*N大小
 * @param N 矩阵维度 M*N大小
 * @param nnz 非零元
 * @param col_ptr_out CSC Ap
 * @param row_idx_out CSC Ai
 * @param val_out CSC Ax
 * @return
 */
void read_mtx_csc(const char *filename,
                  INDEX_TYPE *M, INDEX_TYPE *N, INDEX_TYPE *nnz,
                  INDEX_TYPE **col_ptr_out, INDEX_TYPE **row_idx_out, double **val_out);

/**
 * 调用read_mtx_csc
 */
void load_csc(const char *filename, CSC *matrix);
#ifdef __cplusplus
}
#endif

#endif //QiankunLU_FILE_H
