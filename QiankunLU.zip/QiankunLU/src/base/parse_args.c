//
// Created by mainf on 2025/3/8.
//
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <string.h>
#include <base/malloc.h>
#include "parse_args.h"

#include "log.h"

// 静态辅助函数：安全字符串转整数
static int str_to_int(const char *str, char opt) {
    char *endptr;
    errno = 0;
    long val = strtol(str, &endptr, 10);

    // 检查非法字符
    if (*endptr != '\0') {
        LOG_ERROR("错误: -%c 的参数 '%s' 包含非法字符\n", opt, str);
    }

    // 检查数值范围
    if (errno == ERANGE || val < INT_MIN || val > INT_MAX) {
        LOG_ERROR("错误: -%c 的参数超出范围 (最小 %d, 最大 %d)\n",
                opt, INT_MIN, INT_MAX);
    }
    return (int) val;
}

// 安全字符串转浮点数（支持科学计数法）
static double str_to_double(const char *str, char opt) {
    char *endptr;
    errno = 0;
    double val = strtod(str, &endptr);

    // 检查无效字符
    if (*endptr != '\0') {
        LOG_ERROR("错误: -%c 的参数 '%s' 包含非法字符\n", opt, str);
    }

    // 检查溢出（HUGE_VAL是strtod的溢出返回值）
    if (errno == ERANGE || val == HUGE_VAL || val == -HUGE_VAL) {
        LOG_ERROR("错误: -%c 的参数 '%s' 超出浮点数范围\n", opt, str);
    }

    return val;
}

// 主解析函数
void parse_arguments(int argc, char *argv[], Config *config) {
    if (argc < 2) {
        LOG_ERROR("错误: 必须指定矩阵名\n用法: %s <矩阵名> [-l] [-o 日志文件] [-t 主元阈值] [-n 最大块边长]\n", argv[0]);
    }
    init_config(config);
    config->matrix_name = strdup(argv[1]);
    if (!config->matrix_name) {
        LOG_ERROR("内存分配失败\n");
    }
    // 调整参数位置，让getopt从第三个参数开始解析
    argc -= 1;
    argv += 1;
    int opt;
    while ((opt = getopt(argc, argv, "t:n:d:lo:")) != -1) {
        switch (opt) {
            case 't':
                config->accuracy_threshold = str_to_double(optarg, 't');
                break;
            case 'n':
                config->block_max_side = str_to_int(optarg, 'n');
                break;
            case 'd':
                config->is_output_matrix_structure_diagram = str_to_int(optarg, 'o');
                break;
            case 'l':
                config->log_enabled = 1;
                break;
            case 'o':
                free(config->output_file); // 防止重复赋值
                config->output_file = strdup(optarg);
                if (!config->output_file) {
                    LOG_ERROR("内存分配失败");
                }
                break;
            case '?':
                LOG_ERROR("用法: %s <矩阵名> [-l] [-o 日志文件] [-t 主元阈值] [-n 最大块边长]\n", argv[0]);
            default:
                abort();
        }
    }
}

void print_config(Config *config) {
    LOG_DEBUG("矩阵名: %s", config->matrix_name);
    LOG_DEBUG("参数配置:");
    LOG_DEBUG("  -t: %lg", config->accuracy_threshold);
    LOG_DEBUG("  -n: %d", config->block_max_side);
    LOG_DEBUG("  -l: %s", config->log_enabled ? "启用" : "关闭");
    LOG_DEBUG("  -o: %s", config->output_file ? config->output_file : "无");
}

///设置默认参数
void init_config(Config *config) {
    config->accuracy_threshold=1e-7;
    config->matrix_name=NULL;
    config->log_enabled=0;
    config->block_max_side=40;
    config->is_output_matrix_structure_diagram=0;
    config->output_file=NULL;
}

// 释放配置内存
void free_config(Config *config) {
    lu_free(config->matrix_name);
    lu_free(config->output_file);
}
