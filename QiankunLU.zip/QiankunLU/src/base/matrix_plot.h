//
// Created by mainf on 2025/3/24.
//

#ifndef MATRIX_PLOT_H
#define MATRIX_PLOT_H
#include "matrix.h"
#ifdef __cplusplus
extern "C" {
#endif

/**
 * 绘制分解后的L+U结构。当矩阵很大时是近似计算。
 */
void plot_LU(CSRMatrix *csr, const char *filename, double time);

void csr2image_RGB(const CSRMatrix *matrix, const char *filename, int img_width, int img_height);

///灰度图
void csr2image_gray(const CSRMatrix *matrix, const char *filename, int img_width, int img_height);

void csr2image_block_cut(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                         const char *filename,
                         INDEX_TYPE row_start, INDEX_TYPE row_end,
                         INDEX_TYPE col_start, INDEX_TYPE col_end,
                         const INDEX_TYPE *cut_points, INDEX_TYPE cut_points_count);

#ifdef __cplusplus
}
#endif

#endif //MATRIX_PLOT_H
