//
// Created by mainf on 2025/3/8.
//

#ifndef QiankunLU_PARSE_ARGS_H
#define QiankunLU_PARSE_ARGS_H
#ifdef __cplusplus
extern "C" {
#endif

// 参数配置结构体
typedef struct {
    int use_equivalent_reordering;
    int block_max_side;
    int is_output_matrix_structure_diagram;
    char *matrix_name;
    double accuracy_threshold;
    int log_enabled; // 可选参数：-l (启用日志)
    char *output_file; // 可选参数：-o <文件>
    int is_mc64;//使用MC64
} Config;

// 函数原型
void parse_arguments(int argc, char *argv[], Config *config);

void print_config(Config *config);

void free_config(Config *config);

void init_config(Config *config);

#ifdef __cplusplus
}
#endif
#endif