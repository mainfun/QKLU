//
// Created by mainf on 2024/9/15.
//

#include "matrix.h"

#include "matrix_util.h"

CSRMatrix *init_csr_matrix(INDEX_TYPE num_row, INDEX_TYPE num_col, INDEX_TYPE nnz) {
    CSRMatrix *matrix = (CSRMatrix *) lu_calloc(1, sizeof(CSRMatrix));
    matrix->num_col = num_col;
    matrix->num_row = num_row;
    matrix->nnz = nnz;
    matrix->row_pointers = (INDEX_TYPE *) lu_malloc((num_row + 1) * sizeof(INDEX_TYPE));
    matrix->col_indices = (INDEX_TYPE *) lu_malloc(nnz * sizeof(INDEX_TYPE));
    matrix->csr_values = (ELE_TYPE *) lu_malloc(nnz * sizeof(ELE_TYPE));
    return matrix;
}

void malloc_csc(CSC *matrix, INDEX_TYPE num_row, INDEX_TYPE num_col, INDEX_TYPE nnz) {
    matrix->num_col = num_col;
    matrix->num_row = num_row;
    matrix->nnz = nnz;
    matrix->col_ptr = (INDEX_TYPE *) lu_malloc((num_row + 1) * sizeof(INDEX_TYPE));
    matrix->row_idx = (INDEX_TYPE *) lu_malloc(nnz * sizeof(INDEX_TYPE));
    matrix->values = (ELE_TYPE *) lu_malloc(nnz * sizeof(ELE_TYPE));
}

void free_csc3(CSC *matrix) {
    if (matrix == NULL) return;
    lu_free(matrix->values);
    lu_free(matrix->col_ptr);
    lu_free(matrix->row_idx);
}


void free_csr_matrix(CSRMatrix *matrix) {
    if (matrix == NULL) return;
    lu_free(matrix->csr_values);
    lu_free(matrix->row_pointers);
    lu_free(matrix->col_indices);
    lu_free(matrix);
}

///只是free里面的指针
void free_csr_matrix_ptr(CSRMatrix *matrix) {
    if (matrix == NULL) return;
    lu_free(matrix->csr_values);
    lu_free(matrix->row_pointers);
    lu_free(matrix->col_indices);
}

void print_matrix_csr(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n) {
    if (n > 20) {
        for (INDEX_TYPE r = 0; r < 100; ++r) {
            for (INDEX_TYPE _j = Ap[r]; _j < Ap[r + 1]; ++_j) {
                INDEX_TYPE c = Ai[_j];
                printf("%lld, %lld\n", r, c);
            }
        }
        return;
    }
    INDEX_TYPE i, j, p, found;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            found = 0;
            for (p = Ap[i]; p < Ap[i + 1]; p++) {
                INDEX_TYPE col_index = Ai[p];
                if (col_index == j) {
                    printf(" 1 ");
                    found = 1;
                    break;
                }
            }
            if (!found) {
                printf(" 0 ");
            }
        }
        printf("\n");
    }
}

ELE_TYPE *csr2dense(const CSRMatrix *A) {
    const INDEX_TYPE *Ap = A->row_pointers;
    const INDEX_TYPE *Ai = A->col_indices;
    const ELE_TYPE *Ax = A->csr_values;
    INDEX_TYPE n = A->num_row;

    ELE_TYPE *D;
    D = (ELE_TYPE *) calloc(n * n, sizeof(ELE_TYPE));
    for (INDEX_TYPE r = 0; r < n; ++r) {
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; j++) {
            D[r * n + Ai[j]] = Ax == NULL ? 1 : Ax[j];
        }
    }
    return D;
}

ELE_TYPE *csc2dense(const CSC *A) {
    const INDEX_TYPE *Ap = A->col_ptr;
    const INDEX_TYPE *Ai = A->row_idx;
    const ELE_TYPE *Ax = A->values;

    ELE_TYPE *D;
    D = (ELE_TYPE *) calloc(A->num_row * A->num_col, sizeof(ELE_TYPE));
    for (INDEX_TYPE c = 0; c < A->num_col; ++c) {
        for (INDEX_TYPE j = Ap[c]; j < Ap[c + 1]; j++) {
            D[c + Ai[j] * A->num_col] = Ax == NULL ? 1 : Ax[j];
        }
    }
    return D;
}

ELE_TYPE *csr2dense_v2(const INDEX_TYPE *Ap_start, const INDEX_TYPE *Ap_end, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                       INDEX_TYPE n) {
    ELE_TYPE *D = (ELE_TYPE *) lu_calloc(n * n, sizeof(ELE_TYPE));
    for (INDEX_TYPE r = 0; r < n; ++r) {
        for (INDEX_TYPE j = Ap_start[r]; j < Ap_end[r]; j++) {
            D[r * n + Ai[j]] = Ax[j];
        }
    }
    return D;
}

ELE_TYPE *csc2dense_v2(const INDEX_TYPE *Ap_start, const INDEX_TYPE *Ap_end, const INDEX_TYPE *Ai, const ELE_TYPE *Ax,
                       INDEX_TYPE n) {
    ELE_TYPE *D = (ELE_TYPE *) calloc(n * n, sizeof(ELE_TYPE));
    for (INDEX_TYPE c = 0; c < n; ++c) {
        for (INDEX_TYPE j = Ap_start[c]; j < Ap_end[c]; j++) {
            D[Ai[j] * n + c] = Ax[j];
        }
    }
    return D;
}

void print_dense_matrix(ELE_TYPE *A, INDEX_TYPE n) {
    for (INDEX_TYPE i = 0; i < n; ++i) {
        for (INDEX_TYPE ii = 0; ii < n; ++ii) {
            printf("---------------");
        }
        printf("\n|");
        for (INDEX_TYPE j = 0; j < n; ++j) {
            if (A[i * n + j] == 0.0 || A[i * n + j] == -0.0) printf("              |");
            else printf("%13lf |", A[i * n + j]);
        }
        printf("\n");
    }
    for (INDEX_TYPE i = 0; i < n; ++i) {
        printf("---------------");
    }
    printf("\n");
}

void print_dense_matrix2(ELE_TYPE *A, INDEX_TYPE num_row,INDEX_TYPE num_col) {
    for (INDEX_TYPE i = 0; i < num_row; ++i) {
        for (INDEX_TYPE ii = 0; ii < num_col; ++ii) {
            printf("---------------");
        }
        printf("\n|");
        for (INDEX_TYPE j = 0; j < num_col; ++j) {
            if (A[i * num_col + j] == 0) printf("              |");
            else printf("%13lf |", A[i * num_col + j]);
        }
        printf("\n");
    }
    for (INDEX_TYPE i = 0; i < num_col; ++i) {
        printf("---------------");
    }
    printf("\n");
}

/**
 * 支持非方阵
 * @param A CSC
 */
void print_csc(CSC *A) {
    INDEX_TYPE M = A->num_row;
    INDEX_TYPE N = A->num_col;
    ELE_TYPE *D = csc2dense(A);

    for (INDEX_TYPE i = 0; i < M; ++i) {
        for (INDEX_TYPE ii = 0; ii < N; ++ii) {
            printf("---------------");
        }
        printf("\n|");
        for (INDEX_TYPE j = 0; j < N; ++j) {
            if (D[i * N + j] == 0) printf("              |");
            else printf("%13lf |", D[i * N + j]);
        }
        printf("\n");
    }
    for (INDEX_TYPE i = 0; i < N; ++i) {
        printf("---------------");
    }
    printf("\n");
    lu_free(D);
}

void print_csc3(INDEX_TYPE M,INDEX_TYPE N,INDEX_TYPE *Ap,INDEX_TYPE *Ai,ELE_TYPE *Ax) {
    CSC A;
    A.num_row = M;
    A.num_col = N;
    A.col_ptr = Ap;
    A.row_idx = Ai;
    A.values = Ax;
    print_csc(&A);
}

void print_matrix_csc(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n) {
    ELE_TYPE *A = (ELE_TYPE *) lu_calloc(n * n, sizeof(ELE_TYPE));
    for (INDEX_TYPE c = 0; c < n; ++c) {
        for (INDEX_TYPE j = Ap[c]; j < Ap[c + 1]; j++) {
            A[Ai[j] * n + c] = 1;
        }
    }
    for (INDEX_TYPE i = 0; i < n; ++i) {
        for (INDEX_TYPE j = 0; j < n; ++j) {
            printf("%3d", A[i * n + j] == 0 ? 0 : 1);
        }
        printf("\n");
    }
    lu_free(A);
}

void SpMV_csr(const CSRMatrix *A, const ELE_TYPE *x, ELE_TYPE *y) {
    for (INDEX_TYPE i = 0; i < A->num_row; i++) {
        y[i] = 0.0;
        for (INDEX_TYPE j = A->row_pointers[i]; j < A->row_pointers[i + 1]; j++) {
            y[i] += A->csr_values[j] * x[A->col_indices[j]];
        }
    }
}

void SpMV_csc(const CSC *A, const ELE_TYPE *x, ELE_TYPE *y) {
    for (INDEX_TYPE i = 0; i < A->num_row; i++) {
        for (INDEX_TYPE j = A->col_ptr[i]; j < A->col_ptr[i + 1]; j++) {
            y[A->row_idx[j]] += A->values[j] * x[i];
        }
    }
}

void a_plus_at(INDEX_TYPE n, INDEX_TYPE nnz,
               const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
               INDEX_TYPE *r_nnz, INDEX_TYPE **outRp, INDEX_TYPE **outRi) {
    //T=A^T
    INDEX_TYPE *Tp = (INDEX_TYPE *) lu_calloc((n + 1), sizeof(INDEX_TYPE));
    INDEX_TYPE *Ti = (INDEX_TYPE *) lu_malloc((nnz) * sizeof(INDEX_TYPE));
    csr2csc_pattern(Ap, Ai, Tp, Ti, nnz, n);
    //R=A+T
    INDEX_TYPE max_nnz = nnz * 2; //最大nnz
    INDEX_TYPE *Rp = (INDEX_TYPE *) lu_calloc((n + 1), sizeof(INDEX_TYPE));
    INDEX_TYPE *Ri = (INDEX_TYPE *) lu_malloc((max_nnz) * sizeof(INDEX_TYPE));

    INDEX_TYPE *mark = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    for (INDEX_TYPE i = 0; i < n; ++i) { mark[i] = -1; }
    Rp[0] = 0;
    INDEX_TYPE idx_count = 0;
    for (INDEX_TYPE i = 0; i < n; ++i) {
        mark[i] = i; //排除对角
        //Add A(:,k)
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE k = Ai[j];
            if (mark[k] != i) {
                mark[k] = i;
                Ri[idx_count++] = k;
            }
        }
        //Add T(:,k)
        for (INDEX_TYPE j = Tp[i]; j < Tp[i + 1]; ++j) {
            INDEX_TYPE k = Ti[j];
            if (mark[k] != i) {
                mark[k] = i;
                Ri[idx_count++] = k;
            }
        }
        Rp[i + 1] = idx_count;
    }
    //从max_nnz调整为实际的nnz
    Ri = (INDEX_TYPE *) lu_realloc(Ri, idx_count * sizeof(INDEX_TYPE));
    *r_nnz = idx_count;
    *outRp = Rp;
    *outRi = Ri;
    lu_free(Tp);
    lu_free(Ti);
    lu_free(mark);
}
