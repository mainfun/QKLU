//
// Created by mainf on 2024/8/14.
//
#include <stdio.h>
#include "malloc.h"
#include "log.h"


void *aligned_malloc(size_t size) {
    void *ptr;
    if (posix_memalign(&ptr, 64, size) != 0) {
        return NULL; // 分配失败
    }
    return ptr;
}

void *lu_malloc(size_t size) {
    void *ptr = malloc(size);
    if (ptr == NULL)
        LOG_ERROR("内存分配失败! 分配大小：%lu\n", size);
    return ptr;
}

void *lu_calloc(size_t n, size_t size) {
    void *ptr = calloc(n, size);
    if (ptr == NULL)
        LOG_ERROR("内存分配失败! 分配大小：%lu * %lu\n", n, size);
    return ptr;
}

void *lu_realloc(void *ptr, size_t size) {
    void *tmp = realloc(ptr, size);
    if (tmp == NULL) {
        LOG_ERROR("重新内存分配失败! 分配大小：%lu\n", size);
    }
    return tmp;
}
