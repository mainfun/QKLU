//
// Created by mainf on 2024/5/4.
//

#ifndef QiankunLU_SORT_H
#define QiankunLU_SORT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "base/matrix.h"

void bubble_sort(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE n);

void sort_matrix_idx(const int Ap[],int Ai[], int n);

// void radix_sort(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE n);

void sort_sparse_matrix(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE n);

void sort_ips2ra(INDEX_TYPE *Ai, ELE_TYPE *Ax, INDEX_TYPE n);

void sort_sparse_matrix_v2(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE n);

#ifdef __cplusplus
}
#endif

#endif //QiankunLU_SORT_H
