//
// Created by mainf on 2024/5/5.
//

#include "vector_util.h"
#include <random>
#include <cmath>

void random_int_vector(INDEX_TYPE vector[], INDEX_TYPE size) {
    std::random_device rd; // 用于获得随机种子
    std::mt19937 gen(rd()); // 以随机种子初始化 Mersenne Twister 引擎
    std::uniform_int_distribution<> dis(0, 99); // 生成0到99之间的随机数
    for (INDEX_TYPE i = 0; i < size; ++i) {
        vector[i] = dis(gen);
    }
}

void random_vector(ELE_TYPE vector[], INDEX_TYPE size) {
    std::random_device rd; // 用于获得随机种子
    std::mt19937 gen(rd()); // 以随机种子初始化 Mersenne Twister 引擎
    std::uniform_real_distribution<> dis(-1e19, 1e19); // 生成a到b之间的随机数
    for (INDEX_TYPE i = 0; i < size; ++i) {
        vector[i] = dis(gen);
    }
}

void random_sp_vector(ELE_TYPE vector[], INDEX_TYPE size) {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    // 60% 概率生成 0
    std::bernoulli_distribution zero_dist(0.6);
    // 非零时，绝对值均匀分布在 [min_abs, max_abs]
    const ELE_TYPE min_abs = 1e-16;
    const ELE_TYPE max_abs = 1e16;
    std::uniform_real_distribution<ELE_TYPE> mag_dist(min_abs, max_abs);
    // 决定正负号
    std::bernoulli_distribution sign_dist(0.5);

    for (INDEX_TYPE i = 0; i < size; ++i) {
        if (zero_dist(gen)) {
            vector[i] = 0.0;
        } else {
            ELE_TYPE m = mag_dist(gen);
            vector[i] = sign_dist(gen) ? m : -m;
        }
    }
}


ELE_TYPE *init_b(CSRMatrix *A) {
    ELE_TYPE *b = (ELE_TYPE *) lu_malloc(A->num_row * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = 0; i < A->num_col; ++i) {
        ELE_TYPE sum = 0;
        for (INDEX_TYPE j = A->row_pointers[i]; j < A->row_pointers[i + 1]; ++j) {
            sum += A->csr_values[j];
        }
        b[i] = sum;
    }
    return b;
}

void init_b_csc(const CSC *A, ELE_TYPE *b) {
    for (INDEX_TYPE col = 0; col < A->num_col; ++col) {
        for (INDEX_TYPE k = A->col_ptr[col]; k < A->col_ptr[col + 1]; ++k) {
            INDEX_TYPE row = A->row_idx[k];
            b[row] += A->values[k];
        }
    }
}


/// 计算向量的 L2 范数
double l2_norm(const ELE_TYPE *vector, INDEX_TYPE size) {
    ELE_TYPE sum = 0.0;
    for (INDEX_TYPE i = 0; i < size; i++) {
        sum += vector[i] * vector[i];
    }
    return sqrt(sum);
}

/// 计算向量的 L1 范数
double l1_norm(const ELE_TYPE *vector, INDEX_TYPE size) {
    double sum = 0.0;
    for (INDEX_TYPE i = 0; i < size; i++) {
        sum += fabs(vector[i]);
    }
    return sum;
}

// 计算向量的 L∞ 范数
double l_inf_norm(const ELE_TYPE *vector, INDEX_TYPE size) {
    ELE_TYPE max_val = 0.0;
    for (INDEX_TYPE i = 0; i < size; i++) {
        max_val = std::max(fabs(vector[i]), max_val);
    }
    return max_val;
}

/// r=x-y
void vector_sub(const ELE_TYPE *x, const ELE_TYPE *y, ELE_TYPE *r, INDEX_TYPE n) {
    for (INDEX_TYPE i = 0; i < n; ++i) {
        r[i] = x[i] - y[i];
    }
}
