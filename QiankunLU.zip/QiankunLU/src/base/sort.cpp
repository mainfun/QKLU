//
// Created by mainf on 2024/5/4.
//

#include "sort.h"
#include <algorithm>
#include <iostream>
#include <vector>
// #include <ips2ra.hpp>
// #include <ips4o/ips4o.hpp>
#include <functional>
/**
 * 通过冒泡排序调整稀疏矩阵的index数组，使其变有序
 * @param Ai index
 * @param Ax value
 * @param n 矩阵纬度
 */
void bubble_sort(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE n) {
    INDEX_TYPE i, j, temp;
    ELE_TYPE value_temp;
    INDEX_TYPE swapped;
    for (i = 0; i < n - 1; i++) {
        swapped = 0; // 没有发生交换的标志
        // 内层循环进行相邻元素比较
        for (j = 0; j < n - i - 1; j++) {
            if (Ai[j] > Ai[j + 1]) {
                // 交换
                temp = Ai[j];
                Ai[j] = Ai[j + 1];
                Ai[j + 1] = temp;
                // 交换
                if (Ax != NULL) {
                    value_temp = Ax[j];
                    Ax[j] = Ax[j + 1];
                    Ax[j + 1] = value_temp;
                }
                swapped = 1; // 发生了交换
            }
        }
        // 如果在某次遍历中没有发生交换，则数组已经有序
        if (swapped == 0)
            break;
    }
}

void sort_matrix_idx(const int Ap[],int Ai[], const int n) {
    // #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE i = 0; i < n; ++i) {
        std::sort(&Ai[Ap[i]], &Ai[Ap[i + 1]]);
    }
}


void sort_sparse_matrix(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE n) {
    // 创建索引数组
    std::vector<INDEX_TYPE> indices(n);
    std::vector<INDEX_TYPE> sorted_Ai(n);
    std::vector<ELE_TYPE> sorted_Ax(n);

    for (INDEX_TYPE i = 0; i < n; i++) {
        indices[i] = i;
    }

    // 根据 Ai 中的值对索引进行排序
    std::sort(indices.begin(), indices.end(), [&Ai](INDEX_TYPE i, INDEX_TYPE j) {
        return Ai[i] < Ai[j];
    });

    for (INDEX_TYPE i = 0; i < n; i++) {
        sorted_Ai[i] = Ai[indices[i]];
        sorted_Ax[i] = Ax[indices[i]];
    }

    // 更新 Ai 和 Ax 数组
    for (INDEX_TYPE i = 0; i < n; i++) {
        Ai[i] = sorted_Ai[i];
        Ax[i] = sorted_Ax[i];
    }
}




// 插入排序，用于小规模数组优化
void insertion_sort(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE left, INDEX_TYPE right) {
    for (INDEX_TYPE i = left + 1; i <= right; i++) {
        INDEX_TYPE key_Ai = Ai[i];
        ELE_TYPE key_Ax = Ax[i];
        INDEX_TYPE j = i - 1;
        while (j >= left && Ai[j] > key_Ai) {
            Ai[j + 1] = Ai[j];
            Ax[j + 1] = Ax[j];
            j--;
        }
        Ai[j + 1] = key_Ai;
        Ax[j + 1] = key_Ax;
    }
}

// 交换两个元素，同时交换Ai和Ax中的元素
void swap(INDEX_TYPE *a_Ai, ELE_TYPE *a_Ax, INDEX_TYPE *b_Ai, ELE_TYPE *b_Ax) {
    INDEX_TYPE temp_Ai = *a_Ai;
    ELE_TYPE temp_Ax = *a_Ax;
    *a_Ai = *b_Ai;
    *a_Ax = *b_Ax;
    *b_Ai = temp_Ai;
    *b_Ax = temp_Ax;
}

// 中位数取法，选择枢轴
INDEX_TYPE median_of_three(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE a, INDEX_TYPE b, INDEX_TYPE c) {
    if ((Ai[a] < Ai[b]) != (Ai[a] < Ai[c]))
        return a;
    else if ((Ai[b] < Ai[a]) != (Ai[b] < Ai[c]))
        return b;
    else
        return c;
}

// 非递归且不使用显式栈的快速排序
void sort_sparse_matrix_v2(INDEX_TYPE Ai[], ELE_TYPE Ax[], INDEX_TYPE n) {
    INDEX_TYPE left = 0;
    INDEX_TYPE right = n - 1;

    while (left < right) {
        // 当子数组较小时，使用插入排序
        if (right - left <= 10) {
            insertion_sort(Ai, Ax, left, right);
            break;
        }

        // 选择枢轴
        INDEX_TYPE mid = left + (right - left) / 2;
        INDEX_TYPE pivot_index = median_of_three(Ai, Ax, left, mid, right);
        INDEX_TYPE pivot_Ai = Ai[pivot_index];
        ELE_TYPE pivot_Ax = Ax[pivot_index];
        swap(&Ai[pivot_index], &Ax[pivot_index], &Ai[right], &Ax[right]); // 将枢轴移到末尾

        // 分区过程
        INDEX_TYPE i = left;
        INDEX_TYPE j = right - 1;
        while (i <= j) {
            while (i <= j && Ai[i] < pivot_Ai) i++;
            while (i <= j && Ai[j] > pivot_Ai) j--;
            if (i <= j) {
                swap(&Ai[i], &Ax[i], &Ai[j], &Ax[j]);
                i++;
                j--;
            }
        }
        swap(&Ai[i], &Ax[i], &Ai[right], &Ax[right]); // 将枢轴放回正确的位置

        // 确定较小的子数组
        if ((i - 1 - left) < (right - i)) {
            // 先处理左子数组
            if (left < i - 1) {
                // 将右子数组的边界保存在变量中
                INDEX_TYPE new_right = i - 1;
                // 继续处理左子数组
                right = new_right;
            }
            // 然后处理右子数组
            left = i + 1;
        } else {
            // 先处理右子数组
            if (i + 1 < right) {
                // 将左子数组的边界保存在变量中
                INDEX_TYPE new_left = i + 1;
                // 继续处理右子数组
                left = new_left;
            }
            // 然后处理左子数组
            right = i - 1;
        }
    }

    // 最后，处理可能未排序的小块
    // 因为在上面的循环中，可能有部分小数组未通过插入排序处理
    // 这里再次进行一次插入排序确保整个数组有序
    insertion_sort(Ai, Ax, 0, n - 1);
}
