//
// Created by mainf on 2025/5/21.
//

#ifndef SOLVING_CUDA_H
#define SOLVING_CUDA_H

#endif //SOLVING_CUDA_H

#ifdef __cplusplus
extern "C" {
#endif

#include <base/matrix_util.h>

void solve_sp_diagonal_v0_cuda(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,
                               INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x, ELE_TYPE *b);
#ifdef __cplusplus
}
#endif
