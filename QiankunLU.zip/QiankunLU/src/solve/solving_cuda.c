//
// Created by mainf on 2025/5/21.
//

#include "solving_cuda.h"
#include <numeric/numeric.h>
#include <preprocess/symbolic_analysis.h>
#include <omp.h>

#include "check.h"
#include "solving.h"
#include "numeric/sp_factor_v0_cuda.cuh"

void solve_sp_diagonal_v0_cuda(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,
                               INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x, ELE_TYPE *b) {
    double time_1 = omp_get_wtime();
    //--------------------------符号分析--------------------------
    INDEX_TYPE *lp_csr, *li_csr, *up, *ui; //U是CSR的，L需要从CSR转CSC
    fill_in_2_no_sort_pruneL(n, nnz, Ai, Ap, &up, &ui, &lp_csr, &li_csr);
    INDEX_TYPE l_nnz = lp_csr[n];
    INDEX_TYPE u_nnz = up[n];
    INDEX_TYPE *lp = (INDEX_TYPE *) lu_calloc(n + 1, sizeof(INDEX_TYPE));
    INDEX_TYPE *li = (INDEX_TYPE *) lu_malloc(lp_csr[n] * sizeof(INDEX_TYPE));
    //L需要从CSR转CSC
    csr2csc_pattern(lp_csr, li_csr, lp, li, l_nnz, n);
    //L+U
    INDEX_TYPE *Rp = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ri = (INDEX_TYPE *) lu_malloc((l_nnz + u_nnz) * sizeof(INDEX_TYPE));
    INDEX_TYPE index_size = 0;
    Rp[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = lp_csr[i]; j < lp_csr[i + 1]; j++) {
            Ri[index_size++] = li_csr[j];
        }
        for (INDEX_TYPE j = up[i]; j < up[i + 1]; j++) {
            Ri[index_size++] = ui[j];
        }
        Rp[i + 1] = index_size;
    }
    lu_free(li_csr);
    lu_free(lp_csr);
    LOG_TIME("solve_sp_diagonal_v2 符号计算 time: %f ms", (omp_get_wtime()-time_1)*1000);
    //--------------------------数值计算--------------------------
    ELE_TYPE *lx = (ELE_TYPE *) lu_malloc(l_nnz * sizeof(ELE_TYPE));
    ELE_TYPE *ux = (ELE_TYPE *) lu_malloc(u_nnz * sizeof(ELE_TYPE));
    INDEX_TYPE split_points_num;
    INDEX_TYPE *split_points = dispatch_find_split_points(Ap, Ai, n, nnz, &split_points_num);
    double time_2 = omp_get_wtime();
    sp_factor_v0_cuda(Ap, Ai, Ax, lp, li, lx, up, ui, ux, n, Rp, Ri, split_points_num, split_points);
    LOG_TIME("solve_sp_diagonal_v2 数值计算 time: %f ms", (omp_get_wtime()-time_2)*1000);
    lu_free(Rp);
    lu_free(Ri);
    //--------------------------数值求解--------------------------
    double time_3 = omp_get_wtime();
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    lower_solver_csc(lp, li, lx, n, y, b);
    upper_solver_csr(up, ui, ux, n, x, y);
    lu_free(y);
    lu_free(lp);
    lu_free(up);
    lu_free(li);
    lu_free(ui);
    lu_free(lx);
    lu_free(ux);
    LOG_TIME("solve_sp_diagonal_v2 数值求解 time: %f ms", (omp_get_wtime()-time_3)*1000);
}
