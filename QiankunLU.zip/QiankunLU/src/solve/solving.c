//
// Created by mainf on 2024/8/17.
//

#include "solving.h"

#include <omp.h>
#include <base/matrix_util.h>
#include <numeric/numeric.h>
#include <numeric/sp_factor.h>
#include <preprocess/etree.h>
#include <preprocess/reorder.h>
#include <preprocess/symbolic_analysis.h>

#include "check.h"

ELE_TYPE *permute_b(const ELE_TYPE *b, INDEX_TYPE n,
                    const INDEX_TYPE *mc64_perm,
                    const INDEX_TYPE *reorder_iperm,
                    const ELE_TYPE *Dr) {
    ELE_TYPE *b_prime = (ELE_TYPE *) malloc(n * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = 0; i < n; i++) {
        b_prime[reorder_iperm[mc64_perm[i]]] = b[i] * Dr[i];
        // b_prime[reorder_iperm[mc64_perm[i]]] = b[i] * 1;
    }
    return b_prime;
}

ELE_TYPE *permute_x(const ELE_TYPE *x, INDEX_TYPE n,
                    const INDEX_TYPE *reorder_iperm,
                    const ELE_TYPE *Dc) {
    ELE_TYPE *px = (ELE_TYPE *) malloc(n * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = 0; i < n; i++) {
        px[i] = x[reorder_iperm[i]] * Dc[i];
    }
    return px;
}

ELE_TYPE *permute_b_csc(const ELE_TYPE *b, const INDEX_TYPE n, const PreprocessInfo *f) {
    ELE_TYPE *b_prime = (ELE_TYPE *) malloc(n * sizeof(ELE_TYPE));
    if (f->Dc == NULL) {
        //debug
        if (f->reorder_iperm == NULL) {
            for (INDEX_TYPE i = 0; i < n; i++) {
                b_prime[i] = b[i];
            }
            return b_prime;
        }
        for (INDEX_TYPE i = 0; i < n; i++) {
            b_prime[f->reorder_iperm[i]] = b[i];
        }
        return b_prime;
    }
    //---------------------------------------------
    for (INDEX_TYPE i = 0; i < n; i++) {
        b_prime[f->reorder_iperm[i]] = b[i] * f->Dc[i];
    }
    return b_prime;
}

ELE_TYPE *permute_x_csc(const ELE_TYPE *x, const INDEX_TYPE n, const PreprocessInfo *f) {
    ELE_TYPE *px = (ELE_TYPE *) malloc(n * sizeof(ELE_TYPE));
    if (f->Dr == NULL) {
        //debug
        if (f->reorder_perm == NULL) {
            for (INDEX_TYPE i = 0; i < n; i++) {
                px[i] = x[i];
            }
            return px;
        }
        for (INDEX_TYPE i = 0; i < n; i++) {
            px[f->reorder_perm[i]] = x[i];
        }
        return px;
    }
    //---------------------------------------------
    for (INDEX_TYPE i = 0; i < n; i++) {
        px[f->mc64_iperm[f->reorder_perm[i]]] = x[i];
    }
    for (INDEX_TYPE i = 0; i < n; i++) {
        px[i] *= f->Dr[i];
    }
    return px;
}

/**
* L 是CSC的
*/
void lower_solver_csc(const INDEX_TYPE *Lp, const INDEX_TYPE *Li, const ELE_TYPE *Lx,
                      const INDEX_TYPE n,ELE_TYPE *x, const ELE_TYPE *b) {
    memcpy(x, b, n * sizeof(ELE_TYPE));
    for (INDEX_TYPE j = 0; j < n; ++j) {
        if (x[j] == 0) continue;
        for (INDEX_TYPE i = Lp[j]; i < Lp[j + 1]; i++) {
            x[Li[i]] -= Lx[i] * x[j];
        }
    }
}

void lower_solver_csc_block(const CSC *L11, const CSC *L21, ELE_TYPE *x, const ELE_TYPE *b) {
    memcpy(x, b, (L11->num_row + L21->num_row) * sizeof(ELE_TYPE));
    //x1
    for (INDEX_TYPE j = 0; j < L11->num_col; ++j) {
        ELE_TYPE v = x[j];
        if (x[j] == 0) continue;
        for (INDEX_TYPE i = L11->col_ptr[j]; i < L11->col_ptr[j + 1]; i++) {
            x[L11->row_idx[i]] -= L11->values[i] * v;
        }
        for (INDEX_TYPE i = L21->col_ptr[j]; i < L21->col_ptr[j + 1]; i++) {
            x[L21->row_idx[i] + L11->num_row] -= L21->values[i] * v;
        }
    }
    //x2-=x1*L21
    // for (INDEX_TYPE j = 0; j < L21->num_col; ++j) {
    //     if (x[j] == 0) continue;
    //     for (INDEX_TYPE i = L21->col_ptr[j]; i < L21->col_ptr[j + 1]; i++) {
    //         x[L21->row_idx[i] + L11->num_row] -= L21->values[i] * x[j];
    //     }
    // }
}

/**
* L 是CSR的
*/
void lower_solver_csr(const INDEX_TYPE *Lp, const INDEX_TYPE *Li, const ELE_TYPE *Lx,
                      const INDEX_TYPE n,ELE_TYPE *x, const ELE_TYPE *b) {
    memcpy(x, b, n * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = 0; i < n; ++i) {
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            x[i] -= Lx[j] * x[Li[j]];
        }
    }
}


/**
 * 解UX=b，U是CSR格式
 */
void upper_solver_csr(const INDEX_TYPE *Up, const INDEX_TYPE *Ui, const ELE_TYPE *Ux,
                      const INDEX_TYPE n, ELE_TYPE *x, const ELE_TYPE *b) {
    memcpy(x, b, n * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = n - 1; i >= 0; --i) {
        for (INDEX_TYPE j = Up[i] + 1; j < Up[i + 1]; j++) {
            x[i] -= Ux[j] * x[Ui[j]];
        }
        x[i] /= Ux[Up[i]];
    }
}

/**
 * 解UX=b，U是CSR格式
 */
void upper_solver_csr_exclude_diag(const INDEX_TYPE *Up, const INDEX_TYPE *Ui, const ELE_TYPE *Ux,
                                   const ELE_TYPE *U_diag,
                                   const INDEX_TYPE n, ELE_TYPE *x, const ELE_TYPE *b) {
    memcpy(x, b, n * sizeof(ELE_TYPE));
    for (INDEX_TYPE i = n - 1; i >= 0; --i) {
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            x[i] -= Ux[j] * x[Ui[j]];
        }
        x[i] /= U_diag[i];
    }
}

/**
 * 解UX=b，U是CSC格式
 */
void upper_solver_csc_exclude_diag(const INDEX_TYPE *Up, const INDEX_TYPE *Ui, const ELE_TYPE *Ux,
                                   const ELE_TYPE *U_diag,
                                   const INDEX_TYPE n, ELE_TYPE *x, const ELE_TYPE *b) {
    memcpy(x, b, n * sizeof(ELE_TYPE));
    for (INDEX_TYPE j = n - 1; j >= 0; --j) {
        if (x[j] == 0) continue;
        ELE_TYPE v = x[j] /= U_diag[j];
        for (INDEX_TYPE i = Up[j]; i < Up[j + 1]; i++) {
            x[Ui[i]] -= Ux[i] * v;
        }
    }
}

void upper_solver_csc_exclude_diag_block(const CSC *U11, const CSC *U12,
                                         const ELE_TYPE *U_diag,ELE_TYPE *x, const ELE_TYPE *b) {
    //for x in U12 num_row 累减
    INDEX_TYPE n = U11->num_row + U12->num_col;
    memcpy(x, b, n * sizeof(ELE_TYPE));
    for (INDEX_TYPE j = 0; j < U12->num_col; j++) {
        ELE_TYPE v = x[U11->num_row + j];
        for (INDEX_TYPE i = U12->col_ptr[j]; i < U12->col_ptr[j + 1]; i++) {
            x[U12->row_idx[i]] -= U12->values[i] * v;
        }
    }
    //upper_solver_csc_exclude_diag(U11)
    for (INDEX_TYPE j = U11->num_col - 1; j >= 0; --j) {
        if (x[j] == 0) continue;
        ELE_TYPE v = x[j] /= U_diag[j];
        for (INDEX_TYPE i = U11->col_ptr[j]; i < U11->col_ptr[j + 1]; i++) {
            x[U11->row_idx[i]] -= U11->values[i] * v;
        }
    }
}

void solve_sp_diagonal_v0(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x,
                          ELE_TYPE *b) {
    //符号分析
    INDEX_TYPE *lp_csr, *li_csr, *up, *ui;

    fill_in_2_no_sort_pruneL(n, nnz, Ai, Ap, &up, &ui, &lp_csr, &li_csr);
    INDEX_TYPE l_nnz = lp_csr[n];
    INDEX_TYPE u_nnz = up[n];
    INDEX_TYPE *lp = (INDEX_TYPE *) lu_calloc(n + 1, sizeof(INDEX_TYPE));
    INDEX_TYPE *li = (INDEX_TYPE *) lu_malloc(lp_csr[n] * sizeof(INDEX_TYPE));
    csr2csc_pattern(lp_csr, li_csr, lp, li, l_nnz, n);
    lu_free(lp_csr);
    lu_free(li_csr);
    //数值计算
    ELE_TYPE *lx = (ELE_TYPE *) lu_malloc(l_nnz * sizeof(ELE_TYPE));
    ELE_TYPE *ux = (ELE_TYPE *) lu_malloc(u_nnz * sizeof(ELE_TYPE));
    sp_factor_v0(Ap, Ai, Ax, lp, li, lx, up, ui, ux, n);
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    lower_solver_csc(lp, li, lx, n, y, b);
    upper_solver_csr(up, ui, ux, n, x, y);
    lu_free(y);
    lu_free(lp);
    lu_free(up);
    lu_free(li);
    lu_free(ui);
    lu_free(lx);
    lu_free(ux);
}

void solve_sp_diagonal_v1(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x,
                          ELE_TYPE *b) {
    double time_1 = omp_get_wtime();
    //--------------------------符号分析--------------------------
    INDEX_TYPE *lp_csr, *li_csr, *up, *ui; //U是CSR的，L需要从CSR转CSC
    fill_in_2_no_sort_pruneL(n, nnz, Ai, Ap, &up, &ui, &lp_csr, &li_csr);
    INDEX_TYPE l_nnz = lp_csr[n];
    INDEX_TYPE u_nnz = up[n];
    INDEX_TYPE *lp = (INDEX_TYPE *) lu_calloc(n + 1, sizeof(INDEX_TYPE));
    INDEX_TYPE *li = (INDEX_TYPE *) lu_malloc(lp_csr[n] * sizeof(INDEX_TYPE));
    //L需要从CSR转CSC
    csr2csc_pattern(lp_csr, li_csr, lp, li, l_nnz, n);
    //L+U
    INDEX_TYPE *Rp = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ri = (INDEX_TYPE *) lu_malloc((l_nnz + u_nnz) * sizeof(INDEX_TYPE));
    INDEX_TYPE index_size = 0;
    Rp[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = lp_csr[i]; j < lp_csr[i + 1]; j++) {
            Ri[index_size++] = li_csr[j];
        }
        for (INDEX_TYPE j = up[i]; j < up[i + 1]; j++) {
            Ri[index_size++] = ui[j];
        }
        Rp[i + 1] = index_size;
    }
    lu_free(li_csr);
    lu_free(lp_csr);
    LOG_TIME("solve_sp_diagonal_v1 符号计算 time: %f ms", (omp_get_wtime()-time_1)*1000);
    //--------------------------数值计算--------------------------
    double time_2 = omp_get_wtime();
    ELE_TYPE *lx = (ELE_TYPE *) lu_malloc(l_nnz * sizeof(ELE_TYPE));
    ELE_TYPE *ux = (ELE_TYPE *) lu_malloc(u_nnz * sizeof(ELE_TYPE));
    sp_factor_v1(Ap, Ai, Ax, lp, li, lx, up, ui, ux, n, Rp, Ri);
    lu_free(Rp);
    lu_free(Ri);
    LOG_TIME("solve_sp_diagonal_v1 数值计算 time: %f ms", (omp_get_wtime()-time_2)*1000);
    //--------------------------数值求解--------------------------
    double time_3 = omp_get_wtime();
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    lower_solver_csc(lp, li, lx, n, y, b);
    upper_solver_csr(up, ui, ux, n, x, y);
    lu_free(y);
    lu_free(lp);
    lu_free(up);
    lu_free(li);
    lu_free(ui);
    lu_free(lx);
    lu_free(ux);
    LOG_TIME("solve_sp_diagonal_v1 数值求解 time: %f ms", (omp_get_wtime()-time_3)*1000);
}

void solve_sp_diagonal_v2(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x,
                          ELE_TYPE *b) {
    double time_1 = omp_get_wtime();
    //--------------------------符号分析--------------------------
    INDEX_TYPE *lp_csr, *li_csr, *up, *ui; //U是CSR的，L需要从CSR转CSC
    fill_in_2_no_sort_pruneL(n, nnz, Ai, Ap, &up, &ui, &lp_csr, &li_csr);
    INDEX_TYPE l_nnz = lp_csr[n];
    INDEX_TYPE u_nnz = up[n];
    INDEX_TYPE *lp = (INDEX_TYPE *) lu_calloc(n + 1, sizeof(INDEX_TYPE));
    INDEX_TYPE *li = (INDEX_TYPE *) lu_malloc(lp_csr[n] * sizeof(INDEX_TYPE));
    //L需要从CSR转CSC
    csr2csc_pattern(lp_csr, li_csr, lp, li, l_nnz, n);
    //L+U
    INDEX_TYPE *Rp = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ri = (INDEX_TYPE *) lu_malloc((l_nnz + u_nnz) * sizeof(INDEX_TYPE));
    INDEX_TYPE index_size = 0;
    Rp[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = lp_csr[i]; j < lp_csr[i + 1]; j++) {
            Ri[index_size++] = li_csr[j];
        }
        for (INDEX_TYPE j = up[i]; j < up[i + 1]; j++) {
            Ri[index_size++] = ui[j];
        }
        Rp[i + 1] = index_size;
    }
    lu_free(li_csr);
    lu_free(lp_csr);
    LOG_TIME("solve_sp_diagonal_v2 符号计算 time: %f ms", (omp_get_wtime()-time_1)*1000);
    //--------------------------数值计算--------------------------
    ELE_TYPE *lx = (ELE_TYPE *) lu_malloc(l_nnz * sizeof(ELE_TYPE));
    ELE_TYPE *ux = (ELE_TYPE *) lu_malloc(u_nnz * sizeof(ELE_TYPE));
    INDEX_TYPE split_points_num;
    INDEX_TYPE *split_points = dispatch_find_split_points(Ap, Ai, n, nnz, &split_points_num);
    double time_2 = omp_get_wtime();
    sp_factor_v2(Ap, Ai, Ax, lp, li, lx, up, ui, ux, n, Rp, Ri, split_points_num, split_points);
    LOG_TIME("solve_sp_diagonal_v2 数值计算 time: %f ms", (omp_get_wtime()-time_2)*1000);
    lu_free(Rp);
    lu_free(Ri);
    //--------------------------数值求解--------------------------
    double time_3 = omp_get_wtime();
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    lower_solver_csc(lp, li, lx, n, y, b);
    upper_solver_csr(up, ui, ux, n, x, y);
    lu_free(y);
    lu_free(lp);
    lu_free(up);
    lu_free(li);
    lu_free(ui);
    lu_free(lx);
    lu_free(ux);
    LOG_TIME("solve_sp_diagonal_v2 数值求解 time: %f ms", (omp_get_wtime()-time_3)*1000);
}


void solve_sp_diagonal_v3(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,
                          INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x,
                          ELE_TYPE *b) {
    double time_1 = omp_get_wtime();
    //--------------------------符号分析--------------------------
    INDEX_TYPE *lp_csr, *li_csr, *up, *ui; //U是CSR的，L需要从CSR转CSC
    fill_in_2_no_sort_pruneL(n, nnz, Ai, Ap, &up, &ui, &lp_csr, &li_csr);
    INDEX_TYPE l_nnz = lp_csr[n];
    INDEX_TYPE u_nnz = up[n];
    INDEX_TYPE *lp = (INDEX_TYPE *) lu_calloc(n + 1, sizeof(INDEX_TYPE));
    INDEX_TYPE *li = (INDEX_TYPE *) lu_malloc(lp_csr[n] * sizeof(INDEX_TYPE));
    //L需要从CSR转CSC
    csr2csc_pattern(lp_csr, li_csr, lp, li, l_nnz, n);
    //L+U
    INDEX_TYPE *Rp = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ri = (INDEX_TYPE *) lu_malloc((l_nnz + u_nnz) * sizeof(INDEX_TYPE));
    INDEX_TYPE index_size = 0;
    Rp[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = lp_csr[i]; j < lp_csr[i + 1]; j++) {
            Ri[index_size++] = li_csr[j];
        }
        for (INDEX_TYPE j = up[i]; j < up[i + 1]; j++) {
            Ri[index_size++] = ui[j];
        }
        Rp[i + 1] = index_size;
    }
    lu_free(li_csr);
    lu_free(lp_csr);
    LOG_TIME("solve_sp_diagonal_v2 符号计算 time: %f ms", (omp_get_wtime()-time_1)*1000);
    //--------------------------数值计算--------------------------
    ELE_TYPE *lx = (ELE_TYPE *) lu_malloc(l_nnz * sizeof(ELE_TYPE));
    ELE_TYPE *ux = (ELE_TYPE *) lu_malloc(u_nnz * sizeof(ELE_TYPE));
    INDEX_TYPE split_points_num;
    INDEX_TYPE *split_points = dispatch_find_split_points(Ap, Ai, n, nnz, &split_points_num);
    double time_2 = omp_get_wtime();
    sp_factor_v3(Ap, Ai, Ax, lp, li, lx, up, ui, ux, n, Rp, Ri, split_points_num, split_points);
    LOG_TIME("solve_sp_diagonal_v2 数值计算 time: %f ms", (omp_get_wtime()-time_2)*1000);
    lu_free(Rp);
    lu_free(Ri);
    //--------------------------数值求解--------------------------
    double time_3 = omp_get_wtime();
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    lower_solver_csc(lp, li, lx, n, y, b);
    upper_solver_csr(up, ui, ux, n, x, y);
    lu_free(y);
    lu_free(lp);
    lu_free(up);
    lu_free(li);
    lu_free(ui);
    lu_free(lx);
    lu_free(ux);
    LOG_TIME("solve_sp_diagonal_v2 数值求解 time: %f ms", (omp_get_wtime()-time_3)*1000);
}

void swap_index(INDEX_TYPE *a, INDEX_TYPE *b) {
    INDEX_TYPE tmp = *a;
    *a = *b;
    *b = tmp;
}

void left_looking_solve_small_matrix(CSC o_matrix) {
    INDEX_TYPE n = o_matrix.num_row;
    //-------------- reordering --------------
    double start_time = omp_get_wtime();
    PreprocessInfo *info = init_preprocess_info();
    CSC *A = (CSC *) reordering_small_matrix((CSRMatrix *) &o_matrix, info,true,true);
    //-------------- symbolic analysis --------------
    INDEX_TYPE *etree = create_etree_force2sym((CSRMatrix *) A);
    CSC U11, U12, L11, L21;
    //把CSC格式的A当成CSR的，这相当于在计算A^T，算出来的结果L+U也是转置的
    symbolic_analysis_block(etree, (CSRMatrix *) A, info,
                            (CSRMatrix *) &L11, (CSRMatrix *) &L21,
                            (CSRMatrix *) &U11, (CSRMatrix *) &U12);
    lu_free(etree);
    swap_index(&U12.num_row, &U12.num_col);
    swap_index(&L21.num_row, &L21.num_col);
    //-------------- numerical decomposition --------------
    ELE_TYPE *Lx = (ELE_TYPE *) lu_malloc(L11.nnz * sizeof(ELE_TYPE));
    ELE_TYPE *Ux = (ELE_TYPE *) lu_malloc(U11.nnz * sizeof(ELE_TYPE));
    ELE_TYPE *U_diag = (ELE_TYPE *) lu_malloc(U11.num_row * sizeof(ELE_TYPE));
    L11.values = Lx;
    U11.values = Ux;
    sp_factor_v7(A->col_ptr, A->row_idx, A->values,
                 L11.col_ptr, L11.row_idx, Lx,
                 U11.col_ptr, U11.row_idx, Ux, U_diag, n);
    LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);
    // print_csc(&L11);
    // print_csc(&U11);
    //-------------- solving --------------
    ELE_TYPE *x = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    ELE_TYPE *b = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    random_sp_vector(b, n);
    ELE_TYPE *perm_b = permute_b_csc(b, n, info);

    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    lower_solver_csc(L11.col_ptr, L11.row_idx, Lx, n, y, perm_b);
    upper_solver_csc_exclude_diag(U11.col_ptr, U11.row_idx, Ux, U_diag, n, x, y);

    ELE_TYPE *perm_x = permute_x_csc(x, n, info);
    check_solving_csc(&o_matrix, perm_x, b);
    LOG_TIME("Total time:%f ms", (omp_get_wtime()-start_time)*1000);
    //-------------- free memory --------------
    // LOG_TIME("LU decomposition total time:%f s", omp_get_wtime()-start_time);
    free_csc3(&o_matrix);
    free_csc3(A);
    free_csc3(&L11), free_csc3(&U11);
    free_csc3(&L21);
    lu_free(U_diag);
    lu_free(b);
    lu_free(x);
    lu_free(y);
    lu_free(perm_b);
    lu_free(perm_x);
    free_preprocess_info(info);
}
