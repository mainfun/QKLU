//
// Created by mainf on 2024/8/18.
//
#include "check.h"
#include "math.h"

#include "preprocess/preprocess.h"

ELE_TYPE check_solving(const CSRMatrix *A, ELE_TYPE x[], ELE_TYPE b[]) {
    INDEX_TYPE n = A->num_row;
    ELE_TYPE *r = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    ELE_TYPE *y = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    SpMV_csr(A, x, y); //y=Ax
    vector_sub(y, b, r, n); //r=Ax-b
    ELE_TYPE l2 = l2_norm(r, n); //|| Ax - b ||
    ELE_TYPE result = l2 / l2_norm(b, n);
    printf("|| Ax - b ||2 / || b ||2 = %le\n", result);
    lu_free(y);
    lu_free(r);
    return result;
}

ELE_TYPE check_solving_csc(const CSC *A, ELE_TYPE x[], ELE_TYPE b[]) {
    INDEX_TYPE n = A->num_row;
    ELE_TYPE *r = (ELE_TYPE *) lu_malloc(n * sizeof(ELE_TYPE));
    ELE_TYPE *y = (ELE_TYPE *) lu_calloc(n, sizeof(ELE_TYPE));
    SpMV_csc(A, x, y); //y=Ax
    vector_sub(y, b, r, n); //r=Ax-b
    ELE_TYPE l2 = l2_norm(r, n); //|| Ax - b ||
    ELE_TYPE result = l2 / l2_norm(b, n);
    printf("|| Ax - b ||2 / || b ||2 = %le\n", result);
    lu_free(y);
    lu_free(r);
    return result;
}

/**
 * @param RMSE 均方根误差
 * @param max_diff 绝对值最大误差
 */
void calc_RMSE_and_max_diff(const CSRMatrix *A, const CSRMatrix *L,
                            const CSRMatrix *U, ELE_TYPE *RMSE, ELE_TYPE *max_diff) {
    LOG_DEBUG("check lu start.");
    const INDEX_TYPE *Ap = A->row_pointers;
    const INDEX_TYPE *Ai = A->col_indices;
    const ELE_TYPE *Ax = A->csr_values;

    const INDEX_TYPE *Lp = L->row_pointers;
    const INDEX_TYPE *Li = L->col_indices;
    const ELE_TYPE *Lx = L->csr_values;

    const INDEX_TYPE *Up = U->row_pointers;
    const INDEX_TYPE *Ui = U->col_indices;
    const ELE_TYPE *Ux = U->csr_values;

    ELE_TYPE *R = (ELE_TYPE *) lu_malloc(A->num_col * sizeof(ELE_TYPE));
    ELE_TYPE sum_squared_diff = 0.0;
    ELE_TYPE max_absolute_diff = 0.0;
    for (INDEX_TYPE i = 0; i < L->num_row; ++i) {
        //初始化
        memset(R, 0, sizeof(ELE_TYPE) * A->num_col);
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; j++) {
            R[Ai[j]] = -Ax[j];
        }
        for (INDEX_TYPE j = Up[i]; j < Up[i + 1]; j++) {
            R[Ui[j]] = Ux[j];
        }
        //计算
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; j++) {
            ELE_TYPE Lv = Lx[j];
            INDEX_TYPE l_col = Li[j];
            for (INDEX_TYPE k = Up[l_col]; k < Up[l_col + 1]; k++) {
                ELE_TYPE Uv = Ux[k];
                INDEX_TYPE col = Ui[k];
                R[col] += Lv * Uv;
            }
        }
        //计算误差
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; j++) {
            ELE_TYPE v = R[Ai[j]];
            //LOG_DEBUG("%lf ",v);
            sum_squared_diff += v * v;
            double abs_diff = fabs(v);
            if (abs_diff > max_absolute_diff) {
                max_absolute_diff = abs_diff;
            }
        }
    }
    lu_free(R);
    *RMSE = sqrt(sum_squared_diff / (ELE_TYPE) A->nnz);
    *max_diff = max_absolute_diff;
}

void check_lu(const CSRMatrix *A, const CSRMatrix *L, const CSRMatrix *U) {
    ELE_TYPE RMSE = 0;
    ELE_TYPE max = 0;
    calc_RMSE_and_max_diff(A, L, U, &RMSE, &max);
    LOG_DEBUG("RMSE=%le, max=%le", RMSE, max);
}
