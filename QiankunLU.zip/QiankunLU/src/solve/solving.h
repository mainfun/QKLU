//
// Created by mainf on 2024/8/17.
//

#ifndef MY_LU_SOLVING_H
#define MY_LU_SOLVING_H
#ifdef __cplusplus
extern "C" {
#endif
#include <preprocess/preprocess.h>

#include "base/matrix.h"

ELE_TYPE *permute_b(const ELE_TYPE *b, INDEX_TYPE n,
                    const INDEX_TYPE *mc64_perm,
                    const INDEX_TYPE *reorder_iperm,
                    const ELE_TYPE *Dr);

ELE_TYPE *permute_x(const ELE_TYPE *x, INDEX_TYPE n,
                    const INDEX_TYPE *reorder_iperm,
                    const ELE_TYPE *Dc);

ELE_TYPE *permute_b_csc(const ELE_TYPE *b, INDEX_TYPE n, const PreprocessInfo *f);

ELE_TYPE *permute_x_csc(const ELE_TYPE *x, INDEX_TYPE n, const PreprocessInfo *f);

void lower_solver_csc(const INDEX_TYPE *Lp, const INDEX_TYPE *Li, const ELE_TYPE *Lx,
                      const INDEX_TYPE n,ELE_TYPE *x, const ELE_TYPE *b);

void lower_solver_csc_block(const CSC *L11, const CSC *L21, ELE_TYPE *x, const ELE_TYPE *b);

void upper_solver_csc_exclude_diag_block(const CSC *U11, const CSC *U12,
                                         const ELE_TYPE *U_diag,ELE_TYPE *x, const ELE_TYPE *b);

void lower_solver_csr(const INDEX_TYPE *Lp, const INDEX_TYPE *Li, const ELE_TYPE *Lx,
                      const INDEX_TYPE n,ELE_TYPE *x, const ELE_TYPE *b);

void upper_solver_csr(const INDEX_TYPE *Up, const INDEX_TYPE *Ui, const ELE_TYPE *Ux,
                      const INDEX_TYPE n, ELE_TYPE *x, const ELE_TYPE *b);

void upper_solver_csr_exclude_diag(const INDEX_TYPE *Up, const INDEX_TYPE *Ui, const ELE_TYPE *Ux,
                                   const ELE_TYPE *U_diag,
                                   const INDEX_TYPE n, ELE_TYPE *x, const ELE_TYPE *b);

void upper_solver_csc_exclude_diag(const INDEX_TYPE *Up, const INDEX_TYPE *Ui, const ELE_TYPE *Ux,
                                   const ELE_TYPE *U_diag,
                                   const INDEX_TYPE n, ELE_TYPE *x, const ELE_TYPE *b);

void solve_sp_diagonal_v0(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x,
                          ELE_TYPE *b);

void solve_sp_diagonal_v1(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x,
                          ELE_TYPE *b);

void solve_sp_diagonal_v2(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x,
                          ELE_TYPE *b);

void solve_sp_diagonal_v3(INDEX_TYPE *Ap, INDEX_TYPE *Ai, ELE_TYPE *Ax,INDEX_TYPE n, INDEX_TYPE nnz, ELE_TYPE *x,
                          ELE_TYPE *b);

void left_looking_solve_small_matrix(CSC o_matrix);

#ifdef __cplusplus
}
#endif
#endif //MY_LU_SOLVING_H
