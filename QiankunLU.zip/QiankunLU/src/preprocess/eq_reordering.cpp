//
// Created by mainf on 2024/12/2.
//
#include <iostream>
#include <queue>
#include <preprocess/preprocess.h>
#include <preprocess/etree.h>
#include <base/matrix.h>
#include <preprocess/symbolic_analysis.h>
#include "eq_reordering.h"
#include <stack>
#include <math.h>
#include <omp.h>
#include <base/base_math.h>

INDEX_TYPE *layer1_split;
INDEX_TYPE layer1_num = 0;
INDEX_TYPE *layer2_split;
INDEX_TYPE layer2_num = 0;

///行宽：L的行第一个非零元的列号-对角线的列号
void calc_row_wide(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE *values,INDEX_TYPE n) {
    double time = omp_get_wtime();
    INDEX_TYPE *min_row = A_min_row_idx(Ap, Ai, n);
    for (INDEX_TYPE i = 0; i < n; ++i) {
        INDEX_TYPE idx = Ai[Ap[i]];
        // values[i] = i - idx;
        values[i] = i - MIN(min_row[i], idx);
    }
    LOG_TIME("calc_row_wide elapsed time: %lf ms", (omp_get_wtime() - time) * 1000.0);
}

INDEX_TYPE calc_threshold(INDEX_TYPE n,INDEX_TYPE nnz) {
    // return (INDEX_TYPE) n ;
    printf("omp threads:%d\n", omp_get_max_threads());
    printf("AAT nnz:%ld\n", nnz);
    return (INDEX_TYPE) n / (nnz / n / 2);
}

// INDEX_TYPE *eq_order(INDEX_TYPE n, const INDEX_TYPE parent[], float rate) {
//     INDEX_TYPE *order = (INDEX_TYPE *) malloc(n * sizeof(INDEX_TYPE));
//     INDEX_TYPE *kid_count_0 = (INDEX_TYPE *) calloc(n + 1, sizeof(INDEX_TYPE));
//     INDEX_TYPE *sub_tree_size = (INDEX_TYPE *) calloc(n + 1, sizeof(INDEX_TYPE));
//     INDEX_TYPE *sub_tree_height = (INDEX_TYPE *) calloc(n + 1, sizeof(INDEX_TYPE));
//     sub_tree_size++, sub_tree_height++;
//     INDEX_TYPE *stack = (INDEX_TYPE *) malloc(n * sizeof(INDEX_TYPE));
//     INDEX_TYPE top = n - 1; //head指向stack下一个元素要放的位置
//     INDEX_TYPE rear = n - 1; //rear表示栈底, head==rear是true表示队空
//     INDEX_TYPE top_order = -1;
//     for (INDEX_TYPE i = 0; i < n; i++) {
//         sub_tree_size[i] = 1;
//         sub_tree_height[i] = 1;
//     }
//     INDEX_TYPE *kid_count = kid_count_0 + 1; //为了方便处理根是-1
//     for (INDEX_TYPE i = 0; i < n; kid_count[parent[i++]]++);
//     // 将所有叶子节点入栈
//     for (INDEX_TYPE i = n - 1; i >= 0; i--) {
//         if (kid_count[i] == 0) {
//             // 叶子节点
//             stack[top--] = i;
//         }
//     }
//     while (top_order < n) {
//         INDEX_TYPE node;
//         node = stack[top = (top + 1) % n]; //dequeue
//         //printf("%lld ", node);
//         order[++top_order] = node;
//         // 获取父节点，并减少其子节点数
//         INDEX_TYPE parent_node = parent[node];
//         kid_count[parent_node]--;
//         sub_tree_size[parent_node] += sub_tree_size[node];
//         sub_tree_height[parent_node] = MAX(sub_tree_height[parent_node], sub_tree_height[node]);
//         // 如果父节点的子节点数为0
//         while (parent_node > 0 && kid_count[parent_node] == 0) {
//             sub_tree_height[parent_node]++;
//             if (sub_tree_size[parent_node] >= sqrt(n) * 10 && sub_tree_height[parent_node] / sub_tree_size[parent_node]
//                 <= rate) {
//                 stack[rear = (rear + 1) % n] = parent_node; //入队
//                 sub_tree_size[parent_node] = 1; //todo
//                 sub_tree_height[parent_node] = 1;
//                 // printf("%ld ", top_order);
//                 break;
//             }
//             order[++top_order] = parent_node;
//             INDEX_TYPE s = sub_tree_size[parent_node];
//             INDEX_TYPE h = sub_tree_height[parent_node];
//             parent_node = parent[parent_node];
//             kid_count[parent_node]--;
//             sub_tree_size[parent_node] += s;
//             sub_tree_height[parent_node] = MAX(sub_tree_height[parent_node], h);
//         }
//     }
//     free(sub_tree_size - 1);
//     free(stack);
//     free(kid_count_0);
//     free(sub_tree_height - 1);
//     return order;
// }

auto eq_reordering_1(const INDEX_TYPE n,
                     const INDEX_TYPE parent[],
                     const INDEX_TYPE values[],
                     const INDEX_TYPE threshold,
                     INDEX_TYPE *top_order,
                     INDEX_TYPE *order,
                     INDEX_TYPE *kid_count) {
    layer1_split = (INDEX_TYPE *) malloc((n + 1) * sizeof(INDEX_TYPE));
    layer1_split[layer1_num++] = 0;
    std::queue<INDEX_TYPE> big_queue;
    std::queue<INDEX_TYPE> small_queue;
    INDEX_TYPE *post = tree_postorder(n, parent);
    // exit(1);
    // 将所有叶子节点入栈或入队
    // for (INDEX_TYPE i = 0; i < n; i++) {
    for (INDEX_TYPE i = n - 1; i >= 0; i--) {
        INDEX_TYPE p = post[i];
        // p = i;
        if (kid_count[p] == 0) { // 叶子节点
            if (values[p] > threshold) {
                big_queue.push(p); // 加入大值队列
            } else {
                small_queue.push(p); // 入小值队列
            }
        }
    }
    std::cout << "layer_1:\t";
while_start:
    while (!small_queue.empty()) {
        INDEX_TYPE node = small_queue.front();
        small_queue.pop();
        //std::cout << values[node] << " ";
        order[(*top_order)++] = node;
        // 获取父节点，并减少其子节点数
        INDEX_TYPE parent_node = parent[node];
        kid_count[parent_node]--;
        // 如果父节点的子节点数为0，检查其值并入队
        while (parent_node > 0 && kid_count[parent_node] == 0) {
            if (values[parent_node] > threshold) {
                // std::cout << *top_order << ", ";
                layer1_split[layer1_num++] = *top_order;

                big_queue.push(parent_node); // 加入大值
                goto while_start;
                // break;
            }
            //std::cout << values[parent_node] << " ";
            order[(*top_order)++] = parent_node;
            parent_node = parent[parent_node];
            kid_count[parent_node]--;
        }
        if (values[parent_node] > threshold) { //如果父是割点
            // std::cout << *top_order << ", ";
            layer1_split[layer1_num++] = *top_order;
        }
    }
    std::cout << "\n";
    return big_queue;
}

void get_subtree_info(const INDEX_TYPE n,
                      const INDEX_TYPE *parent,
                      const INDEX_TYPE *kid_count_in,
                      const std::queue<INDEX_TYPE> &queue_in,
                      INDEX_TYPE *&sub_tree_size,
                      INDEX_TYPE *&sub_tree_height) {
    sub_tree_size = (INDEX_TYPE *) calloc(n + 1, sizeof(INDEX_TYPE));
    sub_tree_height = (INDEX_TYPE *) calloc(n + 1, sizeof(INDEX_TYPE));
    sub_tree_size++, sub_tree_height++;
    for (INDEX_TYPE i = 0; i < n; i++) {
        sub_tree_size[i] = 1;
        sub_tree_height[i] = 1;
    }
    std::queue<INDEX_TYPE> queue = queue_in;
    INDEX_TYPE *kid_count = (INDEX_TYPE *) malloc((n + 1) * sizeof(INDEX_TYPE));
    memcpy(kid_count, kid_count_in - 1, (n + 1) * sizeof(INDEX_TYPE));
    kid_count++;
    while (!queue.empty()) {
        INDEX_TYPE node = queue.front(); //dequeue
        queue.pop();
        // 获取父节点，并减少其子节点数
        INDEX_TYPE parent_node = parent[node];
        kid_count[parent_node]--;
        sub_tree_size[parent_node] += sub_tree_size[node];
        sub_tree_height[parent_node] = MAX(sub_tree_height[parent_node], sub_tree_height[node]);
        // 如果父节点的子节点数为0     numbering父节点
        while (parent_node > 0 && kid_count[parent_node] == 0) {
            sub_tree_height[parent_node]++;
            INDEX_TYPE s = sub_tree_size[parent_node];
            INDEX_TYPE h = sub_tree_height[parent_node];
            parent_node = parent[parent_node];
            kid_count[parent_node]--;
            sub_tree_size[parent_node] += s;
            sub_tree_height[parent_node] = MAX(sub_tree_height[parent_node], h);
        }
    }
    sub_tree_size--, sub_tree_height--;
    kid_count--;
    lu_free(kid_count);
}

auto eq_reordering_2_split(const INDEX_TYPE n,
                           const INDEX_TYPE parent[],
                           const INDEX_TYPE rate_threshold,
                           INDEX_TYPE &top_order,
                           INDEX_TYPE *order,
                           INDEX_TYPE *kid_count,
                           std::queue<INDEX_TYPE> &queue) {
    std::queue<INDEX_TYPE> r_queue;
    INDEX_TYPE *sub_tree_size = nullptr;
    INDEX_TYPE *sub_tree_height = nullptr;
    get_subtree_info(n, parent, kid_count, queue, sub_tree_size, sub_tree_height);
    sub_tree_size++, sub_tree_height++;

    printf("layer2:\t");
goto_while:
    while (!queue.empty()) {
        INDEX_TYPE node = queue.front(); //dequeue
        queue.pop();
        //printf("%lld ", node);
        order[top_order++] = node;
        // 获取父节点，并减少其子节点数
        INDEX_TYPE parent_node = parent[node];
        kid_count[parent_node]--;
        // 如果父节点的子节点数为0     numbering父节点
        while (parent_node > 0 && kid_count[parent_node] == 0) {
            sub_tree_height[parent_node]++;
            //割点
            if (sub_tree_size[parent_node] > n/3 &&
                sub_tree_height[parent_node] / sub_tree_size[parent_node] <= rate_threshold) {
                std::cout << top_order << ", ";
                layer2_split[layer2_num++] = top_order;

                r_queue.push(parent_node); //入队
                sub_tree_size[parent_node] = 1;
                sub_tree_height[parent_node] = 1;
                goto goto_while;
            }
            order[top_order++] = parent_node;
            parent_node = parent[parent_node];
            kid_count[parent_node]--;
        }
        if (sub_tree_size[parent_node] > n/3 &&
            sub_tree_height[parent_node] / sub_tree_size[parent_node] <= rate_threshold) {
            std::cout << top_order << ", ";
            layer2_split[layer2_num++] = top_order;
        }
    }
    printf("\n");
    free(sub_tree_size - 1);
    free(sub_tree_height - 1);
    return r_queue;
}

// ///废弃
// auto eq_reordering_2(const INDEX_TYPE n,
//                      const INDEX_TYPE parent[],
//                      const INDEX_TYPE rate_threshold,
//                      INDEX_TYPE &top_order,
//                      INDEX_TYPE *order,
//                      INDEX_TYPE *kid_count,
//                      std::queue<INDEX_TYPE> &queue) {
//     std::queue<INDEX_TYPE> r_queue;
//     INDEX_TYPE *sub_tree_size = (INDEX_TYPE *) calloc(n + 1, sizeof(INDEX_TYPE));
//     INDEX_TYPE *sub_tree_height = (INDEX_TYPE *) calloc(n + 1, sizeof(INDEX_TYPE));
//     sub_tree_size++, sub_tree_height++;
//     for (INDEX_TYPE i = 0; i < n; i++) {
//         sub_tree_size[i] = 1;
//         sub_tree_height[i] = 1;
//     }
//     printf("layer2:\t");
//     while (!queue.empty()) {
//         INDEX_TYPE node = queue.front(); //dequeue
//         queue.pop();
//         //printf("%lld ", node);
//         order[top_order++] = node;
//         // 获取父节点，并减少其子节点数
//         INDEX_TYPE parent_node = parent[node];
//         kid_count[parent_node]--;
//         sub_tree_size[parent_node] += sub_tree_size[node];
//         sub_tree_height[parent_node] = MAX(sub_tree_height[parent_node], sub_tree_height[node]);
//         // 如果父节点的子节点数为0     numbering父节点
//         while (parent_node > 0 && kid_count[parent_node] == 0) {
//             sub_tree_height[parent_node]++;
//             //割点
//             if (sub_tree_size[parent_node] > sqrt(n) * 1 &&
//                 sub_tree_height[parent_node] / sub_tree_size[parent_node] <= rate_threshold) {
//
//                 std::cout << top_order << ", ";
//
//                 r_queue.push(parent_node); //入队
//                 sub_tree_size[parent_node] = 1;
//                 sub_tree_height[parent_node] = 1;
//                 break;
//             }
//             order[top_order++] = parent_node;
//             INDEX_TYPE s = sub_tree_size[parent_node];
//             INDEX_TYPE h = sub_tree_height[parent_node];
//             parent_node = parent[parent_node];
//             kid_count[parent_node]--;
//             sub_tree_size[parent_node] += s;
//             sub_tree_height[parent_node] = MAX(sub_tree_height[parent_node], h);
//         }
//         if (sub_tree_size[parent_node] > sqrt(n) * 1 &&
//             sub_tree_height[parent_node] / sub_tree_size[parent_node] <= rate_threshold) {
//             std::cout << top_order << ", ";
//         }
//     }
//     printf("\n");
//     free(sub_tree_size - 1);
//     free(sub_tree_height - 1);
//     return r_queue;
// }

/**
 * @param parent 父亲表示法的森林
 * @param top_order order大小
 * @param order 拓扑序列
 * @param kid_count 节点的度
 * @param queue 度为0的节点
 */
void eq_reordering_3(const INDEX_TYPE parent[],
                     INDEX_TYPE *top_order,
                     INDEX_TYPE *order,
                     INDEX_TYPE *kid_count,
                     std::queue<INDEX_TYPE> &queue) {
    while (!queue.empty()) {
        INDEX_TYPE node = queue.front();
        queue.pop();
        order[(*top_order)++] = node;
        // 获取父节点，并减少其子节点数
        INDEX_TYPE parent_node = parent[node];
        kid_count[parent_node]--;
        // 如果父节点的子节点数为0
        while (parent_node > 0 && kid_count[parent_node] == 0) {
            order[(*top_order)++] = parent_node;
            parent_node = parent[parent_node];
            kid_count[parent_node]--;
        }
    }
}


INDEX_TYPE *eq_reordering_workflow(INDEX_TYPE n,
                                   const INDEX_TYPE parent[],
                                   INDEX_TYPE *cut_point1,INDEX_TYPE *cut_point2,
                                   INDEX_TYPE *row_wide,
                                   INDEX_TYPE threshold) {
    double start_time = omp_get_wtime();
    //-------------------------初始化-------------------------
    INDEX_TYPE *order = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    INDEX_TYPE *etree_height_r2l = (INDEX_TYPE *) lu_calloc(n + 1, sizeof(INDEX_TYPE));
    etree_height_r2l++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        etree_height_r2l[v] = etree_height_r2l[parent[v]] + 1;
    }
    INDEX_TYPE *kid_count = (INDEX_TYPE *) lu_calloc(n + 1, sizeof(INDEX_TYPE));
    kid_count++;
    // 计算每个节点的子节点数
    for (INDEX_TYPE i = 0; i < n; kid_count[parent[i++]]++);
    INDEX_TYPE top_order = 0;
    //-------------------------end 初始化-------------------------

    auto big_queue = eq_reordering_1(n, parent, row_wide, threshold, &top_order, order, kid_count);
    *cut_point1 = top_order;
    LOG_DEBUG("cut_point1:%lld", top_order);
    layer2_split = (INDEX_TYPE *) malloc((n + 1) * sizeof(INDEX_TYPE));
    layer2_split[layer2_num++] = *cut_point1;
    auto r_queue = eq_reordering_2_split(n, parent, 1.6, top_order, order, kid_count, big_queue);
    // return order;
    *cut_point2 = top_order;
    LOG_DEBUG("cut_point2:%lld", top_order);
    eq_reordering_3(parent, &top_order, order, kid_count, r_queue);
    free(kid_count - 1);
    free(etree_height_r2l - 1);
    LOG_TIME("eq_reordering_workflow elapsed time: %lf ms", (omp_get_wtime() - start_time) * 1000.0);
    return order;
}


INDEX_TYPE *eq_reordering(CSRMatrix *A, INDEX_TYPE n, INDEX_TYPE *cut_point1,INDEX_TYPE *cut_point2,
                          INDEX_TYPE *parent) {
    clock_t start_time = clock();
    //-----------------------------etree--------------------------------
    INDEX_TYPE *b_ptr, *b_idx;
    INDEX_TYPE bnz = A->nnz * 2;
    a_plus_at(n, A->nnz, A->row_pointers, A->col_indices, &bnz, &b_ptr, &b_idx);
    LOG_TIME("a_plus_at elapsed time: %lf ms", ((double) (clock() - start_time)) / CLOCKS_PER_SEC * 1000.0);
    LOG_DEBUG("a_plus_at nnz : %lld", bnz);
    LOG_DEBUG("a nnz : %lld", A->nnz-n);
    sym_etree(b_ptr, b_ptr + 1, b_idx, n, parent);
    lu_free(b_ptr);
    lu_free(b_idx);
    //-----------------------------end etree--------------------------------

    INDEX_TYPE *row_wide = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    calc_row_wide(A->row_pointers, A->col_indices, row_wide, n);
    INDEX_TYPE threshold = calc_threshold(n, bnz);
    LOG_DEBUG("threshold: %lld", threshold);
    INDEX_TYPE *order = eq_reordering_workflow(n, parent, cut_point1, cut_point2, row_wide, threshold);
    // order=eq_order(n,parent,10);
    INDEX_TYPE *iorder = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    for (int i = 0; i < n; ++i) {
        iorder[order[i]] = i;
    }
    lu_free(order);
    lu_free(row_wide);
    LOG_TIME("reorder_toposort elapsed time: %lf ms", ((double) (clock() - start_time)) / CLOCKS_PER_SEC * 1000.0);
    return iorder;
}

INDEX_TYPE *eq_reordering_v2(CSRMatrix *A, INDEX_TYPE n,
                             INDEX_TYPE *cut_point1,INDEX_TYPE *cut_point2,
                             INDEX_TYPE *parent,
                             INDEX_TYPE **layer2_split_out, INDEX_TYPE *layer2_num_out,
                             INDEX_TYPE **layer1_split_out, INDEX_TYPE *layer1_num_out) {
    clock_t start_time = clock();
    //-----------------------------etree--------------------------------
    INDEX_TYPE *b_ptr, *b_idx;
    INDEX_TYPE bnz = A->nnz * 2;
    a_plus_at(n, A->nnz, A->row_pointers, A->col_indices, &bnz, &b_ptr, &b_idx);
    LOG_TIME("a_plus_at elapsed time: %lf ms", ((double) (clock() - start_time)) / CLOCKS_PER_SEC * 1000.0);
    LOG_DEBUG("a_plus_at nnz : %lld", bnz);
    LOG_DEBUG("a nnz : %lld", A->nnz-n);
    sym_etree(b_ptr, b_ptr + 1, b_idx, n, parent);
    lu_free(b_ptr);
    lu_free(b_idx);
    //-----------------------------end etree--------------------------------

    INDEX_TYPE *row_wide = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    calc_row_wide(A->row_pointers, A->col_indices, row_wide, n);
    INDEX_TYPE threshold = calc_threshold(n, A->nnz);
    LOG_DEBUG("threshold: %lld", threshold);
    INDEX_TYPE *order = eq_reordering_workflow(n, parent, cut_point1, cut_point2, row_wide, threshold);
    // order=eq_order(n,parent,10);
    INDEX_TYPE *iorder = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    for (int i = 0; i < n; ++i) {
        iorder[order[i]] = i;
    }
    lu_free(order);
    lu_free(row_wide);
    LOG_TIME("reorder_toposort elapsed time: %lf ms", ((double) (clock() - start_time)) / CLOCKS_PER_SEC * 1000.0);

    *layer2_split_out = layer2_split;
    *layer2_num_out = layer2_num - 1;
    *layer1_split_out = layer1_split;
    *layer1_num_out = layer1_num - 1;
    return iorder;
}
