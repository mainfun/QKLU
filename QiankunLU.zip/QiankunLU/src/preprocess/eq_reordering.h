//
// Created by mainf on 2024/11/28.
//

#ifndef TOPOSORT_H
#define TOPOSORT_H

#ifdef __cplusplus
extern "C" {
#endif

#include <base/matrix.h>
INDEX_TYPE *eq_reordering(CSRMatrix *Ap, INDEX_TYPE n,
                          INDEX_TYPE *cut_point1, INDEX_TYPE *cut_point2,
                          INDEX_TYPE *etree);

INDEX_TYPE *eq_reordering_v2(CSRMatrix *A, INDEX_TYPE n,
                             INDEX_TYPE *cut_point1,INDEX_TYPE *cut_point2,
                             INDEX_TYPE *parent,
                             INDEX_TYPE **layer2_split_out, INDEX_TYPE *layer2_num_out,
                             INDEX_TYPE **layer1_split_out,INDEX_TYPE *layer1_num_out);

#ifdef __cplusplus
}
#endif

#endif //TOPOSORT_H
