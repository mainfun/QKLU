//
// Created by mainf on 2024/5/6.
//
#ifndef QKLU_SYMBOLIC_ANALYSIS_H
#define QKLU_SYMBOLIC_ANALYSIS_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdlib.h>
#include "base/malloc.h"
#include "base/matrix.h"
#include "preprocess/preprocess.h"

void symbolic_analysis(INDEX_TYPE *Ap, INDEX_TYPE *Ai, INDEX_TYPE n, INDEX_TYPE nnz,
                       PreprocessInfo *info);

/**
 * 非对称符合分析
 */
void fill_in_2_no_sort_pruneL(INDEX_TYPE n, INDEX_TYPE nnz,
                              INDEX_TYPE *ai, INDEX_TYPE *ap,
                              INDEX_TYPE **L_rowpointer, INDEX_TYPE **L_columnindex,
                              INDEX_TYPE **U_rowpointer, INDEX_TYPE **U_columnindex);

void get_l_col_patterns_naive(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE n, const INDEX_TYPE *etree,
                              INDEX_TYPE *Lp, INDEX_TYPE *Li,
                              INDEX_TYPE cut_point1,INDEX_TYPE cut_point2);

void get_u_row_patterns_naive(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE n, const INDEX_TYPE *etree,
                              INDEX_TYPE **outUp, INDEX_TYPE **outUi,
                              INDEX_TYPE cut_point1,INDEX_TYPE cut_point2);

void get_l_col_patterns_parallel(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                                 const INDEX_TYPE n, const INDEX_TYPE *etree,
                                 INDEX_TYPE *Lp, INDEX_TYPE *Li,
                                 INDEX_TYPE cut_point1,INDEX_TYPE cut_point2,
                                 INDEX_TYPE split_points_num, INDEX_TYPE *split_points);

void get_u_row_patterns_block(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE n, const INDEX_TYPE *etree,
                              INDEX_TYPE **outUp_11, INDEX_TYPE **outUi_11,
                              INDEX_TYPE **outUp_12, INDEX_TYPE **outUi_12,
                              INDEX_TYPE cut_point1,INDEX_TYPE cut_point2);

/**
 * 对称矩阵
 */
INDEX_TYPE calc_l_nz(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                     const INDEX_TYPE parent[],
                     const INDEX_TYPE n, const INDEX_TYPE cut_point);

INDEX_TYPE calc_l_nz_v2(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                        const INDEX_TYPE parent[],
                        const INDEX_TYPE n, const INDEX_TYPE cut_point,
                        const INDEX_TYPE *ap, const INDEX_TYPE *ai);

void get_l_col_patterns_block(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE n, const INDEX_TYPE *etree,
                              INDEX_TYPE *Lp_11, INDEX_TYPE *Li_11,
                              INDEX_TYPE *Lp_21, INDEX_TYPE *Li_21,
                              INDEX_TYPE cut_point1,INDEX_TYPE cut_point2);

void get_l_row_patterns_naive(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE parent[],
                              const INDEX_TYPE n,
                              const INDEX_TYPE cut_point,
                              INDEX_TYPE **outLp, INDEX_TYPE **outLi);

/**
 * 估计乘加的计算个数
 * @param n dim
 * @param Lp CSR L
 * @param Li CSR L
 * @param Up CSR U
 * @return
 */
long long compute_fma_count(INDEX_TYPE n,
                            const INDEX_TYPE *Lp,
                            const INDEX_TYPE *Li,
                            const INDEX_TYPE *Up);

void symbolic_analysis_block(const INDEX_TYPE *etree,
                             const CSRMatrix *A,
                             const PreprocessInfo *info,
                             CSRMatrix *U11, CSRMatrix *U12,
                             CSRMatrix *L11, CSRMatrix *L21);

#ifdef __cplusplus
}
#endif
#endif //QKLU_SYMBOLIC_ANALYSIS_H
