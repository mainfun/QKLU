//
// Created by mainf on 2024/11/28.
//

#ifndef TOPOSORT_H
#define TOPOSORT_H

#ifdef __cplusplus
extern "C" {
#endif
#include <base/matrix.h>

INDEX_TYPE *eq_reordering(CSRMatrix *A, INDEX_TYPE n, INDEX_TYPE *cut_point1,INDEX_TYPE *cut_point2);

#ifdef __cplusplus
}
#endif

#endif //TOPOSORT_H
