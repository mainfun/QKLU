//
// Created by mainf on 2024/4/15.
//

#ifndef QKLU_REORDER_H
#define QKLU_REORDER_H

#include "base/matrix.h"
#include "base/malloc.h"
#include "symbolic_analysis.h"
#include "preprocess.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * AMD重排序
 * @param matrix
 * @param preprocess_info 符号计算信息
 */
void reorder_csr_amd(const CSRMatrix *matrix, PreprocessInfo *preprocess_info);

void reorder_csr_metis(const CSRMatrix *matrix, PreprocessInfo *preprocess_info);

/**
 * 多种重排序
 */
CSRMatrix *reordering(CSRMatrix *matrix, PreprocessInfo *info,bool is_static_pivoting, bool is_reorder);

CSRMatrix *reordering_small_matrix(CSRMatrix *matrix, PreprocessInfo *info, bool is_static_pivoting, bool is_reorder);

void row_permute(CSRMatrix *A, CSRMatrix *R, const INDEX_TYPE perm[],
                 const ELE_TYPE row_scale[], const ELE_TYPE col_scale[]);

#ifdef __cplusplus
}
#endif

#endif //QKLU_REORDER_H
