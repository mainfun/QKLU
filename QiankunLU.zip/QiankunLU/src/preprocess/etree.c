//
// Created by mainf on 2024/11/28.
//

#include "etree.h"


///支持无序
INDEX_TYPE *create_etree_csr(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai, INDEX_TYPE n) {
    INDEX_TYPE *parent = lu_malloc(sizeof(INDEX_TYPE) * n);
    INDEX_TYPE *ancestor = lu_malloc(sizeof(INDEX_TYPE) * n);
    INDEX_TYPE root;
    for (INDEX_TYPE r = 0; r < n; ++r) {
        ancestor[r] = -1;
        for (INDEX_TYPE j = Ap[r]; j < Ap[r + 1]; ++j) {
            INDEX_TYPE c = Ai[j];
            if (c >= r) continue;
            root = c;
            // 如果有祖先，并且祖先不是本节点，设置祖先为本节点。
            // 例如：8找到1，7，且有ancestor[1] = 7。
            // 修改为ancestor[1] = 8;root=7;
            while (ancestor[root] != -1 && ancestor[root] != r) {
                INDEX_TYPE l = ancestor[root];
                ancestor[root] = r;
                root = l;
            }
            //ancestor[7] = 8;
            //parent[7] = 8;
            if (ancestor[root] == -1) {
                ancestor[root] = r;
                //添加
                parent[root] = r;
            }
        }
    }
    lu_free(ancestor);
    return parent;
}

///支持无序
INDEX_TYPE *create_etree(CSRMatrix *csr_mat) {
    INDEX_TYPE n = csr_mat->num_row;
    INDEX_TYPE *parent = lu_malloc(sizeof(INDEX_TYPE) * n);
    INDEX_TYPE *ancestor = lu_malloc(sizeof(INDEX_TYPE) * n);
    INDEX_TYPE root;
    for (INDEX_TYPE r = 0; r < n; ++r) {
        ancestor[r] = -1;
        for (INDEX_TYPE j = csr_mat->row_pointers[r]; j < csr_mat->row_pointers[r + 1]; ++j) {
            INDEX_TYPE c = csr_mat->col_indices[j];
            if (c >= r) continue;
            root = c;
            // 如果有祖先，并且祖先不是本节点，设置祖先为本节点。
            // 例如：8找到1，7，且有ancestor[1] = 7。
            // 修改为ancestor[1] = 8;root=7;
            while (ancestor[root] != -1 && ancestor[root] != r) {
                INDEX_TYPE l = ancestor[root];
                ancestor[root] = r;
                root = l;
            }
            //ancestor[7] = 8;
            //parent[7] = 8;
            if (ancestor[root] == -1) {
                ancestor[root] = r;
                //添加
                parent[root] = r;
            }
        }
    }
    lu_free(ancestor);
    return parent;
}

///支持无序
INDEX_TYPE *create_etree_force2sym(CSRMatrix *A) {
    INDEX_TYPE *b_ptr, *b_idx;
    INDEX_TYPE bnz = A->nnz * 2;
    a_plus_at(A->num_col, A->nnz, A->row_pointers, A->col_indices, &bnz, &b_ptr, &b_idx);
    INDEX_TYPE *etree = lu_malloc(A->num_col * sizeof(INDEX_TYPE));
    sym_etree(b_ptr, b_ptr + 1, b_idx, A->num_col, etree);
    // INDEX_TYPE *etree = create_etree_csr(b_ptr, b_idx, A->num_col);
    lu_free(b_ptr);
    lu_free(b_idx);
    return etree;
}


static
INDEX_TYPE make_set(
    INDEX_TYPE i,
    INDEX_TYPE *pp
) {
    pp[i] = i;
    return i;
}


static
INDEX_TYPE link(
    INDEX_TYPE s,
    INDEX_TYPE t,
    INDEX_TYPE *pp
) {
    pp[s] = t;
    return t;
}


static INDEX_TYPE find(INDEX_TYPE i, INDEX_TYPE *pp) {
    INDEX_TYPE p, gp;

    p = pp[i];
    gp = pp[p];
    while (gp != p) {
        pp[i] = gp;
        i = gp;
        p = pp[i];
        gp = pp[p];
    }
    return (p);
}

///跟节点是-1
INDEX_TYPE sym_etree(
    INDEX_TYPE *acolst, INDEX_TYPE *acolend,
    INDEX_TYPE *arow,
    INDEX_TYPE n,
    INDEX_TYPE *parent) {
    INDEX_TYPE *root;
    INDEX_TYPE rset, cset;
    INDEX_TYPE row, col;
    INDEX_TYPE rroot;
    INDEX_TYPE p;
    INDEX_TYPE *pp;

    root = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    pp = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));

    for (col = 0; col < n; col++) {
        cset = make_set(col, pp);
        root[cset] = col;
        parent[col] = -1;
        for (p = acolst[col]; p < acolend[col]; p++) {
            row = arow[p];
            if (row >= col) continue;
            rset = find(row, pp);
            rroot = root[rset];
            if (rroot != col) {
                parent[rroot] = col;
                cset = link(cset, rset, pp);
                root[cset] = col;
            }
        }
    }
    lu_free(root);
    lu_free(pp);
    return 0;
}

void etree_dfs(INDEX_TYPE n, const INDEX_TYPE *parent,
               const INDEX_TYPE *first_kid, const INDEX_TYPE *next_kid,
               INDEX_TYPE *post, INDEX_TYPE post_num) {
    INDEX_TYPE current = -1;
    while (post_num != n) {
        INDEX_TYPE first = first_kid[current];
        //直到找到叶子，如果current是叶子
        if (first == -1) {
            //numbering叶子
            post[post_num++] = current;

            //叶子的兄弟
            INDEX_TYPE next = next_kid[current];
            //如果没有兄弟
            while (next == -1 && current != -1) {
                //没有兄弟就numbering父节点
                current = parent[current];
                post[post_num++] = current;
                //父节点的兄弟
                next = next_kid[current];
            }
            if (post_num > n) return;
            //如果有兄弟
            current = next;
        } else {
            //一直找到叶子
            current = first;
        }
    }
}


INDEX_TYPE *tree_postorder(const INDEX_TYPE n, const INDEX_TYPE *parent) {
    INDEX_TYPE *first_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *post = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = -1; v < n; v++) {
        next_kid[v] = -1;
        first_kid[v] = -1;
    }

    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = parent[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }

    INDEX_TYPE post_num = 0;
    etree_dfs(n, parent, first_kid, next_kid, post, post_num);

    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    return post;
}
