//
// Created by mainf on 2024/11/28.
//

#ifndef ETREE_H
#define ETREE_H

#ifdef __cplusplus
extern "C" {
#endif
// #include <stdio.h>
#include <stdlib.h>
#include <base/malloc.h>
#include <base/matrix.h>

/**
 * Symmetric elimination tree
 **/
INDEX_TYPE sym_etree(
    INDEX_TYPE *acolst,
    INDEX_TYPE *acolend, /* column starts and ends past 1 */
    INDEX_TYPE *arow, /* row indices of A */
    INDEX_TYPE n, /* dimension of A */
    INDEX_TYPE *parent /* parent in elim tree */
);

/**
 * 只能对称矩阵操作。支持idx无序。
 * @param csr_mat CSR矩阵的结构信息
 * @return 双亲表示法的列消元树
 */
INDEX_TYPE *create_etree(CSRMatrix *csr_mat);

/**
 * 强制把矩阵根据A+AT变成对称矩阵。生成etree。
 * @param A CSR矩阵的结构信息
 * @return 双亲表示法的列消元树
 */
INDEX_TYPE *create_etree_force2sym(CSRMatrix *A);

INDEX_TYPE *tree_postorder(const INDEX_TYPE n, const INDEX_TYPE *parent);

#ifdef __cplusplus
}
#endif

#endif //ETREE_H
