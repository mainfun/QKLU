//
// Created by mainf on 2024/8/16.
//

#include "preprocess.h"

#include <base/base_math.h>
#include <base/parse_args.h>

#include "pivoting.h"
#include "base/file.h"

extern Config config;

PreprocessInfo *init_preprocess_info() {
    PreprocessInfo *info = (PreprocessInfo *) lu_calloc(1, sizeof(PreprocessInfo));
    return info;
}

void free_preprocess_info(PreprocessInfo *info) {
    lu_free(info->etree);
    free_csr_matrix(info->L);
    free_csr_matrix(info->U);
    free_csr_matrix(info->pattern);

    lu_free(info->mc64_iperm);
    lu_free(info->mc64_perm);
    lu_free(info->reorder_iperm);
    lu_free(info->reorder_perm);
    lu_free(info->Dc);
    lu_free(info->Dr);
    lu_free(info);
}

INDEX_TYPE *L_max_row_idx(const INDEX_TYPE *Lp, const INDEX_TYPE *Li,INDEX_TYPE n) {
    INDEX_TYPE *max_idx = (INDEX_TYPE *) malloc(n * sizeof(INDEX_TYPE));
    for (INDEX_TYPE i = 0; i < n; ++i) {
        INDEX_TYPE max = i;
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            max = MAX(max, Li[j]);
        }
        max_idx[i] = max;
    }
    return max_idx;
}

///A CSR结构
///用于计算A+A^T的min_row_idx，同时也是L的min_row_idx
INDEX_TYPE *A_min_row_idx(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,INDEX_TYPE n) {
    INDEX_TYPE *min_row = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    for (INDEX_TYPE j = 0; j < n; ++j) {
        min_row[j] = j; //最小在对角线上
    }
    for (INDEX_TYPE i = n - 1; i >= 0; --i) {
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE col = Ai[j];
            min_row[col] = i; //自下到上扫描，小的自动覆盖大的
        }
    }
    return min_row;
}
