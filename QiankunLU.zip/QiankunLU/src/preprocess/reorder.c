//
// Created by mainf on 2024/4/15.
//
#include "reorder.h"
#include <amd.h>
// #include <colamd.h>
#include <metis.h>
#include <omp.h>
#include <base/matrix_util.h>

#include "pivoting.h"
#include "base/sort.h"
#include "preprocess/symbolic_analysis.h"
#include "preprocess/eq_reordering.h"
extern double start_time;
void apply_permutation(const CSRMatrix *A, CSRMatrix *R, const INDEX_TYPE iperm[]) {
    const clock_t start_time = clock();
    const INDEX_TYPE *Ap = A->row_pointers;
    const INDEX_TYPE *Ai = A->col_indices;
    const ELE_TYPE *Ax = A->csr_values;
    const INDEX_TYPE n = A->num_row;

    //求PAP^T
    //计算Rp
    for (INDEX_TYPE i = 0; i < n; i++) {
        const INDEX_TYPE row_num = Ap[i + 1] - Ap[i];
        R->row_pointers[iperm[i] + 1] = row_num;
    }
    R->row_pointers[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        R->row_pointers[i + 1] += R->row_pointers[i];
    }
    //计算Ri Rx
    for (INDEX_TYPE i = 0; i < n; i++) {
        const INDEX_TYPE r = iperm[i];
        const INDEX_TYPE r_start = R->row_pointers[r];
        const INDEX_TYPE r_end = R->row_pointers[r + 1];
        INDEX_TYPE a_index = Ap[i];
        for (INDEX_TYPE j = r_start; j < r_end; j++) {
            R->col_indices[j] = iperm[Ai[a_index]];
            R->csr_values[j] = Ax[a_index++];
        }
        const INDEX_TYPE num = r_end - r_start;
        //todo 排序优化
        sort_sparse_matrix(R->col_indices + r_start, R->csr_values + r_start, num);
    }
    LOG_TIME("reordering apply permutation elapsed time: %lf ms",
             ((double) (clock() - start_time)) / CLOCKS_PER_SEC * 1000.0);
}

void reorder_csr_amd(const CSRMatrix *matrix, PreprocessInfo *preprocess_info) {
    clock_t start_time = clock();
    if (matrix == NULL)
        LOG_ERROR("matrix is NULL");
    const INDEX_TYPE n = matrix->num_row;
    const INDEX_TYPE *Ap = matrix->row_pointers;
    const INDEX_TYPE *Ai = matrix->col_indices;
    INDEX_TYPE *perm = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE *iperm = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    // 调用AMD进行重排序
    double Info[AMD_INFO];
    INDEX_TYPE status;
    // 设置 Control 参数
    // double control[2];
    // control[0] = 100;         // 默认，设置稠密行/列的阈值
    // control[1] = 1;     // 启用激进吸收（默认）

    if (sizeof(INDEX_TYPE) == sizeof(double)) {
        status = amd_l_order(n, (int64_t *) Ap, (int64_t *) Ai, (int64_t *) perm, NULL, Info);
    } else {
        status = amd_order((int) n, (int *) Ap, (int *) Ai, (int *) perm, NULL, Info);
    }
    //转置矩阵
    for (int i = 0; i < n; ++i) {
        iperm[perm[i]] = i;
    }
    if (status == AMD_OK) {
        LOG_DEBUG("AMD ordering succeeded!\n");
    } else {
        LOG_DEBUG("AMD ordering failed! Status code: %lld\n", status);
        if (Info[AMD_STATUS] == AMD_INVALID) {
            LOG_ERROR("AMD ordering: Invalid matrix (jumbled or duplicate entries or wrong dimensions)\n");
        } else if (Info[AMD_STATUS] == AMD_OUT_OF_MEMORY) {
            LOG_ERROR("AMD ordering: Out of memory\n");
        } else {
            LOG_ERROR("AMD ordering: Unknown failure\n");
        }
    }
    amd_l_info(Info);
    // preprocess_info->max_nz = Info[AMD_LNZ];
    preprocess_info->reorder_perm = perm;
    preprocess_info->reorder_iperm = iperm;
    LOG_DEBUG("L max_nz:%f .exclude dialog\n", Info[AMD_LNZ]);
    LOG_TIME("AMD reorder elapsed time: %lf ms", ((double) (clock() - start_time)) / CLOCKS_PER_SEC * 1000.0);
}

void reorder_csr_metis(const CSRMatrix *matrix, PreprocessInfo *preprocess_info) {
    clock_t start_time = clock();
    if (matrix == NULL)
        LOG_ERROR("matrix is NULL");
    long n = matrix->num_row;
    const INDEX_TYPE *Ap = matrix->row_pointers;
    const INDEX_TYPE *Ai = matrix->col_indices;
    INDEX_TYPE *perm = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE *iperm = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    preprocess_info->reorder_perm = perm;
    preprocess_info->reorder_iperm = iperm;
    INDEX_TYPE bnz = 0;
    INDEX_TYPE *Bp;
    INDEX_TYPE *Bi;
    a_plus_at(n, matrix->nnz, Ap, Ai, &bnz, &Bp, &Bi);
    int status = METIS_NodeND(&n, (long *) Bp, (long *) Bi, NULL, NULL, (long *) perm, (long *) iperm);
    if (status != METIS_OK) {
        LOG_ERROR("Error in METIS_NodeND: %d\n", status);
    } else {
        LOG_DEBUG("metis reordering completed successfully.");
    }
    lu_free(Bp);
    lu_free(Bi);
    LOG_TIME("metis reorder elapsed time: %lf ms", ((double) (clock() - start_time)) / CLOCKS_PER_SEC * 1000.0);
}

INDEX_TYPE *reorder_metis64(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                            long n,INDEX_TYPE nnz, PreprocessInfo *preprocess_info) {
    clock_t start_time = clock();
    INDEX_TYPE *perm = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE *iperm = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
    preprocess_info->reorder_perm = perm;
    preprocess_info->reorder_iperm = iperm;
    INDEX_TYPE bnz = 0;
    INDEX_TYPE *Bp;
    INDEX_TYPE *Bi;
    a_plus_at(n, nnz, Ap, Ai, &bnz, &Bp, &Bi);
    int status = METIS_NodeND(&n, (long *) Bp, (long *) Bi, NULL, NULL, (long *) perm, (long *) iperm);
    if (status != METIS_OK) {
        LOG_ERROR("Error in METIS_NodeND: %d\n", status);
    } else {
        LOG_DEBUG("metis reordering completed successfully.");
    }
    lu_free(Bp);
    lu_free(Bi);
    LOG_TIME("metis reorder elapsed time: %lf ms", ((double) (clock() - start_time)) / CLOCKS_PER_SEC * 1000.0);
    return perm;
}

///CSR:R=perm*A
///CSC:R=A*perm
void row_permute(CSRMatrix *A, CSRMatrix *R,
                 const INDEX_TYPE perm[],
                 const ELE_TYPE row_scale[], const ELE_TYPE col_scale[]) {
    double time = omp_get_wtime();
    INDEX_TYPE *Ap = A->row_pointers;
    INDEX_TYPE *Ai = A->col_indices;
    ELE_TYPE *Ax = A->csr_values;
    INDEX_TYPE n = A->num_row;
    //求PAP^T
    //计算Rp
    for (INDEX_TYPE i = 0; i < n; i++) {
        INDEX_TYPE row_num = Ap[i + 1] - Ap[i];
        R->row_pointers[perm[i] + 1] = row_num;
    }
    R->row_pointers[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        R->row_pointers[i + 1] += R->row_pointers[i];
    }
    for (INDEX_TYPE i = 0; i < n; i++) {
        INDEX_TYPE row = perm[i];
        ELE_TYPE rs = row_scale[i];
        INDEX_TYPE tmp_index = R->row_pointers[row];
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; j++) {
            INDEX_TYPE col = Ai[j];
            R->col_indices[tmp_index] = col;
            R->csr_values[tmp_index++] = Ax[j] * rs * col_scale[col];
        }
    }
    LOG_TIME("row_permute elapsed time: %lf ms", (omp_get_wtime() - time)* 1000.0);
}

void apply_pivoting_csc(CSC *A, CSC *R,
                        const INDEX_TYPE perm[],
                        const ELE_TYPE row_scale[], const ELE_TYPE col_scale[]) {
    INDEX_TYPE *Ap = A->col_ptr;
    INDEX_TYPE *Ai = A->row_idx;
    ELE_TYPE *Ax = A->values;
    INDEX_TYPE n = A->num_row;
    //求PAP^T
    //计算Rp
    for (INDEX_TYPE i = 0; i < n; i++) {
        INDEX_TYPE row_num = Ap[i + 1] - Ap[i];
        R->col_ptr[perm[i] + 1] = row_num;
    }
    R->col_ptr[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        R->col_ptr[i + 1] += R->col_ptr[i];
    }
    for (INDEX_TYPE i = 0; i < n; i++) {
        INDEX_TYPE row = perm[i];
        ELE_TYPE rs = row_scale[i];
        INDEX_TYPE tmp_index = R->col_ptr[row];
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; j++) {
            INDEX_TYPE col = Ai[j];
            R->row_idx[tmp_index] = col;
            R->values[tmp_index++] = Ax[j] * rs * col_scale[col];
        }
    }
}


CSRMatrix *reordering(CSRMatrix *matrix, PreprocessInfo *info, bool is_static_pivoting, bool is_reorder) {
    clock_t preprocess_time = clock();
    INDEX_TYPE n = matrix->num_row;
    INDEX_TYPE nnz = matrix->nnz;
    info->etree = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    info->etree[0] = 0;
    /**
     * 1.MC64 matrix->tmp_matrix
     */
    CSRMatrix *tmp_matrix;
    if (is_static_pivoting) {
        INDEX_TYPE *perm = NULL;
        INDEX_TYPE *iperm = NULL;
        ELE_TYPE *row_scale = NULL;
        ELE_TYPE *col_scale = NULL;
        static_pivoting(matrix, &perm, &iperm, &row_scale, &col_scale);
        tmp_matrix = init_csr_matrix(n, n, nnz);
        row_permute(matrix, tmp_matrix, perm, row_scale, col_scale);
        // LOG_DEBUG();
        // print_dense_matrix(csr2dense(tmp_matrix), n);
        info->mc64_perm = perm;
        info->mc64_iperm = iperm;
        info->Dr = row_scale;
        info->Dc = col_scale;
    } else {
        tmp_matrix = matrix;
    }
    /**
     * 2.重排序 tmp_matrix->A
     */
    CSRMatrix *A = init_csr_matrix(n, n, nnz);
    if (is_reorder) {
        reorder_csr_metis(tmp_matrix, info);
        /**----------------------toposort------------------ -------**/
        if (1) {
            CSRMatrix *temp2 = init_csr_matrix(n, n, A->nnz);
            apply_permutation(tmp_matrix, temp2, info->reorder_iperm);
            start_time = omp_get_wtime();
            // INDEX_TYPE *toposort_iperm = eq_reordering(temp2, n, &info->cut_point1, &info->cut_point2, info->etree + 1);
            INDEX_TYPE *toposort_iperm = eq_reordering_v2(temp2, n,
                                                          &info->cut_point1, &info->cut_point2,
                                                          info->etree + 1,
                                                          &info->layer2_splits,
                                                          &info->layer2_splits_num,
                                                          &(info->layer1_splits),
                                                          &info->layer1_splits_num);

            apply_permutation(temp2, A, toposort_iperm);
            free_csr_matrix(temp2);

            INDEX_TYPE *ir = (INDEX_TYPE *) lu_malloc(A->num_row * sizeof(INDEX_TYPE));;
            multiply_perm(info->reorder_iperm, toposort_iperm, ir, n);
            lu_free(toposort_iperm);
            lu_free(info->reorder_iperm);
            info->reorder_iperm = ir;
            INDEX_TYPE *r = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
            for (int i = 0; i < n; ++i) {
                r[ir[i]] = i;
            }
            info->reorder_perm = r;
        } else {
            apply_permutation(tmp_matrix, A, info->reorder_iperm);
            info->cut_point1 = n;
        }
        /**---------------------------------------------------------------------------**/
        if (is_static_pivoting) {
            free_csr_matrix(tmp_matrix);
        }
    } else {
        A = tmp_matrix;
    }

    LOG_TIME("reordering elapsed time: %lf ms", ((double) (clock() - preprocess_time)) / CLOCKS_PER_SEC * 1000.0);
    return A;
}


CSRMatrix *reordering_small_matrix(CSRMatrix *matrix, PreprocessInfo *info, bool is_static_pivoting, bool is_reorder) {
    clock_t preprocess_time = clock();
    INDEX_TYPE n = matrix->num_row;
    INDEX_TYPE nnz = matrix->nnz;
    info->etree = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    info->etree[0] = 0;
    /**
     * 1.MC64 matrix->tmp_matrix
     */
    CSRMatrix *tmp_matrix;
    if (is_static_pivoting) {
        INDEX_TYPE *perm = NULL;
        INDEX_TYPE *iperm = NULL;
        ELE_TYPE *row_scale = NULL;
        ELE_TYPE *col_scale = NULL;
        static_pivoting(matrix, &perm, &iperm, &row_scale, &col_scale);
        tmp_matrix = init_csr_matrix(n, n, nnz);
        row_permute(matrix, tmp_matrix, perm, row_scale, col_scale);
        // LOG_DEBUG();
        // print_dense_matrix(csr2dense(tmp_matrix), n);
        info->mc64_perm = perm;
        info->mc64_iperm = iperm;
        info->Dr = row_scale;
        info->Dc = col_scale;
    } else {
        tmp_matrix = matrix;
    }
    /**
     * 2.重排序 tmp_matrix->A
     */
    CSRMatrix *A = init_csr_matrix(n, n, nnz);
    if (is_reorder) {
        reorder_csr_amd(tmp_matrix, info);
        /**----------------------toposort------------------ -------**/
        if (0) {
            CSRMatrix *temp2 = init_csr_matrix(n, n, A->nnz);
            apply_permutation(tmp_matrix, temp2, info->reorder_iperm);
            INDEX_TYPE *toposort_iperm = eq_reordering(temp2, n, &info->cut_point1, &info->cut_point2, info->etree + 1);
            apply_permutation(temp2, A, toposort_iperm);
            free_csr_matrix(temp2);

            INDEX_TYPE *ir = (INDEX_TYPE *) lu_malloc(A->num_row * sizeof(INDEX_TYPE));;
            multiply_perm(info->reorder_iperm, toposort_iperm, ir, n);
            lu_free(toposort_iperm);
            lu_free(info->reorder_iperm);
            info->reorder_iperm = ir;
            INDEX_TYPE *r = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));
            for (int i = 0; i < n; ++i) {
                r[ir[i]] = i;
            }
            info->reorder_perm = r;
        } else {
            apply_permutation(tmp_matrix, A, info->reorder_iperm);
            info->cut_point1 = n;
        }
        /**---------------------------------------------------------------------------**/
        if (is_static_pivoting) {
            free_csr_matrix(tmp_matrix);
        }
    } else {
        A = tmp_matrix;
    }

    LOG_TIME("reordering elapsed time: %lf ms", ((double) (clock() - preprocess_time)) / CLOCKS_PER_SEC * 1000.0);
    return A;
}
