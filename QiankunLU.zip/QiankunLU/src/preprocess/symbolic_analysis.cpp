//
// Created by mainf on 2024/5/6.
//
#include <algorithm>
#include "symbolic_analysis.h"

#include <omp.h>
#include <base/base_math.h>
#include <base/matrix_util.h>

#include "preprocess.h"
#include "base/matrix.h"
// #include <ips2ra.hpp>
// #include <ips4o/ips4o.hpp>
#ifdef __x86_64__
  #include <ips2ra.hpp>
#endif

/**-------------------------------------------------------------------------**/
/**---------------------------------非对称-----------------------------------**/
/**-------------------------------------------------------------------------**/
INDEX_TYPE pruneL(INDEX_TYPE jcol,INDEX_TYPE *U_r_idx,INDEX_TYPE *U_c_ptr,INDEX_TYPE *L_r_idx,INDEX_TYPE *L_c_ptr,
                  INDEX_TYPE *work_space,INDEX_TYPE *prune_space) {
    if (jcol == 0)
        return 0;

    INDEX_TYPE min = U_c_ptr[jcol];
    INDEX_TYPE max = U_c_ptr[jcol + 1];
    INDEX_TYPE cmin, cmax, crow, doprune;
    doprune = 0;

    for (INDEX_TYPE i = min; i < max; i++) //遍历U的一列
    {
        doprune = 0;
        crow = U_r_idx[i]; //U的行号
        cmin = L_c_ptr[crow]; //前端矩阵的列
        cmax = prune_space[crow]; //修剪后的列尾
        for (INDEX_TYPE j = cmin; j < cmax; j++) {
            if (L_r_idx[j] == jcol) {
                doprune = 1;
                break;
            }
        }

        if (doprune == 1) {
            for (INDEX_TYPE j = cmin; j < cmax; j++) {
                INDEX_TYPE ccrow = L_r_idx[j];
                if (ccrow > jcol && work_space[ccrow] == jcol) //加入L的结构，但又>jcol，进行移除
                {
                    INDEX_TYPE temp = L_r_idx[cmax - 1];
                    L_r_idx[cmax - 1] = L_r_idx[j];
                    L_r_idx[j] = temp;
                    cmax--;
                    j--;
                }
            }
        }
        prune_space[crow] = cmax;
    }
    return 0;
}

//todo并行计算

void fill_in_2_no_sort_pruneL(INDEX_TYPE n, INDEX_TYPE nnz,
                              INDEX_TYPE *ai, INDEX_TYPE *ap,
                              INDEX_TYPE **L_rowpointer, INDEX_TYPE **L_columnindex,
                              INDEX_TYPE **U_rowpointer, INDEX_TYPE **U_columnindex) {
    double start_time = omp_get_wtime();
    INDEX_TYPE relloc_zjq = nnz;
    INDEX_TYPE *U_r_idx = (INDEX_TYPE *) lu_malloc(relloc_zjq * sizeof(INDEX_TYPE)); //exclude diagonal
    INDEX_TYPE *U_c_ptr = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *L_r_idx = (INDEX_TYPE *) lu_malloc(relloc_zjq * sizeof(INDEX_TYPE)); //include diagonal
    INDEX_TYPE *L_c_ptr = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    U_c_ptr[0] = 0;
    L_c_ptr[0] = 0;

    INDEX_TYPE *parent = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE)); //for dfs
    INDEX_TYPE *xplore = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));

    INDEX_TYPE *work_space = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE)); //use this to avoid sorting
    INDEX_TYPE *prune_space = (INDEX_TYPE *) lu_malloc(n * sizeof(INDEX_TYPE));

    INDEX_TYPE U_maxsize = relloc_zjq;
    INDEX_TYPE L_maxsize = relloc_zjq;

    INDEX_TYPE U_size = 0;
    INDEX_TYPE L_size = 0; //record quantity

    INDEX_TYPE row = -1;
    INDEX_TYPE oldrow = -1;
    INDEX_TYPE xdfs = -1;
    INDEX_TYPE maxdfs = -1;
    INDEX_TYPE kchild = -1;
    INDEX_TYPE kpar = -1;

    for (INDEX_TYPE k = 0; k < n; k++) {
        work_space[k] = -1; //avoid conflict
        parent[k] = -1;
        xplore[k] = 0;
    }

    //列
    for (INDEX_TYPE i = 0; i < n; i++) {
        //列大小
        INDEX_TYPE n_rows = ap[i + 1] - ap[i];

        for (INDEX_TYPE k = 0; k < n_rows; k++) {
            row = (ai + ap[i])[k]; //行号
            if (work_space[row] == i)
                continue;

            work_space[row] = i;
            if (row >= i) //L部分
            {
                L_r_idx[L_size] = row;
                L_size++;

                if (L_size >= L_maxsize - 100) {
                    L_r_idx = (INDEX_TYPE *) lu_realloc(L_r_idx, (L_maxsize + relloc_zjq) * sizeof(INDEX_TYPE));
                    L_maxsize = L_maxsize + nnz;
                }
            } else {
                U_r_idx[U_size] = row;
                U_size++;
                if (U_size >= U_maxsize - 100) {
                    U_r_idx = (INDEX_TYPE *) lu_realloc(U_r_idx, (U_maxsize + relloc_zjq) * sizeof(INDEX_TYPE));
                    U_maxsize = U_maxsize + nnz;
                }
                //U得L的结构
                //do dfs
                oldrow = -1;
                parent[row] = oldrow;
                xdfs = L_c_ptr[row]; //xdfs ~ maxdfs
                maxdfs = prune_space[row]; //prune
                do {
                    /* code */
                    while (xdfs < maxdfs) {
                        kchild = L_r_idx[xdfs];
                        xdfs++;
                        if (work_space[kchild] != i) {
                            work_space[kchild] = i;
                            if (kchild >= i) {
                                L_r_idx[L_size] = kchild;
                                L_size++;
                                if (L_size >= L_maxsize - 100) {
                                    L_r_idx = (INDEX_TYPE *) lu_realloc(
                                        L_r_idx, (L_maxsize + relloc_zjq) * sizeof(INDEX_TYPE));
                                    L_maxsize = L_maxsize + nnz;
                                }
                            } else {
                                U_r_idx[U_size] = kchild;
                                U_size++;
                                if (U_size >= U_maxsize - 100) {
                                    U_r_idx = (INDEX_TYPE *) lu_realloc(
                                        U_r_idx, (U_maxsize + relloc_zjq) * sizeof(INDEX_TYPE));
                                    U_maxsize = U_maxsize + nnz;
                                }

                                xplore[row] = xdfs;
                                oldrow = row;
                                row = kchild;
                                parent[row] = oldrow;
                                xdfs = L_c_ptr[row];
                                maxdfs = prune_space[row]; //prune
                            }
                        }
                    }

                    kpar = parent[row];

                    if (kpar == -1)
                        break;

                    row = kpar;
                    xdfs = xplore[row];
                    maxdfs = prune_space[row];
                } while (kpar != -1);
            }
        }
        U_c_ptr[i + 1] = U_size;
        L_c_ptr[i + 1] = L_size;
        prune_space[i] = L_size;

        pruneL(i, U_r_idx, U_c_ptr, L_r_idx, L_c_ptr, work_space, prune_space);
    }

    double sort_time = omp_get_wtime();
    //todo 并行排序
    #pragma omp parallel sections
    {
        // 线程 1 处理 L 的排序
        #pragma omp section
        {
            for (INDEX_TYPE i = 0; i < n; ++i) {
                std::sort(&L_r_idx[L_c_ptr[i]], &L_r_idx[L_c_ptr[i + 1]]);
            }
        }

        // 线程 2 处理 U 的排序
        #pragma omp section
        {
            for (INDEX_TYPE i = 0; i < n; ++i) {
                std::sort(&U_r_idx[U_c_ptr[i]], &U_r_idx[U_c_ptr[i + 1]]);
            }
        }
    }
    LOG_TIME("sort elapsed time: %lf ms", (omp_get_wtime() - sort_time) * 1000.0);
    LOG_TIME("符号计算 elapsed time: %lf ms", (omp_get_wtime() - start_time) * 1000.0);
    lu_free(parent);
    lu_free(xplore);
    lu_free(work_space);
    lu_free(prune_space);

    *L_rowpointer = L_c_ptr;
    *L_columnindex = L_r_idx;
    *U_rowpointer = U_c_ptr;
    *U_columnindex = U_r_idx;
}

void symbolic_analysis(INDEX_TYPE *Ap, INDEX_TYPE *Ai, INDEX_TYPE n, INDEX_TYPE nnz,
                       PreprocessInfo *info) {
    double start_time = omp_get_wtime();
    //todo内存泄漏
    CSRMatrix *L = init_csr_matrix(n, n, nnz);
    CSRMatrix *U = init_csr_matrix(n, n, nnz);
    fill_in_2_no_sort_pruneL(n, nnz, Ai, Ap,
                             &U->row_pointers, &U->col_indices,
                             &L->row_pointers, &L->col_indices);
    U->nnz = U->row_pointers[n] + n;
    L->nnz = L->row_pointers[n] - n;
    INDEX_TYPE r_nnz = U->nnz + L->nnz;
    LOG_DEBUG("nnz of L is: %ld", L->nnz);
    LOG_DEBUG("nnz of U is: %ld", U->nnz);
    LOG_DEBUG("nnz of L+U-E is: %ld", r_nnz);
    CSRMatrix *pattern = init_csr_matrix(n, n, r_nnz);
    INDEX_TYPE *Rp = pattern->row_pointers;
    INDEX_TYPE *Ri = pattern->col_indices;
    //L+U
    INDEX_TYPE index_size = 0;
    Rp[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = L->row_pointers[i]; j < L->row_pointers[i + 1]; j++) {
            Ri[index_size++] = L->col_indices[j];
        }
        for (INDEX_TYPE j = U->row_pointers[i]; j < U->row_pointers[i + 1]; j++) {
            Ri[index_size++] = U->col_indices[j];
        }
        Rp[i + 1] = index_size;
    }
    info->L = L;
    info->U = U;
    info->pattern = pattern;
    LOG_TIME("symbolic analysis elapsed time: %lf ms", (omp_get_wtime() - start_time) * 1000.0);
}

void symbolic_near(INDEX_TYPE *Ap, INDEX_TYPE *Ai, INDEX_TYPE n, INDEX_TYPE nnz,
                   PreprocessInfo *info) {
    double start_time = omp_get_wtime();
    //todo内存泄漏
    CSRMatrix *L = init_csr_matrix(n, n, nnz);
    CSRMatrix *U = init_csr_matrix(n, n, nnz);

    U->nnz = U->row_pointers[n];
    L->nnz = L->row_pointers[n];
    INDEX_TYPE r_nnz = U->nnz + L->nnz;
    LOG_DEBUG("nnz of L is: %ld", L->nnz);
    LOG_DEBUG("nnz of U is: %ld", U->nnz);
    LOG_DEBUG("nnz of L+U-E is: %ld", r_nnz);
    CSRMatrix *pattern = init_csr_matrix(n, n, r_nnz);
    INDEX_TYPE *Rp = pattern->row_pointers;
    INDEX_TYPE *Ri = pattern->col_indices;
    //L+U
    INDEX_TYPE index_size = 0;
    Rp[0] = 0;
    for (INDEX_TYPE i = 0; i < n; i++) {
        for (INDEX_TYPE j = L->row_pointers[i]; j < L->row_pointers[i + 1]; j++) {
            Ri[index_size++] = L->col_indices[j];
        }
        for (INDEX_TYPE j = U->row_pointers[i]; j < U->row_pointers[i + 1]; j++) {
            Ri[index_size++] = U->col_indices[j];
        }
        Rp[i + 1] = index_size;
    }
    info->L = L;
    info->U = U;
    info->pattern = pattern;
    LOG_TIME("symbolic analysis elapsed time: %lf ms", (omp_get_wtime() - start_time) * 1000.0);
}

/**
 * 估计乘加的计算个数
 * @param n dim
 * @param Lp CSR L
 * @param Li CSR L
 * @param Up CSR U
 * @return
 */
long long compute_fma_count(
    INDEX_TYPE n,
    const INDEX_TYPE *Lp,
    const INDEX_TYPE *Li,
    const INDEX_TYPE *Up) {
    long long fma_count = 0;
    for (INDEX_TYPE i = 0; i < n; ++i) {
        for (INDEX_TYPE j = Lp[i]; j < Lp[i + 1]; ++j) {
            INDEX_TYPE col = Li[j];
            INDEX_TYPE nz = Up[col + 1] - Up[col];
            fma_count += nz;
        }
    }
    return fma_count;
}

void get_l_row_patterns_naive(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE parent[],
                              const INDEX_TYPE n,
                              const INDEX_TYPE cut_point,
                              INDEX_TYPE **outLp, INDEX_TYPE **outLi) {
    double start_time = omp_get_wtime();
    if (parent == NULL)
        LOG_ERROR("parent==NULL");
    INDEX_TYPE count = 0;
    const long long nnz = Ap[n];
    long long li_capacity = nnz * 5;
    INDEX_TYPE *Lp = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Li = (INDEX_TYPE *) lu_malloc(li_capacity * sizeof(INDEX_TYPE));
    Lp[0] = 0;
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    for (INDEX_TYPE r = 0; r < n; ++r) {
        if (count * 2 >= li_capacity) {
            li_capacity = li_capacity + li_capacity / 2;
            Li = (INDEX_TYPE *) lu_realloc(Li, li_capacity * sizeof(INDEX_TYPE));
        }
        mark[r] = r; //标记是否被添加过
        for (INDEX_TYPE k = Ap[r]; k < Ap[r + 1]; ++k) {
            INDEX_TYPE c = Ai[k];
            if (c < cut_point && c < r) { //只算下三角
                INDEX_TYPE j = c;
                while (j < cut_point && mark[j] != r) {
                    mark[j] = r;
                    Li[count++] = j;
                    j = parent[j];
                }
            }
        }
        Lp[r + 1] = count;
    }
    lu_free(mark);
    if (count) {
        Li = (INDEX_TYPE *) lu_realloc(Li, count * sizeof(INDEX_TYPE));
    }
    LOG_DEBUG("l naive nnz=%lld", count);
    LOG_TIME("get_l_row_patterns_naive time: %f ms", (omp_get_wtime()-start_time)*1000);

    start_time = omp_get_wtime();
    #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE i = 0; i < n; ++i) {
        std::sort(&Li[Lp[i]], &Li[Lp[i + 1]]);
    }
    LOG_TIME("sort li time: %f ms", (omp_get_wtime()-start_time)*1000);
    // 将分配结果返回给调用者
    *outLp = Lp;
    *outLi = Li;
}


void get_l_row_patterns_block(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE parent[],
                              const INDEX_TYPE n,
                              const INDEX_TYPE cut_point,
                              INDEX_TYPE **outLp_11, INDEX_TYPE **outLi_11,
                              INDEX_TYPE **outLp_21, INDEX_TYPE **outLi_21) {
    double start_time = omp_get_wtime();
    if (parent == NULL)
        LOG_ERROR("parent==NULL");
    const long long nnz = Ap[n];
    INDEX_TYPE count_11 = 0;
    INDEX_TYPE count_21 = 0;
    long long li_capacity_11 = nnz * 5;
    long long li_capacity_21 = nnz * 5;
    INDEX_TYPE *Lp_11 = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Li_11 = (INDEX_TYPE *) lu_malloc(li_capacity_11 * sizeof(INDEX_TYPE));
    INDEX_TYPE *Lp_21 = (INDEX_TYPE *) lu_malloc((n - cut_point + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Li_21 = (INDEX_TYPE *) lu_malloc(li_capacity_21 * sizeof(INDEX_TYPE));
    Lp_11[0] = 0;
    Lp_21[0] = 0;
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    for (INDEX_TYPE r = 0; r < cut_point; ++r) {
        if (count_11 * 2 >= li_capacity_11) {
            li_capacity_11 = li_capacity_11 + li_capacity_11 / 2;
            Li_11 = (INDEX_TYPE *) lu_realloc(Li_11, li_capacity_11 * sizeof(INDEX_TYPE));
        }
        mark[r] = r; //标记是否被添加过
        for (INDEX_TYPE k = Ap[r]; k < Ap[r + 1]; ++k) {
            INDEX_TYPE c = Ai[k];
            if (c < cut_point && c < r) { //只算下三角
                INDEX_TYPE j = c;
                while (j < cut_point && mark[j] != r) {
                    mark[j] = r;
                    Li_11[count_11++] = j;
                    j = parent[j];
                }
            }
        }
        Lp_11[r + 1] = count_11;
    }
    //L21
    for (INDEX_TYPE r = cut_point; r < n; ++r) {
        if (count_21 * 2 >= li_capacity_21) {
            li_capacity_21 = li_capacity_21 + li_capacity_21 / 2;
            Li_21 = (INDEX_TYPE *) lu_realloc(Li_21, li_capacity_21 * sizeof(INDEX_TYPE));
        }
        for (INDEX_TYPE k = Ap[r]; k < Ap[r + 1]; ++k) {
            INDEX_TYPE c = Ai[k];
            if (c < cut_point && c < r) { //只算下三角
                INDEX_TYPE j = c;
                while (j < cut_point && mark[j] != r) {
                    mark[j] = r;
                    Li_21[count_21++] = j;
                    j = parent[j];
                }
            }
        }
        Lp_21[r + 1] = count_11;
    }
    lu_free(mark);
    Li_11 = (INDEX_TYPE *) lu_realloc(Li_11, count_11 * sizeof(INDEX_TYPE));
    LOG_DEBUG("l naive nnz=%lld", count_11);
    LOG_TIME("get_l_row_patterns_naive time: %f ms", (omp_get_wtime()-start_time)*1000);

    start_time = omp_get_wtime();
    #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE i = 0; i < cut_point; ++i) {
        std::sort(&Li_11[Lp_11[i]], &Li_11[Lp_11[i + 1]]);
    }
    #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE i = 0; i < n - cut_point; ++i) {
        std::sort(&Li_21[Lp_21[i]], &Li_21[Lp_21[i + 1]]);
    }
    LOG_TIME("sort li time: %f ms", (omp_get_wtime()-start_time)*1000);
    // 将分配结果返回给调用者
    *outLp_11 = Lp_11;
    *outLi_11 = Li_11;
    *outLp_21 = Lp_21;
    *outLi_21 = Li_21;
}

///支持无序
INDEX_TYPE calc_l_nz(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                     const INDEX_TYPE parent[],
                     const INDEX_TYPE n, const INDEX_TYPE cut_point) {
    double start_time = omp_get_wtime();
    if (parent == NULL)
        LOG_ERROR("parent==NULL");
    INDEX_TYPE count = 0;
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    for (INDEX_TYPE r = 0; r < n; ++r) {
        mark[r] = r; //标记是否被添加过
        for (INDEX_TYPE k = Ap[r]; k < Ap[r + 1]; ++k) {
            INDEX_TYPE c = Ai[k];
            // if (c<min_row[r])continue;
            if (c < cut_point && c < r) { //只算下三角
                INDEX_TYPE j = c;
                while (j < cut_point && mark[j] != r) {
                    mark[j] = r;
                    j = parent[j];
                    count++;
                }
            }
        }
    }
    lu_free(mark);
    LOG_TIME("calc_l_nz time: %f ms", (omp_get_wtime()-start_time)*1000);
    return count; //不包括对角线
}

///废弃
INDEX_TYPE calc_l_nz_v2(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                        const INDEX_TYPE parent[],
                        const INDEX_TYPE n, const INDEX_TYPE cut_point,
                        const INDEX_TYPE *ap, const INDEX_TYPE *ai) {
    double start_time = omp_get_wtime();
    if (parent == NULL)
        LOG_ERROR("parent==NULL");
    INDEX_TYPE count = 0;
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    for (INDEX_TYPE r = 0; r < n; ++r) {
        mark[r] = r; //标记是否被添加过
        for (INDEX_TYPE k = Ap[r]; k < Ap[r + 1]; ++k) {
            INDEX_TYPE c = Ai[k];
            if (c < ai[ap[r]]) continue;
            if (c < cut_point && c < r) { //只算下三角
                INDEX_TYPE j = c;
                while (j < cut_point && mark[j] != r) {
                    mark[j] = r;
                    j = parent[j];
                    count++;
                }
            }
        }
    }
    lu_free(mark);
    LOG_TIME("calc_l_nz_v2 time: %f ms", (omp_get_wtime()-start_time)*1000);
    return count; //不包括对角线
}

INDEX_TYPE calc_l_nz_parallel(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE parent[],
                              const INDEX_TYPE n, const INDEX_TYPE cut_point) {
    double start_time = omp_get_wtime();
    if (parent == NULL)
        LOG_ERROR("parent==NULL");
    INDEX_TYPE count = 0;

    #pragma omp parallel reduction(+:count)
    {
        INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
        #pragma omp for
        for (INDEX_TYPE r = 0; r < n; ++r) {
            mark[r] = r; //标记是否被添加过
            for (INDEX_TYPE k = Ap[r]; k < Ap[r + 1]; ++k) {
                INDEX_TYPE c = Ai[k];
                // if (c<min_row[r])continue;
                if (c < cut_point && c < r) { //只算下三角
                    INDEX_TYPE j = c;
                    while (j < cut_point && mark[j] != r) {
                        mark[j] = r;
                        j = parent[j];
                        count++;
                    }
                }
            }
        }
        lu_free(mark);
    }
    LOG_TIME("calc_l_nz time: %f ms", (omp_get_wtime()-start_time)*1000);
    return count; //不包括对角线
}

void get_l_col_nnz(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                   const INDEX_TYPE n, const INDEX_TYPE *etree,
                   INDEX_TYPE *Lp, INDEX_TYPE *Li,
                   INDEX_TYPE cut_point1) {
    double start_time = omp_get_wtime();
    long fma_count = 0;
    //双亲表示法转孩子兄弟表示法
    INDEX_TYPE *first_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    for (INDEX_TYPE v = 0; v <= n; first_kid[v++] = -1);
    for (INDEX_TYPE v = 0; v <= n; next_kid[v++] = -1);
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = etree[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE l_col_count = 0;
    Lp[0] = 0;
    for (INDEX_TYPE i = 0; i < cut_point1; ++i) {
        int row_count = 0;
        //复制自己
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE row = Ai[j];
            if (row <= i) continue;
            Li[l_col_count++] = row;
            mark[row] = i;
            row_count++;
        }
        //查孩子
        INDEX_TYPE child = first_kid[i];
        while (child != -1) {
            // printf("Child of node %lld: %lld\n", i + 1, child + 1);
            //求并集
            for (INDEX_TYPE k = Lp[child + 1] - 1; k >= Lp[child]; k--) {
                INDEX_TYPE row = Li[k];
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Li[l_col_count++] = row;
                    row_count++;
                }
            }
            child = next_kid[child];
        }
        Lp[i + 1] = l_col_count;
        fma_count += row_count * row_count;
    }
    lu_free(mark);
    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    LOG_DEBUG("nnz:%ld", l_col_count);
    LOG_DEBUG("fma_count:%ld", fma_count);
    LOG_DEBUG("fma_count:%ld G", fma_count/1024/1024/1024);
    LOG_TIME("get_l_col_nnz time: %f ms", (omp_get_wtime()-start_time)*1000);
}

///get_u_row_patterns_naive
void get_l_col_patterns_naive(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE n, const INDEX_TYPE *etree,
                              INDEX_TYPE *Lp, INDEX_TYPE *Li,
                              INDEX_TYPE cut_point1,INDEX_TYPE cut_point2) {
    double start_time = omp_get_wtime();
    long long fma_count = 0;
    //双亲表示法转孩子兄弟表示法
    INDEX_TYPE *first_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    for (INDEX_TYPE v = 0; v <= n; first_kid[v++] = -1);
    for (INDEX_TYPE v = 0; v <= n; next_kid[v++] = -1);
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = etree[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    long long l_col_count = 0;
    Lp[0] = 0;
    for (INDEX_TYPE i = 0; i < n; ++i) {
        int row_count = 0;
        //复制自己
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE row = Ai[j];
            if (row <= i) continue;
            Li[l_col_count++] = row;
            mark[row] = i;
            row_count++;
        }
        //查孩子
        INDEX_TYPE child = first_kid[i];
        while (child != -1) {
            // printf("Child of node %lld: %lld\n", i + 1, child + 1);
            //求并集
            for (INDEX_TYPE k = Lp[child + 1] - 1; k >= Lp[child]; k--) {
                INDEX_TYPE row = Li[k];
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Li[l_col_count++] = row;
                    row_count++;
                }
            }
            child = next_kid[child];
        }
        Lp[i + 1] = l_col_count;
        fma_count += row_count * row_count;
        if (i == cut_point1 - 1 || i == cut_point2 - 1) {
            LOG_DEBUG("cut_point(%lld) fma_count:%ld G --- %ld", i, fma_count/1024/1024/1024, fma_count);
        }
    }
    lu_free(mark);
    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    LOG_DEBUG("naive nnz:%lld", l_col_count);
    LOG_DEBUG("fma_count:%lld", fma_count);
    LOG_DEBUG("fma_count:%lld G", fma_count/1024/1024/1024);
    LOG_TIME("get_l_col_patterns time: %f ms", (omp_get_wtime()-start_time)*1000);
}

///函数内分配内存
void get_u_row_patterns_naive(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE n, const INDEX_TYPE *etree,
                              INDEX_TYPE **outUp, INDEX_TYPE **outUi,
                              INDEX_TYPE cut_point1,INDEX_TYPE cut_point2) {
    double start_time = omp_get_wtime();
    long long nnz = Ap[n];
    long long ui_capacity = nnz * 5;
    INDEX_TYPE *Up = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ui = (INDEX_TYPE *) lu_malloc(ui_capacity * sizeof(INDEX_TYPE));
    //双亲表示法转孩子兄弟表示法
    INDEX_TYPE *first_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    for (INDEX_TYPE v = 0; v <= n; first_kid[v++] = -1);
    for (INDEX_TYPE v = 0; v <= n; next_kid[v++] = -1);
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = etree[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    long long count = 0;
    Up[0] = 0;
    for (INDEX_TYPE i = 0; i < n; ++i) {
        if (count * 2 >= ui_capacity) {
            ui_capacity = ui_capacity + ui_capacity / 2;
            Ui = (INDEX_TYPE *) lu_realloc(Ui, ui_capacity * sizeof(INDEX_TYPE));
        }
        //复制自己
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE row = Ai[j];
            if (row <= i) continue;
            Ui[count++] = row;
            mark[row] = i;
        }
        //查孩子
        INDEX_TYPE child = first_kid[i];
        while (child != -1) {
            // printf("Child of node %lld: %lld\n", i + 1, child + 1);
            //求并集
            for (INDEX_TYPE k = Up[child + 1] - 1; k >= Up[child]; k--) {
                INDEX_TYPE row = Ui[k];
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Ui[count++] = row;
                }
            }
            child = next_kid[child];
        }
        Up[i + 1] = count;
    }
    lu_free(mark);
    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    Ui = (INDEX_TYPE *) lu_realloc(Ui, count * sizeof(INDEX_TYPE));
    // start_time=omp_get_wtime();
    // #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    // for (INDEX_TYPE i = 0; i < n; ++i) {
    //     ips2ra::sort(&Ui[Up[i]], &Ui[Up[i + 1]]);
    // }
    // LOG_TIME("sort ui time: %f ms", (omp_get_wtime()-start_time)*1000);
    *outUi = Ui;
    *outUp = Up;
    LOG_DEBUG("naive u_nnz:%lld", count);
    LOG_TIME("get_u_row_patterns_naive time: %f ms", (omp_get_wtime()-start_time)*1000);
}

///函数内分配内存
void get_u_row_patterns_block(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE n, const INDEX_TYPE *etree,
                              INDEX_TYPE **outUp_11, INDEX_TYPE **outUi_11,
                              INDEX_TYPE **outUp_12, INDEX_TYPE **outUi_12,
                              INDEX_TYPE cut_point1,INDEX_TYPE cut_point2) {
    double start_time = omp_get_wtime();
    long long nnz = Ap[n];
    long long capacity_11 = nnz * 5;
    long long capacity_12 = nnz * 5;
    INDEX_TYPE *Up_11 = (INDEX_TYPE *) lu_malloc((cut_point1 + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ui_11 = (INDEX_TYPE *) lu_malloc(capacity_11 * sizeof(INDEX_TYPE));
    INDEX_TYPE *Up_12 = (INDEX_TYPE *) lu_malloc((cut_point1 + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ui_12 = (INDEX_TYPE *) lu_malloc(capacity_11 * sizeof(INDEX_TYPE));
    //双亲表示法转孩子兄弟表示法
    INDEX_TYPE *first_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    for (INDEX_TYPE v = 0; v <= n; first_kid[v++] = -1);
    for (INDEX_TYPE v = 0; v <= n; next_kid[v++] = -1);
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = etree[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    long long count_11 = 0;
    long long count_12 = 0;
    Up_11[0] = 0;
    Up_12[0] = 0;
    for (INDEX_TYPE i = 0; i < cut_point1; ++i) {
        if (count_11 * 2 >= capacity_11) {
            capacity_11 = capacity_11 + capacity_11 / 2;
            Ui_11 = (INDEX_TYPE *) lu_realloc(Ui_11, capacity_11 * sizeof(INDEX_TYPE));
        }
        if (count_12 * 2 >= capacity_12) {
            capacity_12 = capacity_12 + capacity_12 / 2;
            Ui_12 = (INDEX_TYPE *) lu_realloc(Ui_12, capacity_12 * sizeof(INDEX_TYPE));
        }
        //复制自己
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE row = Ai[j];
            if (row <= i) continue;
            if (row < cut_point1) {
                Ui_11[count_11++] = row;
                Up_11[i + 1] = count_11;
            } else {
                Ui_12[count_12++] = row - cut_point1;
                Up_12[i + 1] = count_12;
            }
            mark[row] = i;
        }
        //查孩子
        INDEX_TYPE child = first_kid[i];
        while (child != -1) {
            // printf("Child of node %lld: %lld\n", i + 1, child + 1);
            //求并集
            for (INDEX_TYPE k = Up_11[child + 1] - 1; k >= Up_11[child]; k--) {
                INDEX_TYPE row = Ui_11[k];
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Ui_11[count_11++] = row;
                }
            }
            for (INDEX_TYPE k = Up_12[child + 1] - 1; k >= Up_12[child]; k--) {
                INDEX_TYPE row = Ui_12[k] + cut_point1;
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Ui_12[count_12++] = row - cut_point1;
                }
            }
            child = next_kid[child];
        }
        Up_11[i + 1] = count_11;
        Up_12[i + 1] = count_12;
    }
    lu_free(mark);
    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    if (count_11) {
        Ui_11 = (INDEX_TYPE *) lu_realloc(Ui_11, count_11 * sizeof(INDEX_TYPE));
    }
    if (count_12) {
        Ui_12 = (INDEX_TYPE *) lu_realloc(Ui_12, count_12 * sizeof(INDEX_TYPE));
    }
    start_time=omp_get_wtime();
    // #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    // for (INDEX_TYPE i = 0; i < cut_point1; ++i) {
    //     std::sort(&Ui_12[Up_12[i]], &Ui_12[Up_12[i + 1]]);
    // }
    LOG_TIME("sort ui12 time: %f ms", (omp_get_wtime()-start_time)*1000);
    *outUp_11 = Up_11;
    *outUi_11 = Ui_11;
    *outUp_12 = Up_12;
    *outUi_12 = Ui_12;
    LOG_DEBUG("naive U/L 11_nnz:%lld", count_11);
    LOG_DEBUG("naive U/L 21_nnz:%lld", count_12);
    LOG_TIME("get_u_row_patterns_block time: %f ms", (omp_get_wtime()-start_time)*1000);
}

void get_l_col_patterns_parallel(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                                 const INDEX_TYPE n, const INDEX_TYPE *etree,
                                 INDEX_TYPE *Lp, INDEX_TYPE *Li,
                                 INDEX_TYPE cut_point1,INDEX_TYPE cut_point2,
                                 INDEX_TYPE split_points_num, INDEX_TYPE *split_points) {
    double start_time = omp_get_wtime();
    long long fma_count = 0;
    //双亲表示法转孩子兄弟表示法
    INDEX_TYPE *first_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    for (INDEX_TYPE v = 0; v <= n; first_kid[v++] = -1);
    for (INDEX_TYPE v = 0; v <= n; next_kid[v++] = -1);
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = etree[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    long long l_col_count = 0;
    Lp[0] = 0;

    // // #pragma omp parallel for reduction(+:fma_count)//proc_bind(spread) schedule(dynamic)
    for (INDEX_TYPE ii = 0; ii < split_points_num; ++ii) {
        // int tid = omp_get_thread_num();    // 获取线程 ID
        // int nt  = omp_get_num_threads();   // 获取线程总数
        // #pragma omp critical
        // printf("  线程 %d / %d 正在运行\n", tid, nt);
        INDEX_TYPE start_row = split_points[ii];
        INDEX_TYPE end_row = split_points[ii + 1];
        for (INDEX_TYPE i = start_row; i < end_row; ++i) {
            int row_count = 0;
            //复制自己
            for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
                INDEX_TYPE row = Ai[j];
                if (row <= i) continue;
                Li[l_col_count++] = row;
                mark[row] = i;
                row_count++;
            }
            //查孩子
            INDEX_TYPE child = first_kid[i];
            while (child != -1) {
                // printf("Child of node %lld: %lld\n", i + 1, child + 1);
                //求并集
                for (INDEX_TYPE k = Lp[child + 1] - 1; k >= Lp[child]; k--) {
                    INDEX_TYPE row = Li[k];
                    if (row <= i) continue;
                    //printf("访问：%lld，", row);
                    if (mark[row] != i) {
                        mark[row] = i;
                        Li[l_col_count++] = row;
                        row_count++;
                    }
                }
                child = next_kid[child];
            }
            Lp[i + 1] = l_col_count;
            fma_count += row_count * row_count;
        }
    }
    lu_free(mark);
    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    LOG_DEBUG("nnz:%lld", l_col_count);
    LOG_DEBUG("fma_count:%lld", fma_count);
    LOG_DEBUG("fma_count:%lld G", fma_count/1024/1024/1024);
    LOG_TIME("get_l_col_patterns 并行 time: %f ms", (omp_get_wtime()-start_time)*1000);
}


void get_l_col_patterns_block(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                              const INDEX_TYPE n, const INDEX_TYPE *etree,
                              INDEX_TYPE *Lp_11, INDEX_TYPE *Li_11,
                              INDEX_TYPE *Lp_21, INDEX_TYPE *Li_21,
                              INDEX_TYPE cut_point1,INDEX_TYPE cut_point2) {
    double start_time = omp_get_wtime();
    long fma_count = 0;
    //双亲表示法转孩子兄弟表示法
    INDEX_TYPE *first_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    for (INDEX_TYPE v = 0; v <= n; first_kid[v++] = -1);
    for (INDEX_TYPE v = 0; v <= n; next_kid[v++] = -1);
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = etree[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE l11_col_count = 0;
    INDEX_TYPE l21_col_count = 0;
    Lp_11[0] = 0;
    Lp_21[0] = 0;
    for (INDEX_TYPE i = 0; i < cut_point1; ++i) {
        int row_count = 0;
        //复制自己
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE row = Ai[j];
            if (row <= i) continue;
            // if (mark[row] == i) continue;
            if (row < cut_point1) {
                Li_11[l11_col_count++] = row;
                Lp_11[i + 1] = l11_col_count;
            } else {
                Li_21[l21_col_count++] = row - cut_point1;
                Lp_21[i + 1] = l21_col_count;
            }
            mark[row] = i;
            row_count++;
        }
        //查孩子
        INDEX_TYPE child = first_kid[i];
        while (child != -1) {
            // printf("Child of node %lld: %lld\n", i + 1, child + 1);
            //求并集
            for (INDEX_TYPE k = Lp_11[child + 1] - 1; k >= Lp_11[child]; k--) {
                INDEX_TYPE row = Li_11[k];
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Li_11[l11_col_count++] = row;
                    row_count++;
                }
            }
            for (INDEX_TYPE k = Lp_21[child + 1] - 1; k >= Lp_21[child]; k--) {
                INDEX_TYPE row = Li_21[k] + cut_point1;
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Li_21[l21_col_count++] = row - cut_point1;
                    row_count++;
                }
            }
            child = next_kid[child];
        }
        Lp_11[i + 1] = l11_col_count;
        Lp_21[i + 1] = l21_col_count;
        fma_count += row_count * row_count;
        if (i == cut_point1 || i == cut_point2) {
            LOG_DEBUG("cut_point(%lld) fma_count:%ld G", i, fma_count/1024/1024/1024);
        }
    }
    for (INDEX_TYPE i = cut_point1; i < cut_point2; ++i) {
    }
    lu_free(mark);
    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    LOG_DEBUG("nnz:%ld", l11_col_count+l21_col_count);
    LOG_DEBUG("fma_count:%ld", fma_count);
    LOG_DEBUG("fma_count:%ld G", fma_count/1024/1024/1024);
    double end_time = omp_get_wtime();
    LOG_TIME("get_l_col_patterns block time: %f ms", (end_time-start_time)*1000);
    #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    for (INDEX_TYPE i = 0; i < cut_point1; ++i) {
        #ifdef __x86_64__
            ips2ra::sort(&Li_11[Lp_11[i]], &Li_11[Lp_11[i + 1]],[](INDEX_TYPE x) { return static_cast<unsigned long long>(x); });
            ips2ra::sort(&Li_21[Lp_21[i]], &Li_21[Lp_21[i + 1]],[](INDEX_TYPE x) { return static_cast<unsigned long long>(x); });
        #else
        std::sort(&Li_11[Lp_11[i]], &Li_11[Lp_11[i + 1]]);
        std::sort(&Li_21[Lp_21[i]], &Li_21[Lp_21[i + 1]]);
        #endif
    }

    LOG_TIME("sort block time: %f ms", (omp_get_wtime()-end_time)*1000);
}

void get_u_row_patterns_block3(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,
                               const INDEX_TYPE n, const INDEX_TYPE *etree,
                               INDEX_TYPE **outUp_11, INDEX_TYPE **outUi_11,
                               INDEX_TYPE **outUp_12, INDEX_TYPE **outUi_12,
                               INDEX_TYPE cut_point1,INDEX_TYPE cut_point2) {
    double start_time = omp_get_wtime();
    long long nnz = Ap[n];
    long long capacity_11 = nnz * 5;
    long long capacity_12 = nnz * 5;
    INDEX_TYPE *Up_11 = (INDEX_TYPE *) lu_malloc((cut_point1 + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ui_11 = (INDEX_TYPE *) lu_malloc(capacity_11 * sizeof(INDEX_TYPE));
    INDEX_TYPE *Up_12 = (INDEX_TYPE *) lu_malloc((cut_point1 + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *Ui_12 = (INDEX_TYPE *) lu_malloc(capacity_11 * sizeof(INDEX_TYPE));

    long fma_count = 0;
    //双亲表示法转孩子兄弟表示法
    INDEX_TYPE *first_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    INDEX_TYPE *next_kid = (INDEX_TYPE *) lu_malloc((n + 1) * sizeof(INDEX_TYPE));
    for (INDEX_TYPE v = 0; v <= n; first_kid[v++] = -1);
    for (INDEX_TYPE v = 0; v <= n; next_kid[v++] = -1);
    first_kid++;
    next_kid++;
    for (INDEX_TYPE v = n - 1; v >= 0; v--) {
        INDEX_TYPE dad = etree[v];
        next_kid[v] = first_kid[dad];
        first_kid[dad] = v;
    }
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE l11_col_count = 0;
    INDEX_TYPE l21_col_count = 0;
    Up_11[0] = 0;
    Up_12[0] = 0;
    for (INDEX_TYPE i = 0; i < cut_point1; ++i) {
        if (l11_col_count * 2 >= capacity_11) {
            capacity_11 = capacity_11 + capacity_11 / 2;
            Ui_11 = (INDEX_TYPE *) lu_realloc(Ui_11, capacity_11 * sizeof(INDEX_TYPE));
        }
        if (l21_col_count * 2 >= capacity_12) {
            capacity_12 = capacity_12 + capacity_12 / 2;
            Ui_12 = (INDEX_TYPE *) lu_realloc(Ui_12, capacity_12 * sizeof(INDEX_TYPE));
        }
        int row_count = 0;
        //复制自己
        for (INDEX_TYPE j = Ap[i]; j < Ap[i + 1]; ++j) {
            INDEX_TYPE row = Ai[j];
            if (row <= i) continue;
            // if (mark[row] == i) continue;
            if (row < cut_point1) {
                Ui_11[l11_col_count++] = row;
                Up_11[i + 1] = l11_col_count;
            } else {
                Ui_12[l21_col_count++] = row - cut_point1;
                Up_12[i + 1] = l21_col_count;
            }
            mark[row] = i;
            row_count++;
        }
        //查孩子
        INDEX_TYPE child = first_kid[i];
        while (child != -1) {
            // printf("Child of node %lld: %lld\n", i + 1, child + 1);
            //求并集
            for (INDEX_TYPE k = Up_11[child + 1] - 1; k >= Up_11[child]; k--) {
                INDEX_TYPE row = Ui_11[k];
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Ui_11[l11_col_count++] = row;
                    row_count++;
                }
            }
            for (INDEX_TYPE k = Up_12[child + 1] - 1; k >= Up_12[child]; k--) {
                INDEX_TYPE row = Ui_12[k] + cut_point1;
                if (row <= i) continue;
                //printf("访问：%lld，", row);
                if (mark[row] != i) {
                    mark[row] = i;
                    Ui_12[l21_col_count++] = row - cut_point1;
                    row_count++;
                }
            }
            child = next_kid[child];
        }
        Up_11[i + 1] = l11_col_count;
        Up_12[i + 1] = l21_col_count;
        fma_count += row_count * row_count;
        if (i == cut_point1 || i == cut_point2) {
            LOG_DEBUG("cut_point(%lld) fma_count:%ld G", i, fma_count/1024/1024/1024);
        }
    }
    for (INDEX_TYPE i = cut_point1; i < cut_point2; ++i) {
    }
    lu_free(mark);
    first_kid--;
    next_kid--;
    lu_free(first_kid);
    lu_free(next_kid);
    *outUp_11 = Up_11;
    *outUi_11 = Ui_11;
    *outUp_12 = Up_12;
    *outUi_12 = Ui_12;
    LOG_DEBUG("nnz:%ld", l11_col_count+l21_col_count);
    LOG_DEBUG("fma_count:%ld", fma_count);
    LOG_DEBUG("fma_count:%ld G", fma_count/1024/1024/1024);
    double end_time = omp_get_wtime();
    LOG_TIME("get_l_col_patterns block time: %f ms", (end_time-start_time)*1000);
    // #pragma omp parallel for schedule(dynamic) proc_bind(spread)
    // for (INDEX_TYPE i = 0; i < cut_point1; ++i) {
    //     ips2ra::sort(&Ui_11[Up_11[i]], &Ui_11[Up_11[i + 1]]);
    //     ips2ra::sort(&Ui_12[Up_12[i]], &Ui_12[Up_12[i + 1]]);
    // }
    //
    // LOG_TIME("sort block time: %f ms", (omp_get_wtime()-end_time)*1000);
}

///废弃
typedef struct {
    INDEX_TYPE num_row; // 行数
    INDEX_TYPE num_col; // 列数
    ELE_TYPE *data; // 行优先密集存储
    INDEX_TYPE *row_idx; //存储本 Supernode 中出现非零的行号
    int row_count; // row_idx 的有效长度
} Supernode;

///废弃
void relax_supernode_sparse_rate(
    const INDEX_TYPE n,
    const INDEX_TYPE *Lp,
    const INDEX_TYPE *Li,
    const INDEX_TYPE split_points_num,
    const INDEX_TYPE *split_points
) {
    // mark 数组用于去重
    INDEX_TYPE *mark = (INDEX_TYPE *) lu_calloc(n, sizeof(INDEX_TYPE));
    INDEX_TYPE idx = 0; // 全局写指针

    for (INDEX_TYPE ii = 0; ii < split_points_num; ++ii) {
        INDEX_TYPE start_row = split_points[ii];
        INDEX_TYPE end_row = split_points[ii + 1];
        long count = 0;
        for (INDEX_TYPE i = start_row; i < end_row; ++i) {
            //第i个supernode
            for (INDEX_TYPE p = Lp[i]; p < Lp[i + 1]; ++p) {
                INDEX_TYPE r = Li[p]; //行号
                // printf("%d,",r);
                // 若在当前 supernode 尚未加入，则加入
                if (mark[r] != ii + 1) {
                    mark[r] = ii + 1; // 标记为已加入
                    count++;
                }
            }
            // printf("\n");
        }
        printf("%ld=%ld*%ld  ", count * (end_row - start_row), count, (end_row - start_row));
        printf("nnz=%ld", Lp[end_row] - Lp[start_row]);
        printf("  %.2lf%%\n", 100.0 * (Lp[end_row] - Lp[start_row]) / (count * (end_row - start_row)));
    }
    lu_free(mark);
}

void symbolic_analysis_block(const INDEX_TYPE *etree,
                             const CSRMatrix *A,
                             const PreprocessInfo *info,
                             CSRMatrix *U11, CSRMatrix *U12,
                             CSRMatrix *L11, CSRMatrix *L21) {
    INDEX_TYPE *Lp, *Li;
    INDEX_TYPE *Up_11, *Ui_11, *Up_12, *Ui_12;
    get_u_row_patterns_block(A->row_pointers, A->col_indices, A->num_col, etree,
                             &Up_11, &Ui_11, &Up_12, &Ui_12, info->cut_point1, info->cut_point2);
    get_l_row_patterns_naive(A->row_pointers, A->col_indices, etree,
                             A->num_col, info->cut_point1, &Lp, &Li);
    INDEX_TYPE n = A->num_row;
    INDEX_TYPE *Lp_11 = Lp;
    INDEX_TYPE *Li_11 = Li;
    INDEX_TYPE *Lp_21 = &Lp[info->cut_point1];
    INDEX_TYPE *Li_21 = Li;
    long long l_nnz_11 = Lp[info->cut_point1];
    long long l_nnz_21 = Lp[A->num_row] - l_nnz_11;
    long long u_nnz_11 = Up_11[info->cut_point1];
    long long u_nnz_12 = Up_12[info->cut_point1];
    //--------------U11--------------
    (U11)->row_pointers = Up_11;
    (U11)->col_indices = Ui_11;
    (U11)->nnz = u_nnz_11;
    (U11)->num_row = info->cut_point1;
    (U11)->num_col = info->cut_point1;
    //--------------U12--------------
    (U12)->row_pointers = Up_12;
    (U12)->col_indices = Ui_12;
    (U12)->nnz = u_nnz_12;
    (U12)->num_row = info->cut_point1;
    (U12)->num_col = n - info->cut_point1;
    //--------------L11--------------
    (L11)->row_pointers = Lp_11;
    (L11)->col_indices = Li_11;
    (L11)->nnz = l_nnz_11;
    (L11)->num_row = info->cut_point1;
    (L11)->num_col = info->cut_point1;
    //--------------L21--------------
    (L21)->row_pointers = Lp_21;
    (L21)->col_indices = Li_21;
    (L21)->nnz = l_nnz_21;
    (L21)->num_row = n - info->cut_point1;
    (L21)->num_col = info->cut_point1;

    L11->csr_values = U11->csr_values = L21->csr_values = U12->csr_values = nullptr;
    LOG_DEBUG("L11 nnz: %ld", L11->nnz);
    LOG_DEBUG("L21 nnz: %ld", L21->nnz);
    LOG_DEBUG("U11 nnz: %ld", U11->nnz);
    LOG_DEBUG("U12 nnz: %ld", U12->nnz);
}
