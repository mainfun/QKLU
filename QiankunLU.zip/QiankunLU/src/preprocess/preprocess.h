//
// Created by mainf on 2024/8/16.
//
#ifndef QKLU_PREPROCESS_H
#define QKLU_PREPROCESS_H

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

#include "base/matrix.h"

typedef struct PREPROCESS_INFO {
    struct CSR_MATRIX *pattern; //L+U的结构
    INDEX_TYPE *etree; //消元树
    struct CSR_MATRIX *L; //L的结构
    struct CSR_MATRIX *U; //U的结构
    // double max_nz; //预估的L的非零元上限
    // double pattern_sym_rate; // 结构对称比
    INDEX_TYPE *reorder_perm; //重排序的置换矩阵
    INDEX_TYPE *reorder_iperm; //重排序的置换矩阵的转置矩阵
    /**MC64**/
    INDEX_TYPE *mc64_perm; //mc64的置换矩阵
    INDEX_TYPE *mc64_iperm;
    double *Dc; //mc64：选主元的缩放矩阵,col_scale
    double *Dr; //mc64：row_scale
    /**end MC64**/
    INDEX_TYPE cut_point1;
    INDEX_TYPE cut_point2;
    INDEX_TYPE *layer1_splits;
    INDEX_TYPE layer1_splits_num;
    INDEX_TYPE *layer2_splits;
    INDEX_TYPE layer2_splits_num;
} PreprocessInfo;

PreprocessInfo *init_preprocess_info();

void free_preprocess_info(PreprocessInfo *info);

INDEX_TYPE *L_max_row_idx(const INDEX_TYPE *Lp, const INDEX_TYPE *Li,INDEX_TYPE n);

INDEX_TYPE *A_min_row_idx(const INDEX_TYPE *Ap, const INDEX_TYPE *Ai,INDEX_TYPE n);
#ifdef __cplusplus
}
#endif //__cplusplus
#endif //QKLU_PREPROCESS_H
